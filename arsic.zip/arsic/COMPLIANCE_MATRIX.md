# ARSIC Compliance Matrix

Every spec requirement (S1–S9) mapped to implementation and verification.
Status legend: **IMPL** = implemented as specified · **SUBST** = implemented
behind the specified interface with a documented environment substitution
(sandbox has no network egress, no container orchestration, ephemeral disk).

Test IDs refer to `tests/` (run: `python3 -m unittest discover -s tests`;
66/66 passing). "Demo" = observed in `python3 -m arsic demo` output /
`run/reports/RUN_REPORT.md`.

## S1 — Definition & objectives

| Requirement | Implementation | Verified by | Status |
|---|---|---|---|
| Governed multi-agent runtime; trading instantiation is market-neutral funding/basis/RWA arb, paper-first | whole package; `bootstrap.build_system` signs a system contract with `paper_only=True`, `max_drawdown=0.10`, `max_leverage=3.0`, `min_liq_score=0.3` | test_e2e (zero live trades), test_trading.TestGateway | IMPL |
| Self-improvement only through gated, audited channels | privilege ladder + tickets (`governance.py`), all changes land as tickets; POLICY+ require human role | test_governance.TestTickets, test_improve.TestEpochGates | IMPL |

## S2 — Layered architecture

| Layer | Implementation | Verified by | Status |
|---|---|---|---|
| Governance plane above everything | `Governance`, `KillSwitch`, `ScopeRouter`; scheduler subscribes to freeze hook | test_runtime.test_frozen_scheduler_skips, drill in demo | IMPL |
| Recursive improvement plane | `improve.HarnessEvolution`, `evaluate.EvaluatorEvolution`, `improve.MetaQueue` | test_improve, test_evaluate | IMPL |
| Constellation runtime | `runtime.AgentProcess/Scheduler/Bus`, 19 agents in `constellation.py` | test_runtime, test_e2e | IMPL |
| Knowledge wiki substrate | `wiki.TemporalKG` + `wiki.WikiPages` + `exg.ExperienceGraph` | test_wiki, test_e2e | IMPL |
| Perception & tool plane; agents never touch raw disk/APIs | drivers wrapped as `tools.Tool` with scopes + selftests; registry denies out-of-scope calls | test_runtime.TestTools | IMPL/SUBST (live feeds → seeded synthetic drivers behind the same `MarketDriver` interface) |

## S3 — Knowledge Wiki substrate

| Requirement | Implementation | Verified by | Status |
|---|---|---|---|
| Compiled pages; queries hit the wiki, not the firehose | `WikiPages.compile_all` (nightly) + `surgical` (on change); agents read via `stats_from_wiki` | test_wiki.TestPages; curator step in cycle | IMPL |
| Temporal KG: provenance, timestamp, confidence, invalidation | `Claim` carries all four; `latest(at=)` respects validity; `sweep_invalidation` | test_wiki.TestInvalidation | IMPL |
| Predicates: funding_rate_at, volume_24h, basis_vs_spot, holder_count, narrative_velocity | written by perception agents each cycle (`constellation.py`) | test_e2e (wiki populated), demo | IMPL |
| Entities incl. Binance BTC-USDT-Perp, Ondo USDY, Hyperliquid HIP-3 RWA, MOVE | `perception.UNIVERSE` + `RWADriver` entities | demo wiki pages table | IMPL |
| Gated patches, 5 outcomes: insert / merge / relate / conflict / reject | `TemporalKG.apply` returns exactly these | test_wiki.TestPatchOutcomes (all five) | IMPL |
| Conflicts → arbiter (human/high-privilege); canonical untouched | `arbiter_queue`; `resolve_conflict` role-gated | test_wiki.test_conflict_* | IMPL |
| Experience graph: trajectories → principles; analogous retrieval | `exg.py` (cosine over regime one-hot + stats) | test_e2e.test_trajectories_written; 19 principles in demo | IMPL |
| Audit surface: every claim traceable to page + source hash | `WikiPages.trace(cid)` → page, provenance, object-store key | test_wiki (trace) | IMPL |
| Vector store for retrieval | token-overlap index in `WikiPages.search` | test_wiki (search) | SUBST (interface point for a real vector store) |
| Neo4j-like graph DB | in-process property graph (`TemporalKG.edges`) + content-addressed `ObjectStore` | test_events, test_wiki | SUBST (no external DB offline; same query surface) |

## S4 — Agent constellation

| Requirement | Implementation | Verified by | Status |
|---|---|---|---|
| Perception: market / on-chain / sentiment / RWA agents | `MarketDataAgent`, `OnChainAgent`, `SentimentAgent`, `RWAAgent` | demo; test_e2e | IMPL |
| Research: Market Analyst, Research Analyst, Sentiment/Narrative, Opportunity Scanner | corresponding classes in `constellation.py`; scanner uses shared `should_enter` | demo | IMPL |
| Strategy: Funding-Arb, Basis/Cash-and-Carry, RWA-Spread, Cross-Venue | four strategy agents; RWA proposals are desk-queue only (off-perp venue) | demo (33 closed ops over 30d) | IMPL |
| Exec/Risk: paper simulator, position sizing, liquidation monitor, kill-switch | `trading.py` + `SizingExecAgent`, `LiquidationMonitorAgent`, `KillSwitchAgent` | test_trading; drill in demo | IMPL |
| Meta: Wiki Curator, EXG Writer, Improvement Proposer, Evaluator | four meta agents | demo (freshness/score claims daily) | IMPL |
| IACT-style recursive spawning w/ report-up | `AgentProcess.spawn`; `OpportunityScannerAgent` spawns `DeepDiveAgent` on borderline signals | test_runtime.test_spawn_tree_and_report_up | IMPL |
| Agents: signed contract, bounded scope, private memory, planner-executor-verifier, improvement policy | `AgentProcess` fields + `handle()` loop (1 retry) + `IMPROVEMENT_POLICY` | test_runtime (contract tamper, refusal, quotas) | IMPL |

## S5 — Four nested self-improvement loops

| Loop | Implementation | Verified by | Status |
|---|---|---|---|
| Inner task loop (plan → execute → verify) | `AgentProcess.handle` | test_runtime | IMPL |
| Daily loop → improvement notes as tickets | `ImprovementProposerAgent` files SKILL/POLICY tickets from live metrics | demo ("improvement notes filed as tickets: 1") | IMPL |
| Harness co-evolution on sandbox siblings, frozen evaluator, held-out regimes (trend/range/high_vol/post_squeeze), significance + no-regime-regression gates | `HarnessEvolution.epoch`: asserts `evaluator.frozen`; `heldout_suites` fresh seeds; exact paired sign-flip test (α=0.05); regime-regression veto 0.15; goal-contract lint screen; git commit on promotion | test_improve.TestEpochGates (all four gates); demo epoch 0: promote p=0.0010, lint-reject, not-significant | IMPL |
| Verified sibling trajectories → training signal (SFT/pref/critic) + bounded adapter (ADAPTER-gated, clamped) | `_harvest_sibling_trajectories` (verified only) → `export_training_datasets`; `fit_adapter` → `bounded_adapter_update` (±0.25/epoch) → human-approved ADAPTER ticket → `apply_adapter` | test_improve.TestAdapter (verified-only + clamp + gate); demo (n_verified=310, v3) | IMPL/SUBST (real fine-tuning → distilled parameter table in the LoRA slot; datasets are produced for a real trainer) |
| Evaluator co-evolution: frozen per epoch; candidate must beat human ground truth; human-approved; selective erasure of stale scores | `Evaluator.freeze/set_param`, `GROUND_TRUTH` (8 archetypes), `gt_tau` Kendall, `EvaluatorEvolution.attempt/replace`, `Scoreboard.mark_stale` (raw kept for audit) | test_evaluate (immutability, GT gate, human gate, erasure); demo (τ 0.857→0.929, 2 erased) | IMPL |
| META-gated meta-improvement | `MetaQueue.propose_meta`; demo ratifies acceptance criteria via approved META ticket | test_improve.TestMetaQueue; demo T0009 | IMPL |

## S6 — Governance & safety

| Requirement | Implementation | Verified by | Status |
|---|---|---|---|
| Signed, machine-readable goal contracts | HMAC-signed `GoalContract`; tamper ⇒ agent refuses to run | test_governance.TestContracts; test_runtime.test_tampered_contract_rejected | IMPL |
| Scope router + handoffs with full context; no silent expansion | `ScopeRouter.route` records `Handoff` with payload + originator, audited | test_governance.TestScopeRouter; test_e2e.test_out_of_scope_task_handoff | IMPL |
| Quotas / sandboxes | `Quotas.spend` ⇒ suspension; `Sandbox` isolated dirs, `no_live` asserted | test_runtime.test_quota_suspension; test_improve | IMPL/SUBST (K8s/Docker → per-run sandbox directories + in-proc isolation) |
| Kill-switch circuit breakers: funding extreme; OI spike + price divergence; wiki conflict rate; evaluator score drop; human trip | `KillSwitch.evaluate` implements all four + `human_trip`; OI spike measured on one-step OI returns with warm-up guard; freeze cascades to scheduler, gateway, ticket application | test_governance.TestKillSwitch (each rule); drill + one organic trip w/ human ops review in demo | IMPL |
| Privilege ladder OUTPUT→MEMORY→SKILL→POLICY→ADAPTER→META; POLICY+ human-approved | `Priv` IntEnum; `APPROVAL_REQUIRED_AT=POLICY`; approvals/rejections/unfreeze require human role | test_governance.TestTickets/TestFreeze | IMPL |
| Never live capital without human confirmation | `ExecutionGateway`: live needs autonomy L3 **and** valid HMAC human token; L3 never granted | test_trading.TestGateway; demo probe (rejected, live_trades=0) | IMPL |

## S7 — Implementation stack & bootstrap

| Requirement | Implementation | Verified by | Status |
|---|---|---|---|
| Git harness repos | `HarnessRepo` uses real local git (v1..v3 commits in demo) | test_improve.TestRepo | IMPL |
| W&B-like experiment tracking | `ExperimentTracker` JSONL (every A/B logged with eval hash) | test_events; `run/state/experiments.jsonl` | SUBST |
| Neo4j-like KG store | in-proc graph + object store (see S3) | test_wiki | SUBST |
| LLM cores + tool calling; harness as code | `DeterministicCore` parses prompt directives (`[[EXTREME_DISCOUNT]]`) so prompt mutations change behavior; `ProviderCore` is the wired seam for a real LLM (raises offline) | test_improve (prompt diff changes harness), demo | SUBST (no network ⇒ rule-based core; provider seam documented) |
| TS/Python hybrid runtime (LangGraph/plugin kernel) | pure-Python custom scheduler with the same process semantics | test_runtime | SUBST |
| Bootstrap sequence: seed wiki → instantiate constellation → paper-only N cycles → enable sibling evolution → gradually raise autonomy | `bootstrap.seed_wiki` (4 seed pages) → 19 agents → 30-day L0 run → L1 (evolution) → L2 (adapters); every advance is a human-approved META ticket; L3 (live-eligible) never granted | demo sections in order; `advance_autonomy` | IMPL |

## S8 — Daily operational cycle (7 steps)

| Step | Implementation | Verified by | Status |
|---|---|---|---|
| 1 perception refresh · 2 research/analysis · 3 strategy proposals (entry/exit/size/risk/expected-edge) · 4 risk-gated paper execution · 5 improvement notes → tickets · 6 governance review · 7 curator overnight rebuild + enrich | `cycle.DailyCycle.run_day` dispatches in exactly this order per 8h period; `_proposal()` carries the full step-3 schema; step 6 also runs a human morning ops review that analyzes and resets any organic kill-switch trip | test_e2e (6-day deterministic run); demo daily table | IMPL |

## S9 — Metrics & invariants

| Requirement | Implementation | Demo result | Status |
|---|---|---|---|
| Risk-adjusted return, capture efficiency vs oracle, fp rate, drawdown | `SimResult.metrics` + `evaluate.live_metrics` | 30d: pnl −12,063 · fp 3.0% · capture 37.3% · maxDD 2.07% (incumbent, by design falls into traps) | IMPL |
| Compounding = gap-to-oracle closure across epochs | perfect-foresight `oracle_funding_pnl`; compounding measured on **net** pnl vs oracle (gross funding capture reported as diagnostic — it alone rewards entering squeeze prints and bleeding the gain back on whipsaw) | fresh world seed 8, oracle +809,974: v1 net −1.6% → v3 net +3.1% ⇒ **+4.7% of oracle bound closed**; fp 6.1%→0.0%; pnl −12,985→+24,771 | IMPL |
| Zero un-approved live trades | gateway counters | live_trades **0**, rejections 1 (forged-token probe) | IMPL |
| All kill-switch activations logged and analyzed | freeze events + human analyses in audit chain | 1 organic trip + 1 drill, both reset with logged analysis | IMPL |
| Tamper-evident audit of everything | hash-chained `EventLog.verify` | 1,666 events, chain OK; tamper test flips detection | IMPL |

## Documented substitutions (summary)

No network egress and an ephemeral filesystem in the build sandbox ⇒
exchange/on-chain/sentiment/RWA APIs → seeded synthetic drivers behind the
spec's driver interfaces; LLM provider → deterministic rule core +
`ProviderCore` seam; Neo4j → in-proc temporal graph + object store;
K8s/Docker sandboxes → isolated per-run directories with a `no_live`
invariant; W&B → local JSONL tracker; vector store → token index; real
fine-tuning → bounded adapter table fit from the exported SFT/pref/critic
datasets. Each slot is a single class/interface swap for production.
