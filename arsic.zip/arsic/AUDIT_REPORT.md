# ARSIC Audit Report

Scope: full build audit of the ARSIC reference implementation — unit and
end-to-end tests, a 30-day demo run, audit-chain verification, and the
spec-S9 invariants checklist. All numbers below are taken directly from
the actual run (`run/reports/RUN_REPORT.md`, `run/state/audit.jsonl`);
nothing is estimated.

## 1. Test suite

`python3 -m unittest discover -s tests` → **66 tests, 66 passed, 0 failed**
across 8 suites: events (hash chain + tamper detection), governance
(human-only approvals, freeze semantics, kill-switch rules, scope router,
contract lint), wiki (all five patch outcomes, arbiter queue, TTL
invalidation, surgical merge isolation, provenance trace), runtime/tools
(scope refusal + handoff, quota suspension, recursive spawn/report-up,
contract-tamper rejection, tool selftest gate, scope-denied calls),
trading (funding accrual sign, sizing caps, liquidation levels, frozen
gateway, live-trade rejection), improve (exact sign-flip p-values,
lint screen, unapproved-POLICY block, end-to-end promotion, verified-only
adapter fit with clamp, frozen-evaluator assertion, git commits), evaluate
(frozen immutability, ground-truth gate, selective erasure), and e2e
(deterministic 6-day system run, audit chain, zero live trades, dashboard
render).

Two real defects were found and fixed by the tests during this audit:
(1) `Harness.apply_diff` crashed on bare `topology` diff keys (used by
candidate C3); (2) the OI-spike circuit breaker false-positived during
statistical warm-up because it z-scored random-walk *levels* — it now
z-scores one-step OI returns with a ≥7-observation warm-up and a 3%
relative floor, still detecting genuine +25% shocks at ≈5σ.

## 2. Demo run verification (seed 7, 30 days, MAIN_SCHEDULE trend/range/high_vol/post_squeeze)

Paper phase (L0): final equity 987,937 (pnl −12,063), 33 closed
positions, fp 3.0%, gross funding capture 37.3%, maxDD 2.07%; 32
trajectories and 19 abstracted principles in the experience graph; one
organic kill-switch trip (`oi_spike_price_divergence`) froze trading for
the remainder of that day and was analyzed + reset at the next morning's
human ops review (both events in the audit chain). The incumbent harness
is deliberately permissive (z_cap=14) so it enters squeeze-trap prints —
this is the improvement target.

Epoch 0 harness co-evolution (evaluator sealed, hash f7180a1eface0fc7),
A/B on held-out suites (10 seeds × 4 regimes, exact paired sign-flip
test): "tighten extreme filter (+prompt directive)" **promoted** at
p=0.0010, mean score Δ=+1.094, no regime regression → committed to git as
v2 (a75c6af); "raise leverage to 5x" **lint-rejected** against the signed
goal contract before any A/B spend; "cross-venue precheck" (POLICY,
human-approved) **rejected as not significant** — demonstrating that the
statistical gate and the human gate act independently.

Adapter loop: 310 verified sibling trajectories exported as
sft/pref/critic JSONL; the fitted update was neutral (the promoted
sibling produced zero extreme-entry false positives, so
fp_rate_ext = 0) and was still carried through the full ADAPTER
governance path — ticket, human approval, ±0.25 clamp, git commit v3.

Evaluator co-evolution: candidate {w_fp:4, w_dd:3} beat the incumbent on
the human-curated ground truth (Kendall τ 0.857 → 0.929), passed a
human-approved POLICY ticket, replaced the incumbent
(f7180a1eface0fc7 → f7a00b998e0f17a3); selective erasure marked the 2
old-hash scores non-comparable while keeping raw entries for audit.

Kill-switch drill (crafted snapshot, |funding| = 2.1%/8h):
`funding_extreme` tripped → system frozen; scheduler dispatch returned
None (audited `frozen_skip`); gateway raised `Frozen`; applying an
approved improvement ticket raised `ContractError`; human reset with
logged analysis restored operation.

Live-trade probe: a live order with a forged token raised
`LiveTradeRejected`; a genuine token also fails below autonomy L3
(unit-tested). **live_trades = 0, live_rejections = 1.**

Compounding (S9), fresh out-of-sample world (seed 8, oracle bound
+809,974): v1 net-capture −1.6% (gross funding capture 38.4%, fp 6.1%,
pnl −12,985, new-eval score −0.159) → v3 net-capture +3.1% (gross 31.0%,
fp 0.0%, pnl +24,771, score +1.584). **Gap-to-oracle closed this epoch:
+4.7% of the oracle bound.** Note the metric is defined on *net* pnl vs
oracle: gross funding capture alone is higher for v1 precisely because it
enters squeeze prints and bleeds the gain back on whipsaw — reported as a
diagnostic, not the objective.

Meta path: META ticket T0009 (ratifying the α=0.05 + regime-non-regression
acceptance criteria) human-approved and applied.

## 3. Invariants checklist (from the run)

audit_chain_ok **True** (first_bad none) · audit_events **1,666** ·
`python3 -m arsic verify` re-check **OK** · live_trades **0** ·
live_rejections **1** · policy_plus_applied_all_human **True** ·
evaluator_frozen **True** (sealed successor) · conflicts_awaiting_arbiter
**0** · pending_tickets **1** (a POLICY improvement note left visibly in
the queue for human review — by design) · determinism: repeat run with
the same seed reproduces the daily equity/ops table exactly (test_e2e).

## 4. Known limitations

Synthetic seeded market data (regime dynamics and the squeeze-trap
mechanic are engineered, not historical); the analyst core is a
deterministic rule engine standing in the LLM slot (`ProviderCore` seam
raises offline); sandbox isolation is directory/process-level, not
container-level; "adapter fitting" distills parameters rather than
fine-tuning a model (the training datasets it exports are real and
usable); single-process, no true concurrency. Each substitution is
itemised with its production swap point in `COMPLIANCE_MATRIX.md`.

**Conclusion:** the architecture, all four improvement loops, and every
governance gate specified in S1–S9 are implemented, exercised end-to-end
in the demo, and covered by passing tests; deviations are environmental
substitutions only, each documented. This system is paper-trading
research tooling and is not suitable for live capital without real market
infrastructure, real-data validation, and independent review.
