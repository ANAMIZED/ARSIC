"""ARSIC Governance & Safety Plane (spec S1, S6). Immutable from inside:
agents can only file tickets; approvals for POLICY+ require the human role,
and freeze/unfreeze of the whole system is externally controlled.

Components: GoalContract (signed, machine-readable), privilege ladder
(OUTPUT<MEMORY<SKILL<POLICY<ADAPTER<META), ApprovalQueue, KillSwitch with the
four named circuit breakers + human trigger, ScopeRouter with handoffs, and
contract linting for candidate harnesses.
"""
from __future__ import annotations

import hmac
import hashlib
import itertools
from dataclasses import dataclass, field, asdict
from enum import IntEnum
from typing import Callable, Optional

from .events import EventLog, canon


class Priv(IntEnum):
    """S6: levels of improvement with increasing privilege requirements."""
    OUTPUT = 0
    MEMORY = 1
    SKILL = 2
    POLICY = 3
    ADAPTER = 4
    META = 5


APPROVAL_REQUIRED_AT = Priv.POLICY  # POLICY / ADAPTER / META need human approval


@dataclass
class GoalContract:
    """S6: signed, machine-readable goal contract."""
    principal: str
    objective: str
    constraints: dict          # e.g. max_drawdown, max_leverage, min_liq_score, paper_only
    scopes: tuple              # scope tags this principal may act in
    contract_id: str = ""
    signature: str = ""

    def payload(self) -> dict:
        d = asdict(self)
        d.pop("signature", None)
        return d


class ContractError(Exception):
    pass


class Frozen(Exception):
    pass


@dataclass
class Ticket:
    tid: str
    level: int
    title: str
    payload: dict
    actor: str
    status: str = "pending"     # pending | approved | rejected | applied
    approver: str = ""


@dataclass
class Handoff:
    task_id: str
    from_agent: str
    reason: str
    context: dict


class Governance:
    """Holds the signing secret, the audit log, the approval queue and the
    global freeze flag. Nothing inside the constellation can mint approvals."""

    def __init__(self, secret: str, audit: EventLog):
        self._secret = secret.encode()
        self.audit = audit
        self.tickets: dict[str, Ticket] = {}
        self._tid = itertools.count(1)
        self.frozen = False
        self.freeze_reasons: list[dict] = []
        self._freeze_hooks: list[Callable[[bool, str], None]] = []
        self.autonomy_level = 0    # L0 paper-only .. raised only via approved tickets
        self.last_epoch_score: Optional[float] = None

    # -- contracts ---------------------------------------------------------
    def sign_contract(self, c: GoalContract) -> GoalContract:
        c.contract_id = hashlib.sha256(canon(c.payload()).encode()).hexdigest()[:16]
        c.signature = hmac.new(self._secret, canon(c.payload()).encode(),
                               hashlib.sha256).hexdigest()
        self.audit.append("contract.signed", {"contract_id": c.contract_id,
                                              "principal": c.principal}, "governance")
        return c

    def verify_contract(self, c: GoalContract) -> bool:
        want = hmac.new(self._secret, canon(c.payload()).encode(),
                        hashlib.sha256).hexdigest()
        return hmac.compare_digest(want, c.signature)

    def human_token(self, purpose: str) -> str:
        """Only mintable here — represents explicit human confirmation (S6:
        'never recommend live capital without human confirmation')."""
        return hmac.new(self._secret, f"HUMAN::{purpose}".encode(),
                        hashlib.sha256).hexdigest()

    def check_human_token(self, purpose: str, token: str) -> bool:
        return hmac.compare_digest(self.human_token(purpose), token or "")

    # -- change control ----------------------------------------------------
    def request(self, level: Priv, title: str, payload: dict, actor: str) -> Ticket:
        t = Ticket(tid=f"T{next(self._tid):04d}", level=int(level), title=title,
                   payload=payload, actor=actor)
        if level < APPROVAL_REQUIRED_AT:
            t.status = "approved"
            t.approver = "auto:<policy-threshold"
        self.tickets[t.tid] = t
        self.audit.append("ticket.filed", {"tid": t.tid, "level": int(level),
                                           "title": title, "status": t.status}, actor)
        return t

    def approve(self, tid: str, actor_role: str, actor: str = "human:cli") -> Ticket:
        if actor_role != "human":
            self.audit.append("ticket.approve_denied", {"tid": tid, "by": actor}, actor)
            raise ContractError("POLICY+ approvals require the human role")
        t = self.tickets[tid]
        t.status, t.approver = "approved", actor
        self.audit.append("ticket.approved", {"tid": tid, "by": actor}, actor)
        return t

    def reject(self, tid: str, actor_role: str, actor: str = "human:cli") -> Ticket:
        if actor_role != "human":
            raise ContractError("POLICY+ rejections require the human role")
        t = self.tickets[tid]
        t.status, t.approver = "rejected", actor
        self.audit.append("ticket.rejected", {"tid": tid, "by": actor}, actor)
        return t

    def is_executable(self, t: Ticket) -> bool:
        return t.status == "approved" and not self.frozen

    def mark_applied(self, t: Ticket) -> None:
        if not self.is_executable(t):
            raise ContractError(f"ticket {t.tid} not executable (status={t.status}, frozen={self.frozen})")
        t.status = "applied"
        self.audit.append("ticket.applied", {"tid": t.tid, "title": t.title}, "governance")

    def pending(self) -> list[Ticket]:
        return [t for t in self.tickets.values() if t.status == "pending"]

    # -- freeze / kill-switch plumbing ------------------------------------
    def on_freeze(self, hook: Callable[[bool, str], None]) -> None:
        self._freeze_hooks.append(hook)

    def freeze(self, reason: str, source: str) -> None:
        self.frozen = True
        rec = {"reason": reason, "source": source}
        self.freeze_reasons.append(rec)
        self.audit.append("killswitch.tripped", rec, source)
        for h in self._freeze_hooks:
            h(True, reason)

    def unfreeze(self, actor_role: str, analysis: str, actor: str = "human:cli") -> None:
        if actor_role != "human":
            raise ContractError("unfreeze requires the human role")
        self.frozen = False
        # S9: all kill-switch activations logged AND analyzed.
        self.audit.append("killswitch.reset", {"analysis": analysis, "by": actor}, actor)
        for h in self._freeze_hooks:
            h(False, "reset")


class KillSwitch:
    """S6: external human or rule-based circuit breakers. Rules (verbatim from
    spec): funding extreme > threshold; OI spike + price divergence; wiki
    conflict rate; evaluator score drop. Plus explicit human trip."""

    def __init__(self, gov: Governance, cfg: Optional[dict] = None):
        self.gov = gov
        self.cfg = {"funding_abs_max": 0.015,        # per 8h period
                    "oi_spike_z": 3.0,
                    "wiki_conflict_rate_max": 0.20,
                    "evaluator_drop_frac": 0.30, **(cfg or {})}

    def evaluate(self, snap: dict) -> list[str]:
        c, hit = self.cfg, []
        if abs(snap.get("max_abs_funding", 0.0)) > c["funding_abs_max"]:
            hit.append("funding_extreme")
        if snap.get("oi_z", 0.0) > c["oi_spike_z"] and snap.get("price_divergence", False):
            hit.append("oi_spike_price_divergence")
        if snap.get("wiki_conflict_rate", 0.0) > c["wiki_conflict_rate_max"]:
            hit.append("wiki_conflict_rate")
        last, cur = self.gov.last_epoch_score, snap.get("evaluator_score")
        if last is not None and cur is not None and last > 0 and \
                (last - cur) / abs(last) > c["evaluator_drop_frac"]:
            hit.append("evaluator_score_drop")
        if hit and not self.gov.frozen:
            self.gov.freeze("|".join(hit), "killswitch")
        return hit

    def human_trip(self, reason: str) -> None:
        self.gov.freeze(f"human:{reason}", "human")


class ScopeRouter:
    """S6: out-of-scope tasks are transferred with full context; no silent
    expansion. check() is consulted by every agent before accepting work."""

    def __init__(self, audit: EventLog):
        self.audit = audit
        self.registry: dict[str, set] = {}
        self.handoffs: list[Handoff] = []

    def register(self, agent_id: str, scopes: set) -> None:
        self.registry[agent_id] = set(scopes)

    def check(self, agent_id: str, task_scopes: set) -> bool:
        return bool(set(task_scopes) & self.registry.get(agent_id, set()))

    def route(self, task_id: str, task_scopes: set, context: dict,
              from_agent: str = "") -> Optional[str]:
        for aid, sc in self.registry.items():
            if set(task_scopes) & sc:
                return aid
        h = Handoff(task_id=task_id, from_agent=from_agent,
                    reason="no in-scope agent", context=context)
        self.handoffs.append(h)
        self.audit.append("router.handoff", asdict(h), "router")
        return None


def lint_against_contract(strategy_params: dict, contract: GoalContract) -> list[str]:
    """Screen candidate harnesses against the signed goal contract before any
    A/B run (S6 goal contracts bind the improvement loop too)."""
    v = []
    c = contract.constraints
    if strategy_params.get("max_leverage", 0) > c.get("max_leverage", 3):
        v.append(f"max_leverage {strategy_params.get('max_leverage')} > contract {c.get('max_leverage')}")
    if strategy_params.get("dd_budget", 0) > c.get("max_drawdown", 0.10):
        v.append("dd_budget exceeds contract max_drawdown")
    if not c.get("paper_only", True) and not strategy_params.get("live_ack", False):
        v.append("live trading not contractually enabled")
    if strategy_params.get("min_liq_score", 1.0) < c.get("min_liq_score", 0.3):
        v.append("min_liq_score below contract liquidity floor")
    return v
