"""ARSIC validated tool registry (spec S4). Agents never touch raw disk or
external APIs directly (S2): every driver is wrapped as a Tool with (a) scope
requirements and (b) self-tests that must pass at registration time.
Every call is quota-charged and audited."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .events import EventLog


class ToolError(Exception):
    pass


@dataclass
class Tool:
    name: str
    fn: Callable
    scopes: set                     # caller must hold at least one
    selftests: list = field(default_factory=list)


class ToolRegistry:
    def __init__(self, audit: EventLog):
        self.audit = audit
        self._tools: dict[str, Tool] = {}
        self.rejected: list[str] = []

    def register(self, tool: Tool) -> bool:
        """Only tools that pass unit tests and scope checks are registered."""
        if not tool.scopes:
            self.rejected.append(tool.name)
            self.audit.append("tool.rejected", {"name": tool.name,
                                                "why": "no scopes"}, "registry")
            return False
        for i, t in enumerate(tool.selftests):
            try:
                assert t() is not False
            except Exception as e:                     # noqa: BLE001
                self.rejected.append(tool.name)
                self.audit.append("tool.rejected", {"name": tool.name,
                                                    "why": f"selftest[{i}]: {e}"},
                                  "registry")
                return False
        self._tools[tool.name] = tool
        self.audit.append("tool.registered", {"name": tool.name,
                                              "scopes": sorted(tool.scopes)}, "registry")
        return True

    def call(self, agent, name: str, *args, **kwargs):
        tool = self._tools.get(name)
        if tool is None:
            raise ToolError(f"tool '{name}' is not registered/validated")
        if not (set(agent.scopes) & tool.scopes):
            self.audit.append("tool.scope_denied", {"agent": agent.id,
                                                    "tool": name}, agent.id)
            raise ToolError(f"agent '{agent.id}' lacks scope for tool '{name}'")
        agent.quotas.spend("tool_calls")
        self.audit.append("tool.call", {"agent": agent.id, "tool": name}, agent.id)
        return tool.fn(*args, **kwargs)

    def names(self) -> list[str]:
        return sorted(self._tools)
