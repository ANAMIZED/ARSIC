"""ARSIC Experience Graph (spec S3, EXG-style).

Nodes = full Perception -> Agents -> Strategy -> Outcome trajectories.
Edges link 'what was tried' -> 'why it worked/failed' -> abstracted principles.
Used for (a) retrieval of analogous past regimes and (b) self-improvement
signal / training datasets (S5 verified trajectories -> SFT/pref/critic data).
"""
from __future__ import annotations

import itertools
import json
import math
import os
from dataclasses import dataclass, field, asdict
from typing import Optional

from .events import EventLog, canon


@dataclass
class Trajectory:
    tid: str
    run_id: str
    regime: str
    features: dict            # e.g. {'funding': .., 'z': .., 'streak': .., 'liq': ..}
    actions: list             # ordered decisions taken
    outcome: dict             # {'pnl': .., 'funding_pnl': .., 'fp': bool, ...}
    verified: bool = False    # verifier-passed (only these become training signal)


@dataclass
class Principle:
    pid: str
    text: str
    support: list             # trajectory ids


class ExperienceGraph:
    def __init__(self, audit: EventLog):
        self.audit = audit
        self.traj: dict[str, Trajectory] = {}
        self.principles: dict[str, Principle] = {}
        self.links: list[tuple] = []          # (tid, 'supports', pid)
        self._i = itertools.count(1)

    def add(self, t: Trajectory) -> str:
        if not t.tid:
            t.tid = f"X{next(self._i):05d}"
        self.traj[t.tid] = t
        self.audit.append("exg.trajectory", {"tid": t.tid, "regime": t.regime,
                                             "verified": t.verified,
                                             "pnl": t.outcome.get("pnl")}, "exg")
        return t.tid

    def add_principle(self, text: str, support: list) -> str:
        pid = f"PR{next(self._i):04d}"
        self.principles[pid] = Principle(pid=pid, text=text, support=list(support))
        for tid in support:
            self.links.append((tid, "supports", pid))
        self.audit.append("exg.principle", {"pid": pid, "text": text,
                                            "n_support": len(support)}, "exg")
        return pid

    @staticmethod
    def _vec(features: dict, regime: str) -> list[float]:
        regimes = ["trend", "range", "high_vol", "post_squeeze"]
        v = [1.0 if regime == r else 0.0 for r in regimes]
        v += [float(features.get(k, 0.0)) for k in ("funding", "z", "streak", "liq")]
        return v

    def analogous(self, features: dict, regime: str, k: int = 3) -> list[Trajectory]:
        """Retrieve analogous past regimes by cosine similarity on a small
        feature vector (regime one-hot + market stats)."""
        q = self._vec(features, regime)
        scored = []
        for t in self.traj.values():
            v = self._vec(t.features, t.regime)
            dot = sum(a * b for a, b in zip(q, v))
            na = math.sqrt(sum(a * a for a in q)) or 1e-9
            nb = math.sqrt(sum(b * b for b in v)) or 1e-9
            scored.append((dot / (na * nb), t.tid))
        scored.sort(reverse=True)
        return [self.traj[tid] for _, tid in scored[:k]]

    def verified_trajectories(self) -> list[Trajectory]:
        return [t for t in self.traj.values() if t.verified]

    # -- S5: verified trajectories become training signal ------------------
    def export_training_datasets(self, out_dir: str) -> dict:
        os.makedirs(out_dir, exist_ok=True)
        vt = self.verified_trajectories()
        paths = {k: os.path.join(out_dir, f"{k}.jsonl") for k in ("sft", "pref", "critic")}
        with open(paths["sft"], "w") as f:
            for t in vt:
                if t.outcome.get("pnl", 0) > 0:
                    f.write(canon({"state": t.features, "regime": t.regime,
                                   "action": t.actions}) + "\n")
        wins = [t for t in vt if t.outcome.get("pnl", 0) > 0]
        losses = [t for t in vt if t.outcome.get("pnl", 0) <= 0]
        with open(paths["pref"], "w") as f:
            for w, l in zip(wins, losses):
                f.write(canon({"chosen": {"state": w.features, "action": w.actions},
                               "rejected": {"state": l.features, "action": l.actions}}) + "\n")
        with open(paths["critic"], "w") as f:
            for t in vt:
                f.write(canon({"state": t.features, "regime": t.regime,
                               "score": t.outcome.get("pnl", 0.0),
                               "fp": bool(t.outcome.get("fp", False))}) + "\n")
        self.audit.append("exg.datasets", {"n_verified": len(vt), **paths}, "exg")
        return paths
