"""ARSIC Knowledge Wiki Substrate (spec S3) — the 'disk' of the OS.

- TemporalKG: entities + typed edges, each carrying provenance, timestamp,
  confidence and invalidation rules (TTL).
- Gated write path: only authenticated Patches mutate state; five outcomes per
  claim: insert / merge / relate / conflict / reject. Conflicts go to an
  arbiter queue (human or high-privilege arbiter).
- WikiPages: compiled markdown pages (read agents hit these, not the raw
  firehose), daily rebuild + surgical merge, token retrieval index.
- Audit surface: every claim traceable to page + source hash (trace()).
"""
from __future__ import annotations

import itertools
import re
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Optional

from .events import EventLog, ObjectStore, sha


@dataclass
class Provenance:
    source_id: str
    source_hash: str


@dataclass
class Claim:
    subject: str            # entity id, e.g. 'binance:BTC-USDT-PERP'
    predicate: str          # e.g. 'funding_rate_at', 'basis_vs_spot', 'narrative_velocity'
    value: Any
    ts: float
    confidence: float
    prov: Provenance
    ttl: Optional[float] = None      # invalidation rule: seconds of validity
    relation: bool = False           # True => value is another entity id (typed edge)
    cid: str = ""

    def __post_init__(self):
        if not self.cid:
            self.cid = sha([self.subject, self.predicate, self.value, self.ts,
                            self.prov.source_id])[:16]


@dataclass
class Patch:
    pid: str
    claims: list
    actor: str
    scope: str


# subject-prefix -> writer scopes allowed (gated write path)
WRITE_ACL = {
    "market:":   {"perception.market"},
    "onchain:":  {"perception.onchain"},
    "sent:":     {"perception.sentiment"},
    "rwa:":      {"perception.rwa"},
    "analysis:": {"research.analysis"},
    "strategy:": {"strategy.write"},
    "meta:":     {"meta.write", "research.analysis"},
    "seed:":     {"governance.seed"},
}

CONFLICT_REL_TOL = 0.25       # relative divergence that flags a conflict
CONFLICT_WINDOW_S = 3600.0    # claims about ~the same time


class TemporalKG:
    def __init__(self, audit: EventLog, store: ObjectStore):
        self.audit = audit
        self.store = store
        self.edges: dict[tuple, list[dict]] = {}
        self.entities: set[str] = set()
        self.arbiter_queue: list[dict] = []
        self._pid = itertools.count(1)
        self._recent_outcomes: list[str] = []   # rolling window for conflict-rate breaker

    def new_patch(self, claims: list[Claim], actor: str, scope: str) -> Patch:
        return Patch(pid=f"P{next(self._pid):05d}", claims=claims, actor=actor, scope=scope)

    def _allowed(self, subject: str, scope: str) -> bool:
        for pref, scopes in WRITE_ACL.items():
            if subject.startswith(pref):
                return scope in scopes
        return False

    def apply(self, patch: Patch, now: Optional[float] = None) -> list[tuple]:
        """Gated write path. Returns [(cid, outcome)]; outcome in
        {insert, merge, relate, conflict, reject}."""
        now = now or time.time()
        out = []
        for c in patch.claims:
            outcome = self._apply_claim(c, patch, now)
            out.append((c.cid, outcome))
            self._recent_outcomes.append(outcome)
        self._recent_outcomes = self._recent_outcomes[-500:]
        self.audit.append("wiki.patch", {"pid": patch.pid, "actor": patch.actor,
                                         "outcomes": out}, patch.actor)
        return out

    def _apply_claim(self, c: Claim, patch: Patch, now: float) -> str:
        # -- validation -> reject
        if not (0.0 <= c.confidence <= 1.0) or not c.prov.source_hash \
                or not self._allowed(c.subject, patch.scope):
            return "reject"
        key = (c.subject, c.predicate)
        rec = {"value": c.value, "ts": c.ts, "conf": c.confidence,
               "prov": asdict(c.prov), "cid": c.cid,
               "valid_until": (c.ts + c.ttl) if c.ttl else None,
               "src_key": self.store.put({"claim": asdict(c)})}
        self.entities.add(c.subject)
        if c.relation:
            self.entities.add(str(c.value))
            self.edges.setdefault(key, []).append(rec)
            return "relate"
        hist = self.edges.get(key)
        if not hist:
            self.edges[key] = [rec]
            return "insert"
        latest = hist[-1]
        same_src = latest["prov"]["source_id"] == c.prov.source_id
        close_t = abs(latest["ts"] - c.ts) <= CONFLICT_WINDOW_S
        diverges = _diverges(latest["value"], c.value)
        if (not same_src) and close_t and diverges \
                and latest["conf"] >= 0.6 and c.confidence >= 0.6:
            item = {"key": key, "incumbent": latest, "challenger": rec}
            self.arbiter_queue.append(item)      # canonical value untouched
            self.audit.append("wiki.conflict", {"key": list(key)}, patch.actor)
            return "conflict"
        hist.append(rec)                          # merge: newer canonical, history kept
        return "merge"

    def latest(self, subject: str, predicate: str, at: Optional[float] = None):
        hist = self.edges.get((subject, predicate), [])
        best = None
        for r in hist:
            if at is not None and r["ts"] > at:
                continue
            if r["valid_until"] is not None and (at or time.time()) > r["valid_until"]:
                continue
            if best is None or r["ts"] >= best["ts"]:
                best = r
        return best

    def history(self, subject: str, predicate: str) -> list[dict]:
        return list(self.edges.get((subject, predicate), []))

    def sweep_invalidation(self, now: Optional[float] = None) -> int:
        """Apply invalidation rules: drop expired edge records."""
        now = now or time.time()
        n = 0
        for key, hist in self.edges.items():
            keep = [r for r in hist if r["valid_until"] is None or r["valid_until"] >= now]
            n += len(hist) - len(keep)
            self.edges[key] = keep
        if n:
            self.audit.append("wiki.invalidation_sweep", {"expired": n}, "curator")
        return n

    def conflict_rate(self) -> float:
        w = self._recent_outcomes
        return (w.count("conflict") / len(w)) if w else 0.0

    def resolve_conflict(self, idx: int, pick: str, actor_role: str,
                         actor: str = "human:cli") -> None:
        """Arbiter resolution (human or high-privilege arbiter)."""
        if actor_role not in ("human", "arbiter"):
            raise PermissionError("conflict resolution requires human/arbiter role")
        item = self.arbiter_queue.pop(idx)
        chosen = item[pick]
        self.edges.setdefault(tuple(item["key"]), []).append(chosen)
        self.audit.append("wiki.conflict_resolved",
                          {"key": list(item["key"]), "pick": pick}, actor)


def _diverges(a: Any, b: Any) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        base = max(abs(a), abs(b), 1e-9)
        return abs(a - b) / base > CONFLICT_REL_TOL
    return a != b


class WikiPages:
    """Compiled wiki pages (S3): auto-generated at ingest; queries hit the wiki,
    not the original firehose. Daily rebuild + surgical merge on change."""

    def __init__(self, kg: TemporalKG, audit: EventLog):
        self.kg = kg
        self.audit = audit
        self.pages: dict[str, dict] = {}       # name -> {md, hash, version, ts}
        self._claim_page: dict[str, str] = {}  # cid -> page name

    def _render(self, entity: str, now: float) -> str:
        rows = []
        for (s, p), hist in sorted(self.kg.edges.items()):
            if s != entity or not hist:
                continue
            r = hist[-1]
            self._claim_page[r["cid"]] = entity
            rows.append(f"| {p} | {r['value']} | {r['conf']:.2f} | "
                        f"{r['prov']['source_id']} | `{r['prov']['source_hash'][:10]}` |")
        body = "\n".join(rows) if rows else "| (no facts) | | | | |"
        return (f"# {entity}\n\ncompiled: {now:.0f}\n\n"
                f"| predicate | value | conf | source | source_hash |\n"
                f"|---|---|---|---|---|\n{body}\n")

    def compile_all(self, now: Optional[float] = None) -> int:
        """Daily rebuild: regenerate every page from the KG."""
        now = now or time.time()
        for e in sorted(self.kg.entities):
            self._write(e, now)
        self.audit.append("wiki.rebuild", {"pages": len(self.pages)}, "curator")
        return len(self.pages)

    def surgical(self, entity: str, now: Optional[float] = None) -> str:
        """Surgical merge on change: rebuild exactly one page."""
        now = now or time.time()
        h = self._write(entity, now)
        self.audit.append("wiki.surgical_merge", {"page": entity}, "curator")
        return h

    def seed(self, name: str, md: str) -> None:
        self.pages[name] = {"md": md, "hash": sha(md), "version": 1, "ts": time.time()}

    def _write(self, entity: str, now: float) -> str:
        md = self._render(entity, now)
        h = sha(md)
        prev = self.pages.get(entity)
        version = (prev["version"] + 1) if prev and prev["hash"] != h else \
                  (prev["version"] if prev else 1)
        self.pages[entity] = {"md": md, "hash": h, "version": version, "ts": now}
        return h

    def search(self, query: str, k: int = 3) -> list[str]:
        """Token-overlap retrieval (vector-store slot documented in matrix)."""
        q = set(re.findall(r"[a-z0-9\-:]+", query.lower()))
        scored = []
        for name, pg in self.pages.items():
            toks = set(re.findall(r"[a-z0-9\-:]+", (name + " " + pg["md"]).lower()))
            s = len(q & toks)
            if s:
                scored.append((s, name))
        return [n for _, n in sorted(scored, reverse=True)[:k]]

    def trace(self, cid: str) -> Optional[dict]:
        """S3 audit surface: every claim that influences a live strategy is
        traceable to a wiki page + source hash."""
        for (s, p), hist in self.kg.edges.items():
            for r in hist:
                if r["cid"] == cid:
                    return {"page": self._claim_page.get(cid, s), "subject": s,
                            "predicate": p, "prov": r["prov"], "src_key": r["src_key"]}
        return None

    def freshness(self, now: Optional[float] = None, horizon_s: float = 86400.0) -> float:
        now = now or time.time()
        if not self.pages:
            return 0.0
        fresh = sum(1 for p in self.pages.values() if now - p["ts"] <= horizon_s)
        return fresh / len(self.pages)
