"""ARSIC Execution & Risk agents' machinery (spec S4).

PaperBroker: delta-neutral two-leg positions (perp vs spot); accrues funding
transfers each 8h period, marks premium moves, charges fees/slippage, tracks
the equity curve and drawdown.

PositionSizer: enforces the signed goal contract (max leverage, liquidity
floor, drawdown budget).

LiquidationMonitor: margin-distance checks -> ok / warn / reduce.

ExecutionGateway: the ONLY path to submit orders. Paper by default; a live
order requires a governance-minted human token (S6: 'never recommend live
capital without human confirmation'); rejects everything while frozen.
S9 invariant: zero un-approved live trades — counted here."""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Optional

from .events import EventLog
from .governance import Governance, GoalContract, Frozen
from .strategy_math import COST_ROUNDTRIP
from .perception import Tick


class LiveTradeRejected(Exception):
    pass


class RiskVeto(Exception):
    pass


@dataclass
class Position:
    pid: str
    key: str
    side: int                  # +1 short perp/long spot ; -1 long perp/short spot
    notional: float
    leverage: float
    entry_ts: tuple
    entry_premium: float
    entry_stats: dict
    funding_pnl: float = 0.0
    mtm: float = 0.0
    fees: float = 0.0
    hold: int = 0
    flip_count: int = 0
    open: bool = True
    extreme_entry: bool = False

    @property
    def net(self) -> float:
        return self.funding_pnl + self.mtm - self.fees


class PaperBroker:
    def __init__(self, audit: EventLog, equity0: float = 1_000_000.0):
        self.audit = audit
        self.equity0 = equity0
        self.equity = equity0
        self.curve = [equity0]
        self.positions: dict[str, Position] = {}
        self.closed: list[Position] = []
        self._i = itertools.count(1)

    def open_pos(self, key: str, side: int, notional: float, leverage: float,
                 tick: Tick, stats: dict, extreme: bool) -> Position:
        cost = COST_ROUNDTRIP / 2 * notional
        p = Position(pid=f"POS{next(self._i):04d}", key=key, side=side,
                     notional=notional, leverage=leverage,
                     entry_ts=(tick.day, tick.period), entry_premium=tick.premium,
                     entry_stats=stats, fees=cost, extreme_entry=extreme)
        self.equity -= cost
        self.positions[key] = p
        self.audit.append("paper.open", {"pid": p.pid, "key": key, "side": side,
                                         "notional": round(notional, 2)}, "broker")
        return p

    def on_period(self, ticks: dict) -> None:
        for key, p in self.positions.items():
            t = ticks.get(key)
            if t is None:
                continue
            pay = p.side * t.funding * p.notional          # funding transfer
            p.funding_pnl += pay
            last = p.entry_stats.get("_last_premium", p.entry_premium)
            m = -p.side * (t.premium - last) * p.notional  # premium MTM (delta-neutral legs)
            p.mtm += m
            p.entry_stats["_last_premium"] = t.premium
            p.hold += 1
            self.equity += pay + m
        self.curve.append(self.equity)

    def close(self, key: str) -> Position:
        p = self.positions.pop(key)
        cost = COST_ROUNDTRIP / 2 * p.notional
        p.fees += cost
        self.equity -= cost
        p.open = False
        self.closed.append(p)
        self.curve.append(self.equity)
        self.audit.append("paper.close", {"pid": p.pid, "net": round(p.net, 2)},
                          "broker")
        return p

    def flatten_all(self) -> None:
        for key in list(self.positions):
            self.close(key)

    def max_dd(self) -> float:
        peak, mdd = self.curve[0], 0.0
        for e in self.curve:
            peak = max(peak, e)
            mdd = max(mdd, (peak - e) / peak)
        return mdd


class PositionSizer:
    def __init__(self, contract: GoalContract):
        self.c = contract.constraints

    def size(self, edge: float, liq_score: float, oi: float, equity: float) -> tuple:
        if liq_score < self.c.get("min_liq_score", 0.3):
            raise RiskVeto("liquidity below contract floor")
        lev = min(self.c.get("max_leverage", 3.0), 2.0)
        notional = min(equity * 0.10,                 # risk budget slice
                       equity * lev * 0.5,           # leverage headroom
                       oi * 0.001)                   # ADV/OI participation cap
        return max(0.0, notional), lev


class LiquidationMonitor:
    """Maintenance-margin distance on the perp leg (S4 liquidation monitor)."""

    def __init__(self, maint: float = 0.05):
        self.maint = maint

    def assess(self, p: Position, premium_now: float) -> str:
        capacity = max(1e-9, 1.0 / p.leverage - self.maint)
        adverse = p.side * (premium_now - p.entry_premium)   # premium moving against
        frac = max(0.0, adverse) / capacity
        if frac > 0.9:
            return "reduce"
        if frac > 0.6:
            return "warn"
        return "ok"


class ExecutionGateway:
    def __init__(self, broker: PaperBroker, governance: Governance):
        self.broker = broker
        self.gov = governance
        self.live_trades = 0
        self.live_rejections = 0
        self.l3 = None                # S11: human-lent mandate session

    def submit(self, key: str, side: int, notional: float, leverage: float,
               tick: Tick, stats: dict, extreme: bool,
               live: bool = False, human_token: str = "",
               _approved_oid: str | None = None) -> Position:
        if self.gov.frozen:
            self.gov.audit.append("exec.rejected_frozen", {"key": key}, "gateway")
            raise Frozen("kill-switch active: trading loop frozen")
        ses = self.l3
        mandate_live = bool(ses and ses.active(tick.day) and
                            getattr(ses.mandate, "status", "") == "active")
        if mandate_live and not live:
            live = True               # session upgrades the paper path
        if live:
            if mandate_live:
                # S11: the ladder still refuses; a human MANDATE lends L3.
                # RiskGate + mandate-scoped token; HITL may queue instead.
                tick, notional, extra_fee = ses.route(
                    key, side, notional, leverage, tick, stats, extreme,
                    human_token, _approved_oid)
                self.live_trades += 1
                p = self.broker.open_pos(key, side, notional, leverage,
                                         tick, stats, extreme)
                p.fees += extra_fee
                self.broker.equity -= extra_fee
                return p
            if self.gov.autonomy_level < 3 or \
                    not self.gov.check_human_token(f"live:{key}", human_token):
                self.live_rejections += 1
                self.gov.audit.append("exec.live_rejected",
                                      {"key": key, "why": "no human confirmation"},
                                      "gateway")
                raise LiveTradeRejected("live capital requires human confirmation")
            self.live_trades += 1     # unreachable: the ladder never grants L3
        return self.broker.open_pos(key, side, notional, leverage, tick, stats, extreme)
