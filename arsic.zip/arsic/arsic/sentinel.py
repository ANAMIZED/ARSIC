"""Independent risk sentinel — the out-of-process circuit breaker.

Runs as a SEPARATE process with its OWN venue credentials (cancel/read
scope only — it can never place an order). It observes the ARSIC backend
over HTTP and enforces its own limits with an escalation ladder:

  1. Limit breach while ARSIC is reachable → ask ARSIC to trip its own
     kill-switch (one grace cycle to flatten itself).
  2. Breach persists, OR the runtime stalls/goes unreachable past the
     dead-man window while the venue still holds risk → the sentinel
     flattens VENUE-SIDE directly with its own credentials. This path does
     not depend on the ARSIC runtime in any way: a hung, stopped, or dead
     ARSIC process cannot prevent it.

When ARSIC comes back, its own reconciliation detects the out-of-band
flatten, trips the breaker, and revokes the mandate — the loop closes from
both sides. Every sentinel decision is logged locally and (best-effort)
pinged to the backend so the console can display sentinel liveness.
"""
from __future__ import annotations

import argparse
import json
import os
import time
import urllib.error
import urllib.request

from .venue_client import VenueClient


class Sentinel:
    def __init__(self, api_url: str, venue_url: str, venue_key: str,
                 venue_secret: str, deadman_s: float = 3.0,
                 max_gross: float | None = None,
                 loss_cap: float | None = None, poll_s: float = 0.5):
        self.api = api_url.rstrip("/")
        self.venue = VenueClient(venue_url, venue_key, venue_secret,
                                 timeout=1.0, max_retries=1,
                                 backoff_s=0.02)
        self.deadman_s = deadman_s
        self.max_gross = max_gross
        self.loss_cap = loss_cap
        self.poll_s = poll_s
        self.last_seq = None
        self.last_progress = time.time()
        self.day = None
        self.day_equity0 = None
        self.breach_warned = False
        self.log: list[dict] = []
        self.acted: list[dict] = []

    # ---------------- plumbing ----------------
    def _api(self, path: str, body: dict | None = None, timeout=1.0):
        req = urllib.request.Request(
            self.api + path,
            data=json.dumps(body).encode() if body is not None else None,
            headers={"Content-Type": "application/json"},
            method="POST" if body is not None else "GET")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())

    def _ping(self, status: str, detail: str = ""):
        try:
            self._api("/api/sentinel/ping",
                      {"status": status, "detail": detail,
                       "acted": len(self.acted)}, timeout=0.8)
        except Exception:                    # noqa: BLE001 — best-effort
            pass

    def _flatten(self, reason: str) -> str:
        r = self.venue.cancel_all()          # OWN credentials, venue-direct
        act = {"ts": time.time(), "reason": reason,
               "closed": r.get("closed", 0)}
        self.acted.append(act)
        try:
            self._api("/api/killswitch/trip",
                      {"reason": f"sentinel flatten: {reason}"})
        except Exception:                    # noqa: BLE001
            pass                             # runtime absent — venue is flat
        return f"venue_cancel_all:{reason}:closed={act['closed']}"

    # ---------------- one observation/enforcement pass ----------------
    def check(self, now: float | None = None) -> dict:
        now = now or time.time()
        rec: dict = {"ts": round(now, 3)}
        try:
            st = self._api("/api/state")
            snap = st["snapshot"]
            seq = st.get("cursor", snap.get("auditCount"))
            if seq != self.last_seq:
                self.last_seq = seq
                self.last_progress = now
            eq = snap.get("equity")
            if snap.get("day") != self.day:
                self.day = snap.get("day")
                self.day_equity0 = eq
            day_loss = ((self.day_equity0 - eq)
                        if (eq is not None and
                            self.day_equity0 is not None) else 0.0)
            l3 = snap.get("l3") or {}
            gross = (l3.get("used") or {}).get("gross", 0.0)
            active = bool(l3.get("active"))
            stall = active and (now - self.last_progress) > self.deadman_s
            breach_why = []
            if self.max_gross is not None and gross > self.max_gross:
                breach_why.append(f"gross {gross:.0f} > {self.max_gross:.0f}")
            if self.loss_cap is not None and day_loss > self.loss_cap:
                breach_why.append(
                    f"day loss {day_loss:.0f} > {self.loss_cap:.0f}")
            rec.update(reachable=True, day=self.day, active=active,
                       gross=round(gross, 2), day_loss=round(day_loss, 2),
                       stall=stall, breach=bool(breach_why))
            if breach_why and not self.breach_warned:
                try:
                    self._api("/api/killswitch/trip",
                              {"reason": "sentinel: " +
                               "; ".join(breach_why)})
                    rec["action"] = "api_trip"
                except Exception as e:       # noqa: BLE001
                    rec["action"] = f"api_trip_failed:{e}"
                self.breach_warned = True    # one grace cycle to self-flatten
            elif (breach_why and self.breach_warned) or stall:
                rec["action"] = self._flatten(
                    "stall" if stall else "; ".join(breach_why))
                self.breach_warned = False
            else:
                self.breach_warned = False
            self._ping("acted" if rec.get("action") else "ok",
                       rec.get("action", ""))
        except Exception as e:               # noqa: BLE001 — runtime absent
            rec.update(reachable=False, why=str(e))
            if now - self.last_progress > self.deadman_s:
                try:
                    if self.venue.positions():
                        rec["action"] = self._flatten("unreachable")
                    else:
                        rec["action"] = "venue_already_flat"
                except Exception as ve:      # noqa: BLE001
                    rec["venue_error"] = str(ve)
        self.log.append(rec)
        return rec

    def run(self, stop=None):
        print(f"sentinel watching {self.api} · venue {self.venue.url} · "
              f"deadman {self.deadman_s}s · max_gross {self.max_gross} · "
              f"loss_cap {self.loss_cap}")
        while stop is None or not stop.is_set():
            rec = self.check()
            if rec.get("action"):
                print("SENTINEL ACTION:", json.dumps(rec))
            time.sleep(self.poll_s)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="arsic sentinel")
    ap.add_argument("--api", default=os.environ.get(
        "ARSIC_API_URL", "http://127.0.0.1:8787"))
    ap.add_argument("--venue-url", default=os.environ.get(
        "ARSIC_SENTINEL_VENUE_URL", ""))
    ap.add_argument("--venue-key", default=os.environ.get(
        "ARSIC_SENTINEL_KEY", ""))
    ap.add_argument("--venue-secret", default=os.environ.get(
        "ARSIC_SENTINEL_SECRET", ""))
    ap.add_argument("--deadman", type=float, default=3.0)
    ap.add_argument("--max-gross", type=float, default=None)
    ap.add_argument("--loss-cap", type=float, default=None)
    ap.add_argument("--poll", type=float, default=0.5)
    a = ap.parse_args(argv)
    if not (a.venue_url and a.venue_key and a.venue_secret):
        print("sentinel requires --venue-url/--venue-key/--venue-secret "
              "(cancel-scope credentials)")
        return 2
    Sentinel(a.api, a.venue_url, a.venue_key, a.venue_secret,
             deadman_s=a.deadman, max_gross=a.max_gross,
             loss_cap=a.loss_cap, poll_s=a.poll).run()
    return 0
