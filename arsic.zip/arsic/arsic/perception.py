"""ARSIC Perception & Tool Plane drivers (spec S2 bottom layer, S7 data plane).

The sandbox has no network egress, so the live drivers (exchange APIs,
rwa.xyz, Coinglass-style, Hyperliquid API, X search) are pluggable behind the
same MarketDriver interface. SyntheticMarket is a seeded regime-switching
generator covering the four regimes the spec requires promotion testing on
(trend, range, high-vol, post-squeeze), and it injects the spec's motivating
anomaly: an extreme MOVE funding print that mean-reverts (a false-positive
trap for naive strategies).
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, asdict
from typing import Optional

PERIODS_PER_DAY = 3   # 8h funding periods

UNIVERSE = [  # (venue, symbol, base_liq_score) — entities named in spec S3
    ("binance", "BTC-USDT-PERP", 1.00),
    ("binance", "ETH-USDT-PERP", 0.90),
    ("bybit",   "BTC-USDT-PERP", 0.85),
    ("hyperliquid", "MOVE-PERP", 0.40),
    ("hyperliquid", "HIP3-RWA-PERP", 0.35),
]

REGIMES = {
    #            mu_f       phi   sigma_f   ret_vol  extreme_p
    "trend":        (+0.00045, 0.90, 0.00010, 0.010, 0.02),
    "range":        (+0.00010, 0.80, 0.00008, 0.006, 0.01),
    "high_vol":     (+0.00020, 0.70, 0.00060, 0.030, 0.14),
    "post_squeeze": (-0.00120, 0.85, 0.00050, 0.022, 0.18),
}


@dataclass
class Tick:
    day: int
    period: int
    venue: str
    symbol: str
    spot: float
    perp: float
    funding: float       # per 8h period (fraction); + => longs pay shorts
    oi: float
    volume: float
    liq_score: float

    @property
    def premium(self) -> float:
        return (self.perp - self.spot) / self.spot

    def key(self) -> str:
        return f"{self.venue}:{self.symbol}"


class MarketDriver:
    def ticks(self, day: int) -> list[Tick]:            # pragma: no cover - interface
        raise NotImplementedError

    def regime_of(self, day: int) -> str:               # pragma: no cover - interface
        raise NotImplementedError


class SyntheticMarket(MarketDriver):
    def __init__(self, seed: int, schedule: list[tuple]):
        """schedule: [(regime, n_days), ...]"""
        self.seed = seed
        self.schedule = schedule
        self.total_days = sum(n for _, n in schedule)
        self._build()

    def regime_of(self, day: int) -> str:
        d = 0
        for r, n in self.schedule:
            if day < d + n:
                return r
            d += n
        return self.schedule[-1][0]

    def _build(self) -> None:
        rng = random.Random(self.seed)
        self.data: dict[tuple, list[Tick]] = {}
        state = {}
        for venue, sym, liq in UNIVERSE:
            state[(venue, sym)] = {"spot": 100.0 * (1 + rng.random()),
                                   "f": 0.0001, "oi": 1e8 * liq}
        for day in range(self.total_days):
            regime = self.regime_of(day)
            mu, phi, sig, rvol, ex_p = REGIMES[regime]
            for period in range(PERIODS_PER_DAY):
                for venue, sym, liq in UNIVERSE:
                    st = state[(venue, sym)]
                    ret = rng.gauss(0.0005 if regime == "trend" else 0.0, rvol)
                    st["spot"] *= (1 + ret)
                    f = mu + phi * (st["f"] - mu) + rng.gauss(0, sig)
                    if st.get("squeeze", 0) > 0:
                        # squeeze aftermath: funding whipsaws AGAINST the trap
                        # entrant while premium stays pinned (no MTM rescue).
                        st["squeeze"] -= 1
                        f = -st["trap_sign"] * rng.uniform(0.004, 0.007)
                        premium = st["prem_pin"] + rng.gauss(0, 0.0002)
                    elif rng.random() < ex_p * (1.6 - liq):
                        # the MOVE-style extreme print (spec S4 deep-dive case):
                        # a huge one-off funding rate that mean-reverts hard.
                        s_ = rng.choice([-1, 1])
                        f = s_ * rng.uniform(0.004, 0.009)
                        st["trap_sign"], st["squeeze"] = s_, 2
                        premium = 2.0 * f + rng.gauss(0, 0.0004)
                        st["prem_pin"] = premium
                    else:
                        premium = 2.0 * f + rng.gauss(0, 0.0004)
                    st["f"] = f
                    oi_shock = rng.gauss(0, 0.05) + (0.25 if abs(f) > 0.0035 else 0)
                    st["oi"] *= max(0.5, 1 + oi_shock)
                    t = Tick(day=day, period=period, venue=venue, symbol=sym,
                             spot=st["spot"], perp=st["spot"] * (1 + premium),
                             funding=f, oi=st["oi"],
                             volume=st["oi"] * rng.uniform(0.5, 1.5),
                             liq_score=liq)
                    self.data.setdefault((day, period), []).append(t)

    def ticks(self, day: int) -> list[Tick]:
        out = []
        for p in range(PERIODS_PER_DAY):
            out += self.data.get((day, p), [])
        return out

    def ticks_at(self, day: int, period: int) -> list[Tick]:
        return list(self.data.get((day, period), []))


class RWADriver:
    """rwa.xyz-style metrics for tokenized assets (spec S3 entities: Ondo USDY,
    Hyperliquid HIP-3 RWA markets)."""

    def __init__(self, seed: int):
        self.rng = random.Random(seed * 7 + 1)

    def metrics(self, day: int) -> list[dict]:
        base_yield = 0.052 + 0.002 * math.sin(day / 9)
        return [
            {"entity": "rwa:ondo-usdy", "tvl": 6.1e8 * (1 + 0.002 * day + self.rng.gauss(0, 0.01)),
             "yield": base_yield, "holder_count": int(21000 + 40 * day + self.rng.gauss(0, 60))},
            {"entity": "rwa:hip3-rwa", "tvl": 9.5e7 * (1 + 0.004 * day + self.rng.gauss(0, 0.02)),
             "yield": base_yield + 0.011 + self.rng.gauss(0, 0.001),
             "holder_count": int(3200 + 15 * day + self.rng.gauss(0, 30))},
        ]


class SentimentDriver:
    """X/narrative ingest stand-in producing narrative_velocity edges (S3)."""

    def __init__(self, seed: int):
        self.rng = random.Random(seed * 13 + 2)

    def narrative(self, day: int) -> list[dict]:
        out = []
        for _, sym, liq in UNIVERSE:
            v = max(0.0, self.rng.gauss(0.4 + 0.3 * (1 - liq), 0.15))
            out.append({"symbol": sym, "narrative_velocity": round(v, 3)})
        return out


class OnChainDriver:
    def __init__(self, seed: int):
        self.rng = random.Random(seed * 17 + 3)

    def flows(self, day: int) -> list[dict]:
        return [{"symbol": sym, "netflow": self.rng.gauss(0, 1e6)}
                for _, sym, _ in UNIVERSE]


def heldout_suites(seeds: list[int], days: int = 10) -> dict[str, list[SyntheticMarket]]:
    """Held-out regime suites for the frozen evaluator (S5): promotion requires
    improvement across trend / range / high-vol / post-squeeze on fresh seeds."""
    return {regime: [SyntheticMarket(seed=s * 1000 + i, schedule=[(regime, days)])
                     for i, s in enumerate(seeds)]
            for regime in REGIMES}
