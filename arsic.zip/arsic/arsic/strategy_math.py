"""Pure strategy math shared by the live constellation agents AND the sandbox
sibling constellations used in harness A/B tests (spec S5). Keeping one source
of truth guarantees the sibling runs exercise the exact logic being promoted.

Implements: funding-persistence analysis (streak, z), entry/exit rules
parameterised by the harness, expected-edge estimate, a full deterministic
paper simulation, and a perfect-foresight oracle used for the S9 'compounding'
metric (fraction of the gap to oracle closed over epochs).
"""
from __future__ import annotations

import math
import statistics as st
from dataclasses import dataclass, field
from typing import Optional

from .perception import MarketDriver, Tick, PERIODS_PER_DAY

FEE_BPS_PER_LEG = 4.0       # taker fee per leg per side
SLIP_BPS = 2.0
COST_ROUNDTRIP = (FEE_BPS_PER_LEG * 2 * 2 + SLIP_BPS * 2) / 1e4   # both legs, open+close


@dataclass
class SymStats:
    key: str
    funding: float
    streak: int          # consecutive same-sign funding periods
    z: float             # z-score of latest funding vs rolling window
    basis: float         # perp premium
    liq: float
    mean_f: float


def rolling_stats(hist: list[float], liq: float, basis: float, key: str) -> SymStats:
    f = hist[-1]
    window = hist[-12:]
    mu = st.fmean(window)
    sd = st.pstdev(window) if len(window) > 2 else 0.0
    z = (f - mu) / sd if sd > 1e-9 else 0.0
    streak, sign = 0, (1 if f >= 0 else -1)
    for x in reversed(hist):
        if (1 if x >= 0 else -1) == sign and abs(x) > 1e-6:
            streak += 1
        else:
            break
    return SymStats(key=key, funding=f, streak=streak, z=z, basis=basis,
                    liq=liq, mean_f=mu)


def should_enter(s: SymStats, p: dict) -> Optional[dict]:
    """Harness-parameterised entry rule.
    side +1 = short perp / long spot (collect positive funding);
    side -1 = long perp / short spot (collect negative funding)."""
    if s.liq < p["min_liq_score"]:
        return None
    if abs(s.funding) < p["f_min"]:
        return None
    if s.streak < p["persistence_min"]:
        return None
    if abs(s.z) > p["z_cap"]:
        return None                      # extreme prints are mean-reversion traps
    side = 1 if s.funding > 0 else -1
    if side < 0 and not p.get("neg_side_enabled", True):
        return None
    edge = expected_edge(s, p)
    if edge <= 0:
        return None
    return {"key": s.key, "side": side, "edge": edge,
            "extreme_entry": abs(s.z) > 2.5,
            "borderline": (2.0 < abs(s.z) <= p["z_cap"]) and s.liq < 0.5,
            "reason": f"|f|={abs(s.funding):.4%}/8h streak={s.streak} z={s.z:.1f}"}


def extreme_reverts(z_hist: list) -> bool:
    """Deep-dive evidence rule (shared by the live DeepDive child agent's core
    and the sandbox sibling sim): has an extreme print recently collapsed?"""
    return any(abs(a) > 2.5 and abs(b) < abs(a) * 0.6
               for a, b in zip(z_hist, z_hist[1:]))


def expected_edge(s: SymStats, p: dict) -> float:
    hold = p["expected_hold_periods"]
    decay = 0.75                          # funding decays toward mean while held
    gross = abs(s.mean_f * (1 - decay) + s.funding * decay) * hold
    return gross - COST_ROUNDTRIP - p.get("edge_fee_buffer", 0.0)


def should_exit(pos: dict, s: SymStats, p: dict) -> Optional[str]:
    if pos["hold"] >= p["max_hold_periods"]:
        return "max_hold"
    if pos["side"] * s.funding < 0:
        pos["flip_count"] += 1
    else:
        pos["flip_count"] = 0
    if pos["flip_count"] >= p["exit_flip_k"]:
        return "funding_flipped"
    if abs(s.z) > p["z_cap"] + 1.5 and (s.z * pos["side"] < 0):
        return "reversal_extreme"
    return None


# ---------------------------------------------------------------------------
# Deterministic paper simulation (used by sandbox siblings + tests)
# ---------------------------------------------------------------------------

@dataclass
class SimResult:
    equity_curve: list
    funding_pnl: float
    fees: float
    mtm: float
    n_ops: int
    fp_entries: int
    extreme_entries: int
    oracle_funding: float
    wins: int
    trajectories: list = field(default_factory=list)

    @property
    def pnl(self) -> float:
        return self.equity_curve[-1] - self.equity_curve[0]

    def metrics(self, equity0: float) -> dict:
        rets = [(b - a) / a for a, b in zip(self.equity_curve, self.equity_curve[1:])]
        sd = st.pstdev(rets) if len(rets) > 2 else 0.0
        sharpe = (st.fmean(rets) / sd * math.sqrt(365)) if sd > 1e-12 else 0.0
        peak, mdd = self.equity_curve[0], 0.0
        for e in self.equity_curve:
            peak = max(peak, e)
            mdd = max(mdd, (peak - e) / peak)
        cap = self.funding_pnl / self.oracle_funding if self.oracle_funding > 0 else 0.0
        fp = self.fp_entries / self.n_ops if self.n_ops else 0.0
        return {"pnl": self.pnl, "sharpe": sharpe, "max_dd": mdd,
                "capture_eff": max(0.0, cap), "fp_rate": fp,
                "n_ops": self.n_ops, "win_rate": (self.wins / self.n_ops) if self.n_ops else 0.0,
                "funding_pnl": self.funding_pnl, "oracle_funding": self.oracle_funding}


def oracle_funding_pnl(driver: MarketDriver, notional: float,
                       upto_day: Optional[int] = None) -> float:
    """Perfect-foresight upper bound: capture |funding|*notional on every
    period/symbol where it exceeds per-period cost (S9 'oracle strategies').
    upto_day limits the horizon (inclusive) for live to-date metrics."""
    per_period_cost = COST_ROUNDTRIP / 4      # amortised across a short hold
    last = driver.total_days if upto_day is None else min(driver.total_days, upto_day + 1)
    total = 0.0
    for day in range(last):
        for p in range(PERIODS_PER_DAY):
            for t in driver.ticks_at(day, p):
                gain = abs(t.funding) * notional - per_period_cost * notional
                if gain > 0:
                    total += gain
    return total


def simulate(harness_strategy: dict, driver: MarketDriver, adapter: dict,
             equity0: float = 1_000_000.0, size_frac: float = 0.10) -> SimResult:
    """Headless sibling run: identical entry/exit math as the agent
    constellation, minus the message bus. Deterministic given (harness, seed)."""
    p = dict(harness_strategy)
    # bounded model-adapter influence (S5): analyst risk aversion & extreme discount
    p = apply_adapter(p, adapter)
    hist: dict[str, list] = {}
    zhist: dict[str, list] = {}
    open_pos: dict[str, dict] = {}
    equity = equity0
    curve = [equity]
    fund_pnl = fees = mtm_tot = 0.0
    n_ops = fp = wins = extreme = 0
    trajs = []
    for day in range(driver.total_days):
        regime = driver.regime_of(day)
        for period in range(PERIODS_PER_DAY):
            ticks = {t.key(): t for t in driver.ticks_at(day, period)}
            for key, t in ticks.items():
                hist.setdefault(key, []).append(t.funding)
            # -- update open positions
            for key in list(open_pos):
                pos, t = open_pos[key], ticks[key]
                s = rolling_stats(hist[key], t.liq_score, t.premium, key)
                pay = pos["side"] * t.funding * pos["notional"]
                pos["funding_pnl"] += pay
                fund_pnl += pay
                d_prem = t.premium - pos["last_premium"]
                m = -pos["side"] * d_prem * pos["notional"]
                pos["mtm"] += m
                mtm_tot += m
                pos["last_premium"] = t.premium
                pos["hold"] += 1
                equity += pay + m
                why = should_exit(pos, s, p)
                if why:
                    cost = COST_ROUNDTRIP / 2 * pos["notional"]
                    fees += cost
                    equity -= cost
                    net = pos["funding_pnl"] + pos["mtm"] - pos["cost_open"] - cost
                    n_ops += 1
                    wins += 1 if net > 0 else 0
                    is_fp = pos["extreme_entry"] and pos["hold"] <= 3 and net < 0
                    fp += 1 if is_fp else 0
                    trajs.append({"regime": regime,
                                  "features": {"funding": pos["entry_f"], "z": pos["entry_z"],
                                               "streak": pos["entry_streak"], "liq": t.liq_score},
                                  "actions": [{"enter": pos["side"], "exit": why}],
                                  "outcome": {"pnl": net, "funding_pnl": pos["funding_pnl"],
                                              "fp": is_fp, "hold": pos["hold"]}})
                    del open_pos[key]
            # -- consider entries
            for key, t in ticks.items():
                if len(hist[key]) >= 4:
                    zhist.setdefault(key, []).append(
                        rolling_stats(hist[key], t.liq_score, t.premium, key).z)
                if key in open_pos or len(hist[key]) < 4:
                    continue
                s = rolling_stats(hist[key], t.liq_score, t.premium, key)
                sig = should_enter(s, p)
                if not sig:
                    continue
                if sig["borderline"] and extreme_reverts(zhist.get(key, [])[-8:]):
                    continue          # deep-dive verdict: unsustainable extreme
                notional = min(equity * size_frac,
                               equity * p["max_leverage"] * 0.5,
                               t.oi * 0.001)
                cost = COST_ROUNDTRIP / 2 * notional
                fees += cost
                equity -= cost
                extreme += 1 if sig["extreme_entry"] else 0
                open_pos[key] = {"side": sig["side"], "notional": notional,
                                 "funding_pnl": 0.0, "mtm": 0.0, "hold": 0,
                                 "flip_count": 0, "cost_open": cost,
                                 "last_premium": t.premium,
                                 "entry_f": s.funding, "entry_z": s.z,
                                 "entry_streak": s.streak,
                                 "extreme_entry": sig["extreme_entry"]}
            curve.append(equity)
    return SimResult(equity_curve=curve, funding_pnl=fund_pnl, fees=fees,
                     mtm=mtm_tot, n_ops=n_ops, fp_entries=fp,
                     extreme_entries=extreme,
                     oracle_funding=oracle_funding_pnl(driver, equity0 * size_frac),
                     wins=wins, trajectories=trajs)


def apply_adapter(p: dict, adapter: dict) -> dict:
    """S5 bounded model adapters: small numeric tendencies of the analyst core
    (risk_aversion scales edge buffer; extreme_discount tightens z_cap)."""
    q = dict(p)
    q["edge_fee_buffer"] = p.get("edge_fee_buffer", 0.0) * adapter.get("risk_aversion", 1.0)
    q["z_cap"] = p["z_cap"] / max(1e-6, adapter.get("extreme_discount", 1.0))
    return q
