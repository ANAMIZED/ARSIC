"""Venue HTTP client — the production connector for the L3 external route.

Handles what a real exchange integration must: HMAC request signing with
strictly-increasing nonces, hard timeouts, bounded retry with exponential
backoff on throttling (429) and transient (5xx / connection) errors,
idempotent client order ids (safe to retry a placement), and a clean error
taxonomy (VenueAuthError is fatal; VenueUnavailable is transient and
surfaces only after retries are exhausted).

ExternalVenueAdapter exposes the exact `fill(intent, tick)` interface the
L3Session already uses for the shadow route, so the RiskGate, HITL queue,
token checks, and every demotion path are identical on both routes.
"""
from __future__ import annotations

import dataclasses
import json
import time
import urllib.error
import urllib.request

from .venue_sim import sign


class VenueAuthError(RuntimeError):
    """Fatal: bad credentials/signature/scope. Never retried."""


class VenueUnavailable(RuntimeError):
    """Transient exhaustion: timeouts/5xx/429 beyond the retry budget."""


class VenueClient:
    def __init__(self, url: str, api_key: str, secret: str,
                 timeout: float = 2.0, max_retries: int = 3,
                 backoff_s: float = 0.05):
        self.url = url.rstrip("/")
        self.api_key = api_key
        self.secret = secret
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_s = backoff_s
        self._nonce = time.time_ns()

    def _request(self, method: str, path: str, body: dict | None = None):
        payload = json.dumps(body) if body is not None else ""
        attempt = 0
        while True:
            self._nonce += 1
            nonce = str(self._nonce)
            req = urllib.request.Request(
                self.url + path, method=method,
                data=payload.encode() if payload else None,
                headers={"Content-Type": "application/json",
                         "X-API-KEY": self.api_key,
                         "X-NONCE": nonce,
                         "X-SIGNATURE": sign(self.secret, method, path,
                                             payload, nonce)})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return json.loads(r.read().decode())
            except urllib.error.HTTPError as e:
                detail = e.read().decode(errors="replace")
                if e.code in (401, 403):
                    raise VenueAuthError(f"{e.code}: {detail}") from None
                if e.code == 409:
                    # nonce desync (e.g. another client on the same key or a
                    # restart): resync to the clock and retry, bounded
                    attempt += 1
                    if attempt > self.max_retries:
                        raise VenueAuthError(
                            f"nonce replay persists: {detail}") from None
                    self._nonce = time.time_ns()
                    continue
                if e.code == 429 or e.code >= 500:
                    attempt += 1
                    if attempt > self.max_retries:
                        raise VenueUnavailable(
                            f"{e.code} after {attempt} attempts") from None
                    time.sleep(self.backoff_s * (2 ** (attempt - 1)))
                    continue
                raise VenueUnavailable(f"{e.code}: {detail}") from None
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                attempt += 1
                if attempt > self.max_retries:
                    raise VenueUnavailable(str(e)) from None
                time.sleep(self.backoff_s * (2 ** (attempt - 1)))

    # ---------------- api ----------------
    def health(self):
        return self._request("GET", "/v1/health")

    def place_order(self, client_oid: str, key: str, side: int,
                    notional: float, leverage: float):
        return self._request("POST", "/v1/order",
                             {"client_oid": client_oid, "key": key,
                              "side": side, "notional": notional,
                              "leverage": leverage})

    def cancel_all(self):
        return self._request("POST", "/v1/cancel_all", {})

    def positions(self):
        return self._request("GET", "/v1/positions")["positions"]

    def gross(self) -> float:
        return sum(p["notional"] for p in self.positions())


class ExternalVenueAdapter:
    """Same interface as ShadowLiveAdapter — the session cannot tell the
    routes apart, so every control binds identically."""

    def __init__(self, client: VenueClient, mid: str):
        self.client = client
        self.mid = mid

    def fill(self, intent, tick):
        r = self.client.place_order(
            client_oid=f"{self.mid}:{intent.oid}", key=intent.key,
            side=intent.side, notional=intent.notional,
            leverage=intent.leverage)
        if r.get("status") == "rejected":
            return None
        slip = intent.side * r["slip_bps"] * 1e-4
        t2 = dataclasses.replace(tick, perp=tick.perp * (1 + slip))
        return {"tick": t2, "ratio": r["fill_ratio"],
                "slip_bps": r["slip_bps"], "extra_fee": r["fee"]}
