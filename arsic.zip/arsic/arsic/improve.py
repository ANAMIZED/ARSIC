"""ARSIC Recursive Improvement Plane (spec S2 second layer, S5 'the heart').

Loops implemented here:
- Harness Co-Evolution: outer proposer emits candidate harness diffs; each is
  contract-linted (S6), applied to a SIBLING sandbox constellation (isolated
  dirs, data snapshots by seed, no live-exchange access), A/B-run against the
  incumbent on held-out regime suites (trend/range/high-vol/post-squeeze),
  scored by the FROZEN evaluator, and promoted only on statistical
  significance (paired sign-flip permutation test) with no per-regime
  regression. Promotions are versioned in a real git repo.
- Verified sibling trajectories -> training signal (SFT / preference / critic
  JSONL) -> bounded model-adapter update, gated at ADAPTER privilege.
- Meta-Improvement: changes to acceptance criteria / topology / the search
  itself file META tickets (human-gated).
Every experiment is logged to the ExperimentTracker.
"""
from __future__ import annotations

import copy
import itertools
import os
import statistics as st
import subprocess
from dataclasses import dataclass, field, asdict

from . import strategy_math as sm
from .events import EventLog, ExperimentTracker, canon, sha
from .evaluate import Evaluator, Scoreboard
from .exg import ExperienceGraph, Trajectory
from .governance import Governance, GoalContract, Priv, lint_against_contract
from .llm import bounded_adapter_update
from .perception import SyntheticMarket, heldout_suites

DEFAULT_STRATEGY = {
    "f_min": 0.0003, "persistence_min": 2, "z_cap": 14.0,
    "max_hold_periods": 12, "exit_flip_k": 2, "expected_hold_periods": 6,
    "edge_fee_buffer": 0.0002, "neg_side_enabled": True,
    "min_liq_score": 0.3, "max_leverage": 2.0, "dd_budget": 0.08,
    "xv_gap_min": 0.0006, "basis_min": 0.004, "rwa_spread_min": 0.008,
}

DEFAULT_PROMPTS = {
    "market_analysis": ("You are the Market Analyst. Read only the wiki. "
                        "Report funding persistence, z-score and basis."),
    "opportunity_rank": ("Rank opportunities by expected edge net of costs; "
                         "prefer liquid venues."),
}

DEFAULT_TOPOLOGY = ["perception", "market_analyst", "research", "sentiment",
                    "opportunity_scanner", "strategies", "sizing_exec",
                    "liq_monitor", "killswitch", "meta"]


@dataclass
class Harness:
    version: int = 1
    prompts: dict = field(default_factory=lambda: dict(DEFAULT_PROMPTS))
    strategy: dict = field(default_factory=lambda: dict(DEFAULT_STRATEGY))
    routing: dict = field(default_factory=lambda: {"cross_venue_precheck": False})
    topology: list = field(default_factory=lambda: list(DEFAULT_TOPOLOGY))
    adapter: dict = field(default_factory=lambda: {"risk_aversion": 1.0,
                                                   "extreme_discount": 1.0})

    def apply_diff(self, diff: dict) -> "Harness":
        h = copy.deepcopy(self)
        for path, val in diff.items():
            if "." not in path:                      # bare section, e.g. "topology"
                if path == "topology":
                    h.topology.append(val)
                    continue
                raise ValueError(f"un-addressable diff path: {path}")
            sect, key = path.split(".", 1)
            tgt = getattr(h, sect)
            if sect == "prompts" and isinstance(val, str) and val.startswith("+"):
                tgt[key] = tgt.get(key, "") + " " + val[1:]
            elif sect == "topology":
                tgt.append(val)
            else:
                tgt[key] = val
        return h

    def to_json(self) -> str:
        return canon(asdict(self))


class HarnessRepo:
    """S7: sandboxed git repo for harness code/config. Falls back to a plain
    versioned file if git is unavailable."""

    def __init__(self, path: str, audit: EventLog):
        self.path = path
        self.audit = audit
        os.makedirs(path, exist_ok=True)
        self.git_ok = self._git("rev-parse", "--is-inside-work-tree") is not None
        if not self.git_ok:
            self.git_ok = self._git("init", "-q") is not None
            self._git("config", "user.email", "arsic@local")
            self._git("config", "user.name", "arsic")

    def _git(self, *args):
        try:
            r = subprocess.run(["git", "-C", self.path, *args],
                               capture_output=True, text=True, timeout=20)
            return r.stdout.strip() if r.returncode == 0 else None
        except Exception:
            return None

    def commit(self, harness: Harness, msg: str) -> str:
        fp = os.path.join(self.path, "harness.json")
        with open(fp, "w") as f:
            f.write(harness.to_json())
        commit_sha = ""
        if self.git_ok:
            self._git("add", "harness.json")
            self._git("commit", "-q", "-m", msg)
            commit_sha = self._git("rev-parse", "HEAD") or ""
        self.audit.append("harness.commit", {"version": harness.version,
                                             "msg": msg,
                                             "git_sha": commit_sha[:12]}, "improve")
        return commit_sha

    def log(self) -> list:
        out = self._git("log", "--oneline") or ""
        return out.splitlines()


class Sandbox:
    """S6: isolated experimental constellation — its own directory tree, its
    own data snapshot (seeded driver), and NO live-exchange write access.
    (Container/K8s isolation is the production substitution; see matrix.)"""

    _i = itertools.count(1)

    def __init__(self, root: str):
        self.id = f"SBX{next(Sandbox._i):03d}"
        self.dir = os.path.join(root, self.id)
        os.makedirs(self.dir, exist_ok=True)
        self.no_live = True

    def run(self, harness: Harness, driver: SyntheticMarket) -> dict:
        assert self.no_live, "sandboxes never touch live venues"
        res = sm.simulate(harness.strategy, driver, harness.adapter)
        m = res.metrics(1_000_000.0)
        m["_trajectories"] = res.trajectories
        return m


def signflip_pvalue(diffs: list, one_sided: bool = True) -> float:
    """Paired sign-flip permutation test (exact for n<=12)."""
    n = len(diffs)
    obs = st.fmean(diffs)
    total = 1 << n
    ge = 0
    for mask in range(total):
        s = 0.0
        for i, d in enumerate(diffs):
            s += d if (mask >> i) & 1 else -d
        if s / n >= obs - 1e-15:
            ge += 1
    return ge / total if one_sided else min(1.0, 2 * ge / total)


@dataclass
class ABReport:
    candidate_title: str
    level: int
    lint_violations: list
    p_value: float = 1.0
    mean_diff: float = 0.0
    per_regime: dict = field(default_factory=dict)
    promoted: bool = False
    ticket_id: str = ""
    reason: str = ""


class HarnessEvolution:
    """S5 harness co-evolution loop with S6 gates."""

    ALPHA = 0.05
    REGIME_REGRESSION_TOL = 0.15    # a regime may not lose more than this

    def __init__(self, gov: Governance, contract: GoalContract,
                 evaluator: Evaluator, repo: HarnessRepo, board: Scoreboard,
                 tracker: ExperimentTracker, audit: EventLog, sandbox_root: str):
        self.gov = gov
        self.contract = contract
        self.evaluator = evaluator
        self.repo = repo
        self.board = board
        self.tracker = tracker
        self.audit = audit
        self.sandbox_root = sandbox_root
        self.sibling_exg = ExperienceGraph(audit)   # verified sibling trajectories

    def default_candidates(self) -> list:
        """S8 step 5 outputs, expressed as concrete diffs."""
        return [
            ("tighten extreme filter (+prompt directive)", Priv.SKILL,
             {"strategy.z_cap": 2.5, "strategy.persistence_min": 3,
              "prompts.market_analysis": "+[[EXTREME_DISCOUNT]]"}),
            ("raise leverage to 5x", Priv.SKILL,
             {"strategy.max_leverage": 5.0}),
            ("cross-venue precheck in topology", Priv.POLICY,
             {"routing.cross_venue_precheck": True,
              "strategy.xv_gap_min": 0.0005,
              "topology": "cross_venue_precheck"}),
        ]

    def epoch(self, incumbent: Harness, seeds: list, days: int = 10,
              candidates: list | None = None, epoch_no: int = 0) -> tuple:
        assert self.evaluator.frozen, "evaluator must be frozen during an epoch (S5)"
        suites = heldout_suites(seeds, days=days)
        inc_scores, inc_regime = self._score_harness(incumbent, suites, "incumbent")
        self.board.record(self.evaluator.hash, f"incumbent.v{incumbent.version}",
                          st.fmean(inc_scores), epoch_no)
        reports, promoted = [], incumbent
        for title, level, diff in (candidates or self.default_candidates()):
            rep = ABReport(candidate_title=title, level=int(level),
                           lint_violations=[])
            cand = incumbent.apply_diff(diff)
            rep.lint_violations = lint_against_contract(cand.strategy, self.contract)
            if rep.lint_violations:
                rep.reason = "screened out by goal-contract lint"
                self.audit.append("improve.lint_reject",
                                  {"title": title, "violations": rep.lint_violations},
                                  "improve")
                reports.append(rep)
                continue
            c_scores, c_regime = self._score_harness(cand, suites, title)
            diffs = [c - i for c, i in zip(c_scores, inc_scores)]
            rep.p_value = signflip_pvalue(diffs)
            rep.mean_diff = st.fmean(diffs)
            rep.per_regime = {r: round(c_regime[r] - inc_regime[r], 4)
                              for r in c_regime}
            regression = any(d < -self.REGIME_REGRESSION_TOL
                             for d in rep.per_regime.values())
            ticket = self.gov.request(level, f"promote: {title}",
                                      {"diff": diff, "p": rep.p_value,
                                       "mean_diff": rep.mean_diff,
                                       "per_regime": rep.per_regime}, "improve")
            rep.ticket_id = ticket.tid
            significant = rep.p_value < self.ALPHA and rep.mean_diff > 0
            if significant and not regression and self.gov.is_executable(ticket):
                self.gov.mark_applied(ticket)
                promoted = cand
                promoted.version = incumbent.version + 1
                rep.promoted = True
                rep.reason = "significant, no regime regression, ticket executable"
                self.repo.commit(promoted, f"v{promoted.version}: {title} "
                                           f"(p={rep.p_value:.4f})")
                self._harvest_sibling_trajectories(c_regime, cand, suites)
            else:
                rep.reason = ("not significant" if not significant else
                              "regime regression" if regression else
                              f"ticket not executable (status={ticket.status})")
            self.tracker.log({"epoch": epoch_no, "candidate": title,
                              "p": rep.p_value, "mean_diff": rep.mean_diff,
                              "promoted": rep.promoted,
                              "eval_hash": self.evaluator.hash})
            self.audit.append("improve.ab_result", asdict(rep), "improve")
            reports.append(rep)
            if rep.promoted:
                incumbent = promoted
                inc_scores, inc_regime = c_scores, c_regime
                self.board.record(self.evaluator.hash,
                                  f"incumbent.v{incumbent.version}",
                                  st.fmean(inc_scores), epoch_no)
        return promoted, reports

    def _score_harness(self, h: Harness, suites: dict, tag: str) -> tuple:
        per_seed, per_regime = [], {}
        n_seeds = len(next(iter(suites.values())))
        for i in range(n_seeds):
            vals = []
            for regime, drivers in suites.items():
                sb = Sandbox(self.sandbox_root)
                m = sb.run(h, drivers[i])
                s = self.evaluator.score(m)
                vals.append(s)
                per_regime.setdefault(regime, []).append(s)
                if tag != "incumbent":
                    self._stash_trajs(m, regime)
            per_seed.append(st.fmean(vals))
        return per_seed, {r: st.fmean(v) for r, v in per_regime.items()}

    def _stash_trajs(self, m: dict, regime: str) -> None:
        self._pending = getattr(self, "_pending", [])
        for t in m.get("_trajectories", [])[:20]:
            self._pending.append((regime, t))

    def _harvest_sibling_trajectories(self, _regime_scores, cand, suites) -> None:
        """S5: verified trajectories from the winning sibling become training
        signal (SFT / preference / critic)."""
        for regime, t in getattr(self, "_pending", [])[:400]:
            self.sibling_exg.add(Trajectory(
                tid="", run_id="sibling", regime=t["regime"],
                features=t["features"], actions=t["actions"],
                outcome=t["outcome"], verified=True))
        self._pending = []

    # -- bounded model-adapter update (S5, ADAPTER privilege) --------------
    def fit_adapter(self, harness: Harness, out_dir: str) -> tuple:
        paths = self.sibling_exg.export_training_datasets(out_dir)
        vt = self.sibling_exg.verified_trajectories()
        fp_ext = [t for t in vt if abs(t.features.get("z", 0)) > 2.5]
        fp_rate_ext = (sum(1 for t in fp_ext if t.outcome.get("pnl", 0) < 0)
                       / len(fp_ext)) if fp_ext else 0.0
        proposed = {"risk_aversion": 1.0 + 0.5 * fp_rate_ext,
                    "extreme_discount": 1.0 + 1.0 * fp_rate_ext}
        bounded = bounded_adapter_update(harness.adapter, proposed)
        ticket = self.gov.request(Priv.ADAPTER,
                                  "bounded adapter update from verified siblings",
                                  {"proposed": proposed, "bounded": bounded,
                                   "n_verified": len(vt), "datasets": paths},
                                  "improve")
        return bounded, ticket, paths

    def apply_adapter(self, harness: Harness, bounded: dict, ticket) -> Harness:
        self.gov.mark_applied(ticket)          # raises unless human-approved
        h = copy.deepcopy(harness)
        h.adapter = bounded
        h.version += 1
        self.repo.commit(h, f"v{h.version}: adapter update (ADAPTER ticket {ticket.tid})")
        return h


class MetaQueue:
    """S5 Meta-Improvement + S8: self-improvement notes are first-class
    tickets; changes to the improvement search itself are META-gated."""

    def __init__(self, gov: Governance):
        self.gov = gov

    def propose_meta(self, title: str, payload: dict, actor: str):
        return self.gov.request(Priv.META, title, payload, actor)
