"""ARSIC bootstrap (spec S7 'Bootstrap sequence') and full system wiring.

1. Seed the wiki with the daily scan format, funding tables, RWA metrics and
   initial strategy templates.
2. Instantiate the core constellation from the research agents.
3. Run paper-trade only for N cycles (autonomy L0).
4. Enable harness evolution on a sibling (autonomy L1, human-approved).
5. Gradually raise autonomy under human observation (L2 adapters; L3 = live
   eligibility exists in the ladder but is never granted in this build).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from .constellation import AGENT_SPECS, ts_of
from .events import EventLog, ObjectStore, ExperimentTracker, sha
from .evaluate import Evaluator, Scoreboard
from .exg import ExperienceGraph
from .governance import ContractError, Governance, GoalContract, KillSwitch, Priv, ScopeRouter
from .improve import Harness, HarnessRepo, HarnessEvolution, MetaQueue
from .llm import DeterministicCore
from .perception import (SyntheticMarket, RWADriver, SentimentDriver,
                         OnChainDriver, UNIVERSE)
from .runtime import Planes, Scheduler, Bus
from .tools import Tool, ToolRegistry
from .trading import (PaperBroker, PositionSizer, LiquidationMonitor,
                      ExecutionGateway)
from .wiki import TemporalKG, WikiPages, Claim, Provenance

KEYS = [f"{v}:{s}" for v, s, _ in UNIVERSE]
SYMBOLS = sorted({s for _, s, _ in UNIVERSE})
VENUE_PAIRS = [("binance", "bybit", "BTC-USDT-PERP")]

AUTONOMY_LABELS = {0: "L0 paper-trade only",
                   1: "L1 + harness evolution on siblings",
                   2: "L2 + bounded adapter updates",
                   3: "L3 live-eligible (NEVER granted in this build)"}


@dataclass
class TradingPlane:
    broker: PaperBroker
    sizer: PositionSizer
    liq: LiquidationMonitor
    gateway: ExecutionGateway


@dataclass
class SystemState:
    root: str
    governance: Governance
    audit: EventLog
    router: ScopeRouter
    tools: ToolRegistry
    kg: TemporalKG
    pages: WikiPages
    exg: ExperienceGraph
    bus: Bus
    core: DeterministicCore
    harness: Harness
    planes: Planes
    scheduler: Scheduler
    driver: SyntheticMarket
    trading: TradingPlane
    killswitch: KillSwitch
    evaluator: Evaluator
    board: Scoreboard
    repo: HarnessRepo
    tracker: ExperimentTracker
    evolution: HarnessEvolution
    meta_queue: MetaQueue
    system_contract: GoalContract
    agents: dict = field(default_factory=dict)
    daily_rows: list = field(default_factory=list)


def make_drivers(seed: int, schedule):
    return (SyntheticMarket(seed=seed, schedule=schedule),
            RWADriver(seed), SentimentDriver(seed), OnChainDriver(seed))


def register_tools(tools: ToolRegistry, market, rwa, sent, onchain) -> None:
    """S4: only tools that pass unit tests and scope checks enter the registry."""
    def _t_market():
        ts = market.ticks_at(0, 0)
        return len(ts) == len(UNIVERSE) and all(
            abs(t.funding) < 0.05 and t.spot > 0 for t in ts)

    tools.register(Tool("market_ticks",
                        lambda day, period: market.ticks_at(day, period),
                        {"perception.market"}, [_t_market]))
    tools.register(Tool("rwa_metrics", rwa.metrics, {"perception.rwa"},
                        [lambda: len(rwa.metrics(0)) == 2]))
    tools.register(Tool("x_narrative", sent.narrative, {"perception.sentiment"},
                        [lambda: all(r["narrative_velocity"] >= 0
                                     for r in sent.narrative(0))]))
    tools.register(Tool("onchain_flows", onchain.flows, {"perception.onchain"},
                        [lambda: len(onchain.flows(0)) == len(UNIVERSE)]))


def seed_wiki(state: "SystemState") -> None:
    """Bootstrap step 1 (S7)."""
    p = state.pages
    p.seed("seed:daily_scan_format",
           "# Daily scan format\n1 perception refresh -> 2 analyst -> 3 research "
           "-> 4 sentiment -> 5 opportunity scan -> 6 strategy proposals "
           "(entry/exit, size, risk limits, expected edge) -> 7 exec/risk -> "
           "8 EXG write -> 9 improvement notes -> 10 governance review -> "
           "11 curator merge.")
    p.seed("seed:strategy_templates",
           "# Strategy templates\n- funding_arb: short perp/long spot on "
           "persistent positive funding (mirror for negative).\n- basis_carry: "
           "premium-rich, funding-aligned.\n- rwa_spread: tokenized-yield "
           "spread HIP3 vs USDY.\n- cross_venue: same-symbol funding gap.")
    p.seed("seed:funding_tables",
           "# Funding tables\nPer-venue 8h funding history lives under "
           "market:<venue>:<symbol> / funding_rate_at.")
    p.seed("seed:rwa_metrics",
           "# RWA metrics\nrwa:ondo-usdy and rwa:hip3-rwa carry tvl / yield / "
           "holder_count edges from the rwa.xyz-style driver.")
    prov = Provenance("bootstrap", sha("seed"))
    now = ts_of(0, 0) - 60
    state.kg.apply(state.kg.new_patch(
        [Claim("seed:system", "spec", "ARSIC v1 trading instantiation", now, 1.0, prov),
         Claim("seed:system", "objective",
               "maximize risk-adjusted market-neutral edge; paper-only", now, 1.0, prov)],
        "bootstrap", "governance.seed"), now=now)


def build_system(seed: int, schedule, root: str,
                 secret: str = "arsic-governance-secret") -> SystemState:
    os.makedirs(root, exist_ok=True)
    audit = EventLog(os.path.join(root, "state", "audit.jsonl"))
    gov = Governance(secret, audit)
    router = ScopeRouter(audit)
    tools = ToolRegistry(audit)
    kg = TemporalKG(audit, ObjectStore(os.path.join(root, "state", "objects")))
    pages = WikiPages(kg, audit)
    exg = ExperienceGraph(audit)
    bus = Bus()
    harness = Harness()
    core = DeterministicCore(harness.prompts, harness.adapter)

    market, rwa, sent, onchain = make_drivers(seed, schedule)
    register_tools(tools, market, rwa, sent, onchain)

    system_contract = gov.sign_contract(GoalContract(
        principal="arsic.system",
        objective=("maximize market-neutral risk-adjusted yield (funding/basis/"
                   "RWA spreads) subject to constraints; recursively improve the "
                   "pipeline; NEVER commit live capital without human confirmation"),
        constraints={"max_drawdown": 0.10, "max_leverage": 3.0,
                     "min_liq_score": 0.3, "paper_only": True},
        scopes=("system",)))

    broker = PaperBroker(audit)
    trading = TradingPlane(broker=broker, sizer=PositionSizer(system_contract),
                           liq=LiquidationMonitor(),
                           gateway=ExecutionGateway(broker, gov))
    ks = KillSwitch(gov)
    planes = Planes(gov, router, tools, kg, pages, exg, bus, audit, core,
                    harness=harness, trading=trading, killswitch=ks)
    sched = Scheduler(planes)

    agents = {}
    for cls, aid in AGENT_SPECS:
        contract = gov.sign_contract(GoalContract(
            principal=aid, objective=f"{cls.ROLE} within ARSIC",
            constraints=dict(system_contract.constraints),
            scopes=tuple(cls.SCOPES)))
        a = cls(aid, contract, planes)
        sched.add(a)
        agents[aid] = a

    evaluator = Evaluator()
    board = Scoreboard()
    repo = HarnessRepo(os.path.join(root, "harness_repo"), audit)
    tracker = ExperimentTracker(os.path.join(root, "state", "experiments.jsonl"))
    evolution = HarnessEvolution(gov, system_contract, evaluator, repo, board,
                                 tracker, audit, os.path.join(root, "sandboxes"))
    state = SystemState(root=root, governance=gov, audit=audit, router=router,
                        tools=tools, kg=kg, pages=pages, exg=exg, bus=bus,
                        core=core, harness=harness, planes=planes,
                        scheduler=sched, driver=market, trading=trading,
                        killswitch=ks, evaluator=evaluator, board=board,
                        repo=repo, tracker=tracker, evolution=evolution,
                        meta_queue=MetaQueue(gov), system_contract=system_contract,
                        agents=agents)
    seed_wiki(state)
    repo.commit(harness, "v1: bootstrap harness")
    audit.append("bootstrap.done", {"agents": len(agents),
                                    "autonomy": AUTONOMY_LABELS[0]}, "bootstrap")
    return state


def advance_autonomy(state: SystemState, to_level: int) -> None:
    """S7 step 5: raise autonomy only via human-approved META tickets.
    S11 invariant: the ladder never reaches L3 — live authority can only be
    LENT by a human mandate (arsic.execution_l3), never taken."""
    if to_level >= 3:
        raise ContractError(
            "L3 is never self-grantable: the ladder stops at L2; "
            "a human mandate (execution_l3) is the only live path")
    t = state.governance.request(
        Priv.META, f"advance autonomy to {AUTONOMY_LABELS[to_level]}",
        {"from": state.governance.autonomy_level, "to": to_level}, "bootstrap")
    state.governance.approve(t.tid, actor_role="human")
    state.governance.mark_applied(t)
    state.governance.autonomy_level = to_level
    state.audit.append("autonomy.advanced",
                       {"level": to_level, "label": AUTONOMY_LABELS[to_level]},
                       "human:cli")


def swap_harness(state: SystemState, new_harness: Harness) -> None:
    """Promotion hand-off: live constellation adopts the promoted harness
    (prompts + params + adapter), keeping core/prompts in lockstep."""
    state.harness = new_harness
    state.planes.harness = new_harness
    state.core.prompts = dict(new_harness.prompts)
    state.core.adapter = {**state.core.adapter, **new_harness.adapter}
    state.audit.append("harness.swapped", {"version": new_harness.version},
                       "governance")
