"""ARSIC Constellation Runtime (spec S2 third layer, S4).

Agents are first-class processes: signed goal contract + bounded scope,
private working memory, read access to the shared wiki, validated tool
registry, local planner-executor-verifier loop, and an improvement policy
(what they may propose changing). They can spawn children recursively
(IACT-style call tree); children report structured status upward; the scope
router prevents out-of-scope work; quotas suspend runaway agents; the
scheduler freezes instantly when governance trips the kill-switch."""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Optional

from .events import EventLog
from .governance import Governance, GoalContract, ScopeRouter
from .tools import ToolRegistry


class QuotaExceeded(Exception):
    pass


@dataclass
class Task:
    tid: str
    kind: str
    scopes: set
    payload: dict
    origin: str = "system"


@dataclass
class Quotas:
    tool_calls: int = 5000
    llm_calls: int = 5000
    spawns: int = 200

    def spend(self, kind: str, n: int = 1) -> None:
        cur = getattr(self, kind)
        if cur - n < 0:
            raise QuotaExceeded(kind)
        setattr(self, kind, cur - n)


class Bus:
    def __init__(self):
        self.topics: dict[str, list] = {}

    def publish(self, topic: str, msg: dict) -> None:
        self.topics.setdefault(topic, []).append(msg)

    def drain(self, topic: str) -> list:
        msgs = self.topics.get(topic, [])
        self.topics[topic] = []
        return msgs

    def peek(self, topic: str) -> list:
        return list(self.topics.get(topic, []))


class AgentProcess:
    ROLE = "agent"
    SCOPES: set = set()
    IMPROVEMENT_POLICY = "may propose SKILL-level changes to own prompts/params only"

    def __init__(self, aid: str, contract: GoalContract, planes: "Planes",
                 quotas: Optional[Quotas] = None):
        self.id = aid
        self.contract = contract
        self.scopes = set(contract.scopes)
        self.planes = planes
        self.quotas = quotas or Quotas()
        self.memory: dict = {}                 # private working memory
        self.children: list[AgentProcess] = []
        self.parent: Optional[AgentProcess] = None
        self.status: dict = {"state": "idle"}
        self.suspended = False
        self._retries = 1

    # -- planner -> executor -> verifier loop (S4) -------------------------
    def plan(self, task: Task) -> list:
        return [task.payload]

    def execute(self, step: dict, task: Task) -> dict:
        raise NotImplementedError

    def verify(self, result: dict, task: Task) -> bool:
        return result is not None and "error" not in result

    def handle(self, task: Task) -> Optional[dict]:
        router = self.planes.router
        if not router.check(self.id, task.scopes):
            router.route(task.tid, task.scopes, {"payload": task.payload,
                                                 "refused_by": self.id}, self.id)
            self.planes.audit.append("agent.refused_out_of_scope",
                                     {"agent": self.id, "task": task.tid}, self.id)
            return None
        if not self.planes.governance.verify_contract(self.contract):
            raise PermissionError(f"{self.id}: invalid goal contract signature")
        last = None
        for step in self.plan(task):
            attempt, ok = 0, False
            while attempt <= self._retries and not ok:
                try:
                    last = self.execute(step, task)
                except QuotaExceeded:
                    self.suspended = True
                    self.status = {"state": "suspended", "why": "quota"}
                    self.planes.audit.append("agent.suspended",
                                             {"agent": self.id}, "scheduler")
                    return None
                ok = self.verify(last, task)
                attempt += 1
            if not ok:
                self.status = {"state": "verify_failed", "task": task.tid}
                return None
        self.status = {"state": "done", "task": task.tid}
        return last

    # -- recursive spawning (IACT-style call tree) -------------------------
    def spawn(self, child_cls, aid: str, task: Task):
        self.quotas.spend("spawns")
        contract = self.planes.governance.sign_contract(GoalContract(
            principal=aid, objective=f"child of {self.id}: {task.kind}",
            constraints=dict(self.contract.constraints),
            scopes=tuple(child_cls.SCOPES)))
        child = child_cls(aid, contract, self.planes)
        child.parent = self
        self.children.append(child)
        self.planes.router.register(aid, child.scopes)
        self.planes.audit.append("agent.spawned", {"parent": self.id,
                                                   "child": aid,
                                                   "task": task.tid}, self.id)
        result = child.handle(task)
        self.report_up(child, result)
        return result

    def report_up(self, child: "AgentProcess", result: Optional[dict]) -> None:
        self.memory.setdefault("child_reports", []).append(
            {"child": child.id, "status": child.status, "result": result})


class Planes:
    """Bundle of the shared planes an agent may touch (never raw disk/APIs)."""

    def __init__(self, governance: Governance, router: ScopeRouter,
                 tools: ToolRegistry, wiki, pages, exg, bus: Bus,
                 audit: EventLog, core, harness=None, trading=None,
                 killswitch=None):
        self.governance = governance
        self.router = router
        self.tools = tools
        self.wiki = wiki
        self.pages = pages
        self.exg = exg
        self.bus = bus
        self.audit = audit
        self.core = core
        self.harness = harness
        self.trading = trading
        self.killswitch = killswitch


class Scheduler:
    """Process scheduler for the constellation. Respects governance.frozen
    (kill-switch => no agent steps, S6)."""

    def __init__(self, planes: Planes):
        self.planes = planes
        self.agents: dict[str, AgentProcess] = {}
        self._task_i = itertools.count(1)
        planes.governance.on_freeze(self._on_freeze)
        self.frozen = planes.governance.frozen

    def _on_freeze(self, frozen: bool, reason: str) -> None:
        self.frozen = frozen

    def add(self, agent: AgentProcess) -> None:
        self.agents[agent.id] = agent
        self.planes.router.register(agent.id, agent.scopes)

    def retire(self, aid: str) -> None:
        self.agents.pop(aid, None)
        self.planes.audit.append("agent.retired", {"agent": aid}, "scheduler")

    def new_task(self, kind: str, scopes: set, payload: dict) -> Task:
        return Task(tid=f"K{next(self._task_i):05d}", kind=kind,
                    scopes=set(scopes), payload=payload)

    def dispatch(self, aid: str, task: Task) -> Optional[dict]:
        if self.frozen:
            self.planes.audit.append("scheduler.frozen_skip",
                                     {"agent": aid, "task": task.tid}, "scheduler")
            return None
        agent = self.agents[aid]
        if agent.suspended:
            return None
        return agent.handle(task)

    def tree(self) -> dict:
        def node(a: AgentProcess) -> dict:
            return {"id": a.id, "role": a.ROLE, "status": a.status,
                    "children": [node(c) for c in a.children]}
        roots = [a for a in self.agents.values() if a.parent is None]
        return {"agents": [node(a) for a in roots]}
