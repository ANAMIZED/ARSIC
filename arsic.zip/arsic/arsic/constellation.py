"""ARSIC core constellation for the trading domain (spec S4, S8).

Direct mapping of the spec's agent list:
  Perception : MarketDataAgent, OnChainAgent, SentimentAgent, RWAAgent
  Research   : MarketAnalystAgent, ResearchAnalystAgent,
               SentimentNarrativeAgent, OpportunityScannerAgent (+ DeepDiveAgent child)
  Strategy   : FundingArbAgent, BasisCarryAgent, RWASpreadAgent, CrossVenueAgent
  Exec/Risk  : SizingExecAgent (paper-trade simulator + position sizing),
               LiquidationMonitorAgent, KillSwitchAgent
  Meta       : WikiCuratorAgent, EXGWriterAgent, ImprovementProposerAgent,
               EvaluatorAgent

Agents read the wiki, never the raw firehose (S3); perception agents are the
only ones with driver-tool scopes (S2). All entry/exit math is shared with the
sandbox sibling simulator via strategy_math (single source of truth for S5).
"""
from __future__ import annotations

from dataclasses import asdict
from typing import Optional

from . import strategy_math as sm
from .exg import Trajectory
from .governance import Priv, Frozen
from .perception import Tick, PERIODS_PER_DAY
from .runtime import AgentProcess, Task, Quotas
from .trading import RiskVeto, LiveTradeRejected
from .wiki import Claim, Provenance

T0 = 1_700_000_000.0


def ts_of(day: int, period: int) -> float:
    return T0 + day * 86400.0 + period * 28800.0


def mkey(t: Tick) -> str:
    return f"market:{t.venue}:{t.symbol}"


# --------------------------------------------------------------------------
# Perception plane (S4): read raw sources ONCE via validated tools, compile
# into durable wiki claims. Predicates match spec S3 examples.
# --------------------------------------------------------------------------

class MarketDataAgent(AgentProcess):
    ROLE = "perception.market"
    SCOPES = {"perception.market"}

    def execute(self, step: dict, task: Task) -> dict:
        day, period = step["day"], step["period"]
        ticks = self.planes.tools.call(self, "market_ticks", day, period)
        claims = []
        now = ts_of(day, period)
        for t in ticks:
            prov = Provenance(source_id=f"{t.venue}:api",
                              source_hash=_h(t))
            s = mkey(t)
            claims += [
                Claim(s, "funding_rate_at", t.funding, now, 0.95, prov),
                Claim(s, "basis_vs_spot", t.premium, now, 0.9, prov),
                Claim(s, "volume_24h", t.volume, now, 0.85, prov, ttl=2 * 86400),
                Claim(s, "open_interest", t.oi, now, 0.9, prov),
                Claim(s, "spot", t.spot, now, 0.9, prov),
                Claim(s, "liq_score", t.liq_score, now, 0.99, prov),
            ]
        patch = self.planes.wiki.new_patch(claims, self.id, "perception.market")
        outcomes = self.planes.wiki.apply(patch, now=now)
        self.memory["last_ticks"] = {t2.key(): t2 for t2 in ticks}
        return {"n_claims": len(claims), "outcomes": outcomes}


class OnChainAgent(AgentProcess):
    ROLE = "perception.onchain"
    SCOPES = {"perception.onchain"}

    def execute(self, step: dict, task: Task) -> dict:
        day = step["day"]
        rows = self.planes.tools.call(self, "onchain_flows", day)
        now = ts_of(day, 0)
        claims = [Claim(f"onchain:{r['symbol']}", "netflow", r["netflow"], now, 0.8,
                        Provenance("onchain:node", _h(r)), ttl=3 * 86400)
                  for r in rows]
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            claims, self.id, "perception.onchain"), now=now)
        return {"n_claims": len(claims)}


class SentimentAgent(AgentProcess):
    ROLE = "perception.sentiment"
    SCOPES = {"perception.sentiment"}

    def execute(self, step: dict, task: Task) -> dict:
        day = step["day"]
        rows = self.planes.tools.call(self, "x_narrative", day)
        now = ts_of(day, 0)
        claims = [Claim(f"sent:{r['symbol']}", "narrative_velocity",
                        r["narrative_velocity"], now, 0.7,
                        Provenance("x:keyword_search", _h(r)), ttl=2 * 86400)
                  for r in rows]
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            claims, self.id, "perception.sentiment"), now=now)
        return {"n_claims": len(claims)}


class RWAAgent(AgentProcess):
    ROLE = "perception.rwa"
    SCOPES = {"perception.rwa"}

    def execute(self, step: dict, task: Task) -> dict:
        day = step["day"]
        rows = self.planes.tools.call(self, "rwa_metrics", day)
        now = ts_of(day, 0)
        claims = []
        for r in rows:
            prov = Provenance("rwa.xyz", _h(r))
            e = r["entity"]
            claims += [Claim(e, "tvl", r["tvl"], now, 0.85, prov),
                       Claim(e, "yield", r["yield"], now, 0.85, prov),
                       Claim(e, "holder_count", r["holder_count"], now, 0.85, prov)]
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            claims, self.id, "perception.rwa"), now=now)
        return {"n_claims": len(claims)}


# --------------------------------------------------------------------------
# Research plane (S4): wiki-only readers.
# --------------------------------------------------------------------------

def stats_from_wiki(planes, key: str, now: float) -> Optional[sm.SymStats]:
    subj = f"market:{key}"
    hist = [r["value"] for r in planes.wiki.history(subj, "funding_rate_at")
            if r["ts"] <= now]
    if len(hist) < 4:
        return None
    basis = planes.wiki.latest(subj, "basis_vs_spot", at=now)
    liq = planes.wiki.latest(subj, "liq_score", at=now)
    return sm.rolling_stats(hist, liq["value"] if liq else 0.0,
                            basis["value"] if basis else 0.0, key)


class MarketAnalystAgent(AgentProcess):
    ROLE = "research.market_analyst"
    SCOPES = {"research.analysis"}

    def execute(self, step: dict, task: Task) -> dict:
        day, period = step["day"], step["period"]
        now = ts_of(day, period)
        keys = step["keys"]
        out = []
        for key in keys:
            s = stats_from_wiki(self.planes, key, now)
            if s is None:
                continue
            self.quotas.spend("llm_calls")
            note = self.planes.core.complete("market_analysis",
                                             self.planes.harness.prompts["market_analysis"],
                                             {"stats": s})
            prov = Provenance("wiki:derived", _h(note))
            claims = [Claim(f"analysis:{key}", "streak", s.streak, now, 0.9, prov),
                      Claim(f"analysis:{key}", "zscore", round(s.z, 3), now, 0.9, prov),
                      Claim(f"analysis:{key}", "summary", note["summary"], now, 0.8, prov),
                      Claim(f"analysis:{key}", "about", f"market:{key}", now, 0.99,
                            prov, relation=True)]
            self.planes.wiki.apply(self.planes.wiki.new_patch(
                claims, self.id, "research.analysis"), now=now)
            out.append(s)
        self.memory["stats"] = {s.key: s for s in out}
        return {"analyzed": len(out)}


class ResearchAnalystAgent(AgentProcess):
    """Cross-links RWA / on-chain context into research notes (S4)."""
    ROLE = "research.research_analyst"
    SCOPES = {"research.analysis"}

    def execute(self, step: dict, task: Task) -> dict:
        day = step["day"]
        now = ts_of(day, 0)
        y1 = self.planes.wiki.latest("rwa:hip3-rwa", "yield", at=now + 1)
        y0 = self.planes.wiki.latest("rwa:ondo-usdy", "yield", at=now + 1)
        spread = (y1["value"] - y0["value"]) if (y1 and y0) else 0.0
        prov = Provenance("wiki:derived", _h({"spread": spread}))
        claims = [Claim("analysis:rwa", "yield_spread_hip3_vs_usdy",
                        round(spread, 5), now, 0.85, prov),
                  Claim("analysis:rwa", "about", "rwa:hip3-rwa", now, 0.99,
                        prov, relation=True)]
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            claims, self.id, "research.analysis"), now=now)
        return {"rwa_spread": spread}


class SentimentNarrativeAgent(AgentProcess):
    ROLE = "research.sentiment"
    SCOPES = {"research.analysis"}

    def execute(self, step: dict, task: Task) -> dict:
        day = step["day"]
        now = ts_of(day, 0)
        hot = []
        for sym in step["symbols"]:
            r = self.planes.wiki.latest(f"sent:{sym}", "narrative_velocity", at=now + 1)
            if r and r["value"] > 0.6:
                hot.append(sym)
        prov = Provenance("wiki:derived", _h(hot))
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            [Claim("analysis:narrative", "hot_symbols", hot, now, 0.7, prov)],
            self.id, "research.analysis"), now=now)
        return {"hot": hot}


class DeepDiveAgent(AgentProcess):
    """Child agent spawned recursively for sub-problems, e.g. 'deep-dive this
    extreme MOVE funding rate' (S4 IACT-style call tree)."""
    ROLE = "research.deep_dive"
    SCOPES = {"research.analysis"}

    def execute(self, step: dict, task: Task) -> dict:
        key, now = step["key"], step["now"]
        hist = [r["value"] for r in
                self.planes.wiki.history(f"market:{key}", "funding_rate_at")
                if r["ts"] <= now]
        zs = []
        for i in range(4, len(hist) + 1):
            zs.append(sm.rolling_stats(hist[:i], 1.0, 0.0, key).z)
        self.quotas.spend("llm_calls")
        v = self.planes.core.complete("deep_dive", "", {"z_history": zs[-8:]})
        prov = Provenance("wiki:deep_dive", _h(v))
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            [Claim(f"analysis:{key}", "deep_dive_verdict", v["verdict"],
                   now, 0.85, prov)], self.id, "research.analysis"), now=now)
        return {"key": key, **v}


class OpportunityScannerAgent(AgentProcess):
    ROLE = "research.opportunity_scanner"
    SCOPES = {"research.analysis"}

    def execute(self, step: dict, task: Task) -> dict:
        day, period, keys = step["day"], step["period"], step["keys"]
        now = ts_of(day, period)
        p = sm.apply_adapter(self.planes.harness.strategy, self.planes.core.adapter)
        ops = []
        for key in keys:
            s = stats_from_wiki(self.planes, key, now)
            if s is None:
                continue
            sig = sm.should_enter(s, p)
            if not sig:
                continue
            if sig["borderline"]:
                # spawn a child deep-dive on suspicious extremes (S4)
                tag = f"{key}:{day}"
                if tag not in self.memory.setdefault("dived", set()):
                    self.memory["dived"].add(tag)
                    t = Task(tid=f"{task.tid}.dd", kind="deep_dive",
                             scopes={"research.analysis"},
                             payload={"key": key, "now": now}, origin=self.id)
                    r = self.spawn(DeepDiveAgent, f"{self.id}.dd.{day}.{key[-6:]}", t)
                    if r and r["verdict"] == "unsustainable_extreme":
                        continue
            sig["stats"] = s
            ops.append(sig)
        self.quotas.spend("llm_calls")
        ranked = self.planes.core.complete(
            "opportunity_rank", self.planes.harness.prompts.get("opportunity_rank", ""),
            {"ops": ops})["ranked"]
        self.planes.bus.publish("ops", {"day": day, "period": period, "ops": ranked})
        return {"n_ops": len(ranked)}


# --------------------------------------------------------------------------
# Strategy plane (S4): ranked proposals with entry/exit rules, size
# guidelines, risk limits and expected edge (S8 step 3).
# --------------------------------------------------------------------------

def _proposal(kind: str, key: str, side: int, edge: float, p: dict,
              extreme: bool, extra: str = "") -> dict:
    return {"kind": kind, "key": key, "side": side, "expected_edge": edge,
            "extreme_entry": extreme,
            "entry_rule": f"|f|>={p['f_min']:.4%}/8h, streak>={p['persistence_min']}, |z|<={p['z_cap']}",
            "exit_rule": f"funding flips x{p['exit_flip_k']} | hold>={p['max_hold_periods']} | reversal extreme",
            "size_guideline": "min(10% equity, 0.5*lev headroom, 0.1% OI)",
            "risk_limits": {"max_leverage": p["max_leverage"],
                            "dd_budget": p["dd_budget"],
                            "min_liq_score": p["min_liq_score"]},
            "note": extra}


class FundingArbAgent(AgentProcess):
    ROLE = "strategy.funding_arb"
    SCOPES = {"strategy.write"}

    def execute(self, step: dict, task: Task) -> dict:
        p = self.planes.harness.strategy
        props = []
        for m in self.planes.bus.drain("ops"):
            for o in m["ops"]:
                props.append(_proposal("funding_arb", o["key"], o["side"],
                                       o["edge"], p, o["extreme_entry"], o["reason"]))
        for pr in props:
            self.planes.bus.publish("proposals", pr)
        if props:
            now = ts_of(step["day"], step["period"])
            prov = Provenance("wiki:strategy", _h(props[0]))
            self.planes.wiki.apply(self.planes.wiki.new_patch(
                [Claim("strategy:funding_arb", "latest_proposals",
                       [pr["key"] for pr in props], now, 0.9, prov)],
                self.id, "strategy.write"), now=now)
        return {"n_proposals": len(props)}


class BasisCarryAgent(AgentProcess):
    """Basis / cash-and-carry: flags proposals where premium is rich AND
    aligned with funding (extra edge from premium convergence)."""
    ROLE = "strategy.basis_carry"
    SCOPES = {"strategy.write"}

    def execute(self, step: dict, task: Task) -> dict:
        day, period, keys = step["day"], step["period"], step["keys"]
        now = ts_of(day, period)
        p = self.planes.harness.strategy
        n = 0
        for key in keys:
            s = stats_from_wiki(self.planes, key, now)
            if s is None or abs(s.basis) < p["basis_min"]:
                continue
            if s.basis * s.funding <= 0:
                continue
            side = 1 if s.basis > 0 else -1
            self.planes.bus.publish("proposals", _proposal(
                "basis_carry", key, side, abs(s.basis) * 0.5, p, abs(s.z) > 2.5,
                f"basis={s.basis:+.3%} aligned with funding"))
            n += 1
        return {"n_proposals": n}


class RWASpreadAgent(AgentProcess):
    ROLE = "strategy.rwa_spread"
    SCOPES = {"strategy.write"}

    def execute(self, step: dict, task: Task) -> dict:
        day = step["day"]
        now = ts_of(day, PERIODS_PER_DAY - 1)
        r = self.planes.wiki.latest("analysis:rwa", "yield_spread_hip3_vs_usdy",
                                    at=now + 1)
        p = self.planes.harness.strategy
        if r and r["value"] >= p["rwa_spread_min"]:
            pr = _proposal("rwa_spread", "rwa:hip3-rwa/ondo-usdy", 1,
                           r["value"] / 365 * 30, p, False,
                           f"tokenized-yield spread {r['value']:.2%} (30d carry est.)")
            pr["execution"] = "proposal-level (off-perp venue; human desk executes)"
            self.planes.bus.publish("proposals", pr)
            return {"n_proposals": 1}
        return {"n_proposals": 0}


class CrossVenueAgent(AgentProcess):
    """Cross-venue funding-gap arb on the same symbol (S4)."""
    ROLE = "strategy.cross_venue"
    SCOPES = {"strategy.write"}

    def execute(self, step: dict, task: Task) -> dict:
        day, period = step["day"], step["period"]
        now = ts_of(day, period)
        p = self.planes.harness.strategy
        pairs = step["venue_pairs"]           # [(venueA, venueB, symbol)]
        n = 0
        for va, vb, sym in pairs:
            fa = self.planes.wiki.latest(f"market:{va}:{sym}", "funding_rate_at", at=now + 1)
            fb = self.planes.wiki.latest(f"market:{vb}:{sym}", "funding_rate_at", at=now + 1)
            if not (fa and fb):
                continue
            gap = fa["value"] - fb["value"]
            if abs(gap) < p["xv_gap_min"]:
                continue
            side = 1 if gap > 0 else -1       # short perp on high-funding venue
            self.planes.bus.publish("proposals", _proposal(
                "cross_venue", f"xv:{va}>{vb}:{sym}", side,
                abs(gap) * p["expected_hold_periods"] * 0.6 - sm.COST_ROUNDTRIP,
                p, False, f"funding gap {gap:+.4%}/8h ({va} vs {vb})"))
            n += 1
        return {"n_proposals": n}


# --------------------------------------------------------------------------
# Execution & Risk plane (S4): paper-trade simulator, position sizing,
# liquidation monitor, kill-switch feed.
# --------------------------------------------------------------------------

class SizingExecAgent(AgentProcess):
    ROLE = "risk.sizing_exec"
    SCOPES = {"risk.exec"}
    MAX_CONCURRENT = 4

    def execute(self, step: dict, task: Task) -> dict:
        tr = self.planes.trading
        day, period = step["day"], step["period"]
        now = ts_of(day, period)
        ticks: dict = step["ticks"]
        # cross-venue virtual ticks for open xv positions + fresh proposals
        ticks = dict(ticks)
        self._add_virtual_ticks(ticks, day, period)
        # 1) accrue open positions, then evaluate exits with shared math
        tr.broker.on_period(ticks)
        self._exits(ticks, now)
        # 2) liquidation monitor runs inside its own agent (see below)
        # 3) entries from ranked proposals
        opened = vetoes = 0
        for pr in self.planes.bus.drain("proposals"):
            if pr.get("execution", "").startswith("proposal-level"):
                self.memory.setdefault("desk_queue", []).append(pr)
                continue
            key = pr["key"]
            if key in tr.broker.positions or \
                    len(tr.broker.positions) >= self.MAX_CONCURRENT:
                continue
            t = ticks.get(key)
            if t is None:
                continue
            try:
                notional, lev = tr.sizer.size(pr["expected_edge"], t.liq_score,
                                              t.oi, tr.broker.equity)
                if notional <= 0:
                    continue
                pos = tr.gateway.submit(key, pr["side"], notional, lev, t,
                                        {"entry_z": pr.get("stats_z", 0.0)},
                                        pr["extreme_entry"])
                pos.entry_stats.update({"entry_f": t.funding,
                                        "entry_streak": 0, "kind": pr["kind"]})
                self.memory.setdefault("pos_meta", {})[key] = {
                    "flip_count": 0, "features": self._features(key, now, t)}
                opened += 1
            except (RiskVeto, LiveTradeRejected):
                vetoes += 1
            except Frozen:
                return {"opened": opened, "skipped": "frozen"}
        return {"opened": opened, "vetoes": vetoes,
                "open_now": len(tr.broker.positions)}

    def _features(self, key: str, now: float, t: Tick) -> dict:
        s = stats_from_wiki(self.planes, key, now) if not key.startswith("xv:") else None
        return {"funding": s.funding if s else t.funding,
                "z": s.z if s else 0.0, "streak": s.streak if s else 0,
                "liq": t.liq_score}

    def _add_virtual_ticks(self, ticks: dict, day: int, period: int) -> None:
        for key in list(self.planes.trading.broker.positions) + \
                   [m["key"] for m in self.planes.bus.peek("proposals")
                    if m["kind"] == "cross_venue"]:
            if not key.startswith("xv:") or key in ticks:
                continue
            _, rest = key.split("xv:")
            venues, sym = rest.split(":")
            va, vb = venues.split(">")
            ta, tb = ticks.get(f"{va}:{sym}"), ticks.get(f"{vb}:{sym}")
            if ta and tb:
                ticks[key] = Tick(day=day, period=period, venue="xv", symbol=sym,
                                  spot=ta.spot, perp=ta.spot * (1 + ta.premium - tb.premium),
                                  funding=ta.funding - tb.funding,
                                  oi=min(ta.oi, tb.oi), volume=min(ta.volume, tb.volume),
                                  liq_score=min(ta.liq_score, tb.liq_score))

    def _exits(self, ticks: dict, now: float) -> None:
        tr = self.planes.trading
        p = sm.apply_adapter(self.planes.harness.strategy, self.planes.core.adapter)
        for key in list(tr.broker.positions):
            pos = tr.broker.positions[key]
            t = ticks.get(key)
            if t is None:
                continue
            if key.startswith("xv:"):
                s = sm.SymStats(key=key, funding=t.funding, streak=1, z=0.0,
                                basis=t.premium, liq=t.liq_score, mean_f=t.funding)
            else:
                s = stats_from_wiki(self.planes, key, now) or \
                    sm.SymStats(key, t.funding, 1, 0.0, t.premium, t.liq_score, t.funding)
            meta = self.memory.setdefault("pos_meta", {}).setdefault(
                key, {"flip_count": 0, "features": self._features(key, now, t)})
            state = {"side": pos.side, "hold": pos.hold,
                     "flip_count": meta["flip_count"]}
            why = sm.should_exit(state, s, p)
            meta["flip_count"] = state["flip_count"]
            if why:
                closed = tr.broker.close(key)
                is_fp = closed.extreme_entry and closed.hold <= 3 and closed.net < 0
                self.planes.bus.publish("closed", {
                    "pid": closed.pid, "key": key, "why": why, "net": closed.net,
                    "funding_pnl": closed.funding_pnl, "hold": closed.hold,
                    "fp": is_fp, "extreme": closed.extreme_entry,
                    "features": meta["features"], "side": closed.side})
                self.memory["pos_meta"].pop(key, None)


class LiquidationMonitorAgent(AgentProcess):
    ROLE = "risk.liquidation_monitor"
    SCOPES = {"risk.exec"}

    def execute(self, step: dict, task: Task) -> dict:
        tr = self.planes.trading
        ticks: dict = step["ticks"]
        actions = []
        for key in list(tr.broker.positions):
            t = ticks.get(key)
            if t is None:
                continue
            verdict = tr.liq.assess(tr.broker.positions[key], t.premium)
            if verdict == "reduce":
                closed = tr.broker.close(key)
                self.planes.audit.append("risk.forced_reduce",
                                         {"pid": closed.pid, "key": key}, self.id)
                self.planes.bus.publish("closed", {
                    "pid": closed.pid, "key": key, "why": "liq_reduce",
                    "net": closed.net, "funding_pnl": closed.funding_pnl,
                    "hold": closed.hold, "fp": False, "extreme": closed.extreme_entry,
                    "features": {}, "side": closed.side})
            actions.append((key, verdict))
        # drawdown-budget breach => flatten (contract enforcement)
        if tr.broker.max_dd() > self.contract.constraints.get("max_drawdown", 0.10):
            tr.broker.flatten_all()
            self.planes.audit.append("risk.dd_flatten",
                                     {"dd": tr.broker.max_dd()}, self.id)
        return {"checks": actions}


class KillSwitchAgent(AgentProcess):
    """Feeds the S6 circuit breakers each period from wiki-visible state."""
    ROLE = "risk.killswitch"
    SCOPES = {"risk.exec"}

    def execute(self, step: dict, task: Task) -> dict:
        day, period = step["day"], step["period"]
        now = ts_of(day, period)
        max_f, oi_z, diverg = 0.0, 0.0, False
        for key in step["keys"]:
            f = self.planes.wiki.latest(f"market:{key}", "funding_rate_at", at=now + 1)
            if f:
                max_f = max(max_f, abs(f["value"]))
            oih = [r["value"] for r in
                   self.planes.wiki.history(f"market:{key}", "open_interest")
                   if r["ts"] <= now][-12:]
            # spike test on one-step returns (levels random-walk, so a level
            # z-score false-positives during warm-up); needs >=6 baseline rets
            rets = [oih[i] / oih[i - 1] - 1.0 for i in range(1, len(oih))]
            if len(rets) >= 7:
                import statistics as st
                base = rets[:-1]
                sd = max(st.pstdev(base), 0.03)      # 3% relative floor
                z = (rets[-1] - st.fmean(base)) / sd
                if z > oi_z:
                    oi_z = z
                    sp = [r["value"] for r in
                          self.planes.wiki.history(f"market:{key}", "spot")
                          if r["ts"] <= now][-2:]
                    if f and len(sp) == 2:
                        diverg = (sp[1] - sp[0]) * f["value"] < 0
        snap = {"max_abs_funding": max_f, "oi_z": oi_z,
                "price_divergence": diverg,
                "wiki_conflict_rate": self.planes.wiki.conflict_rate(),
                "evaluator_score": self.memory.get("last_score")}
        hit = self.planes.killswitch.evaluate(snap)
        return {"snapshot": snap, "tripped": hit}


# --------------------------------------------------------------------------
# Meta agents (S4): Wiki Curator, Experience Graph Writer, Improvement
# Proposer, Evaluator.
# --------------------------------------------------------------------------

class WikiCuratorAgent(AgentProcess):
    ROLE = "meta.wiki_curator"
    SCOPES = {"meta.write", "research.analysis"}

    def execute(self, step: dict, task: Task) -> dict:
        day = step["day"]
        now = ts_of(day, PERIODS_PER_DAY - 1) + 1
        expired = self.planes.wiki.sweep_invalidation(now=now)
        n_pages = self.planes.pages.compile_all(now=now)     # nightly rebuild
        fresh = self.planes.pages.freshness(now=now)
        prov = Provenance("wiki:curator", _h({"day": day}))
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            [Claim("meta:wiki", "freshness", round(fresh, 3), now, 0.99, prov),
             Claim("meta:wiki", "conflict_rate",
                   round(self.planes.wiki.conflict_rate(), 4), now, 0.99, prov)],
            self.id, "meta.write"), now=now)
        self.planes.pages.surgical("meta:wiki", now=now)     # surgical merge path
        return {"pages": n_pages, "expired": expired, "freshness": fresh}


class EXGWriterAgent(AgentProcess):
    ROLE = "meta.exg_writer"
    SCOPES = {"meta.write"}

    def verify_traj(self, msg: dict) -> bool:
        return all(k in msg for k in ("net", "funding_pnl", "hold", "features")) \
            and abs(msg["net"]) < 1e6

    def execute(self, step: dict, task: Task) -> dict:
        day, regime = step["day"], step["regime"]
        added = []
        for m in self.planes.bus.drain("closed"):
            t = Trajectory(tid="", run_id=f"day{day}", regime=regime,
                           features=m["features"],
                           actions=[{"enter": m["side"], "exit": m["why"],
                                     "key": m["key"]}],
                           outcome={"pnl": m["net"], "funding_pnl": m["funding_pnl"],
                                    "fp": m["fp"], "hold": m["hold"]},
                           verified=self.verify_traj(m))
            self.planes.exg.add(t)
            added.append(t)
        if added:
            self.quotas.spend("llm_calls")
            pr = self.planes.core.complete("principle_abstract", "", {
                "trajs": [{"outcome": t.outcome} for t in added]})
            self.planes.exg.add_principle(pr["principle"], [t.tid for t in added])
        return {"trajectories": len(added)}


class ImprovementProposerAgent(AgentProcess):
    """S8 step 5: scans for data gaps, prompt mutations, new tool needs,
    topology changes; self-improvement notes become first-class tickets."""
    ROLE = "meta.improvement_proposer"
    SCOPES = {"meta.write"}
    IMPROVEMENT_POLICY = "proposes SKILL..META tickets; never applies them itself"

    def execute(self, step: dict, task: Task) -> dict:
        m = step["metrics"]
        notes, tickets = [], []
        if m.get("fp_rate", 0) > 0.10:
            notes.append("high false-positive rate on extreme funding prints; "
                         "tighten z_cap + require [[EXTREME_DISCOUNT]] in analyst prompt")
            t = self.planes.governance.request(
                Priv.SKILL, "candidate: tighten extreme filter",
                {"diff": {"strategy.z_cap": 2.5, "strategy.persistence_min": 3,
                          "prompts.market_analysis": "+[[EXTREME_DISCOUNT]]"},
                 "rationale": notes[-1]}, self.id)
            tickets.append(t.tid)
        if m.get("capture_eff", 1) < 0.25:
            notes.append("capture efficiency low vs oracle; consider routing "
                         "cross-venue precheck earlier (topology change)")
            t = self.planes.governance.request(
                Priv.POLICY, "candidate: cross-venue precheck in topology",
                {"diff": {"routing.cross_venue_precheck": True,
                          "strategy.xv_gap_min": 0.0005},
                 "rationale": notes[-1]}, self.id)
            tickets.append(t.tid)
        now = ts_of(step["day"], PERIODS_PER_DAY - 1) + 2
        prov = Provenance("wiki:improvement", _h(notes))
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            [Claim("meta:improvement_notes", f"day_{step['day']}", notes or ["none"],
                   now, 0.9, prov)], self.id, "meta.write"), now=now)
        return {"notes": notes, "tickets": tickets}


class EvaluatorAgent(AgentProcess):
    ROLE = "meta.evaluator"
    SCOPES = {"meta.write"}

    def execute(self, step: dict, task: Task) -> dict:
        m, score = step["metrics"], step["score"]
        now = ts_of(step["day"], PERIODS_PER_DAY - 1) + 3
        prov = Provenance("wiki:evaluator", _h(m))
        self.planes.wiki.apply(self.planes.wiki.new_patch(
            [Claim("meta:evaluator", "daily_score", round(score, 4), now, 0.95, prov),
             Claim("meta:evaluator", "fp_rate", round(m.get("fp_rate", 0), 4),
                   now, 0.95, prov)], self.id, "meta.write"), now=now)
        return {"score": score}


def _h(obj) -> str:
    from .events import sha
    return sha(obj)


AGENT_SPECS = [  # (class, agent_id)
    (MarketDataAgent, "perc.market"), (OnChainAgent, "perc.onchain"),
    (SentimentAgent, "perc.sentiment"), (RWAAgent, "perc.rwa"),
    (MarketAnalystAgent, "res.market_analyst"),
    (ResearchAnalystAgent, "res.research_analyst"),
    (SentimentNarrativeAgent, "res.sentiment"),
    (OpportunityScannerAgent, "res.opportunity_scanner"),
    (FundingArbAgent, "strat.funding_arb"), (BasisCarryAgent, "strat.basis_carry"),
    (RWASpreadAgent, "strat.rwa_spread"), (CrossVenueAgent, "strat.cross_venue"),
    (SizingExecAgent, "risk.sizing_exec"),
    (LiquidationMonitorAgent, "risk.liq_monitor"),
    (KillSwitchAgent, "risk.killswitch"),
    (WikiCuratorAgent, "meta.wiki_curator"), (EXGWriterAgent, "meta.exg_writer"),
    (ImprovementProposerAgent, "meta.improvement_proposer"),
    (EvaluatorAgent, "meta.evaluator"),
]
