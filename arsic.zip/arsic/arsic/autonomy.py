"""S10: autonomous knowledge→improvement loop (Python mirror of the JS
engine's autonomy section). The constellation closes its own loop: detect
wiki gaps → gather targeted information through the SAME governed agent
machinery (scopes, quotas, audit) → mine improvement candidates FROM that
knowledge → run evolution epochs on a cadence. Autonomy stays inside the
envelope: SKILL promotions auto-execute, POLICY/ADAPTER queue for the human
keys, standing human approvals transfer to identical re-proposals (audited),
and a frozen system refuses to tick until a human resets it.
"""
from __future__ import annotations

import statistics as st

from .constellation import ts_of
from .cycle import KEYS
from .governance import Priv
from .evaluate import live_metrics
from .strategy_math import oracle_funding_pnl


def ensure_days(state, upto: int) -> bool:
    d = state.driver
    if upto < d.total_days:
        return False
    base = list(d.schedule) if not getattr(state, "_base_schedule", None) \
        else state._base_schedule
    state._base_schedule = base
    length = sum(n for _, n in base)
    k = (upto // length) + 1
    d.schedule = [seg for _ in range(k) for seg in base]
    d.total_days = k * length
    d._build()                       # same seed ⇒ identical prefix
    state.audit.append("world.extended", {"total_days": d.total_days},
                       "scheduler")
    return True


def scan_gaps(state, day: int) -> dict:
    now = ts_of(day, 0)
    gaps = {"stale": [], "lowConf": [], "uncovered": [],
            "arbiter": len(state.kg.arbiter_queue)}
    for name, pg in state.pages.pages.items():
        if name.startswith("seed:"):
            continue
        if now - pg["ts"] > 0.75 * 86400:
            gaps["stale"].append(name)
    for key in KEYS:
        latest = state.kg.latest(f"market:{key}", "funding_rate_at", now)
        if latest and latest["conf"] < 0.6:
            gaps["lowConf"].append(key)
        hist = [r["value"] for r in
                state.kg.history(f"market:{key}", "funding_rate_at")
                if r["ts"] <= now]
        z = 0.0
        if len(hist) >= 8:
            mu = st.fmean(hist[:-1])
            sd = st.pstdev(hist[:-1]) or 1e-9
            z = (hist[-1] - mu) / sd
        dv = state.kg.latest(f"analysis:{key}", "deep_dive_verdict", now)
        if abs(z) > 1.6 and (not dv or now - dv["ts"] > 3 * 86400):
            gaps["uncovered"].append(key)
    return gaps


def research_pass(state, cycle, day: int, cap: int = 4) -> dict:
    if state.governance.frozen:
        return {"skipped": "frozen"}
    gaps = scan_gaps(state, day)
    targets = list(dict.fromkeys(
        [n[7:] for n in gaps["stale"] if n.startswith("market:")]
        + gaps["lowConf"] + gaps["uncovered"]))[:cap]
    d = min(day, state.driver.total_days - 1)
    acts = {"reingest": 0, "deep_dives": 0}
    if targets:
        cycle._dispatch("perc.market", "ingest_market",
                        {"day": d, "period": 0})
        acts["reingest"] = len(targets)
        before = sum(len(a.children) for a in state.agents.values())
        cycle._dispatch("res.market_analyst", "analyze",
                        {"day": d, "period": 0, "keys": targets})
        cycle._dispatch("res.opportunity_scanner", "scan",
                        {"day": d, "period": 0, "keys": targets})
        acts["deep_dives"] = max(
            0, sum(len(a.children) for a in state.agents.values()) - before)
        now = ts_of(day, 0)
        for key in targets:
            for ent in (f"market:{key}", f"analysis:{key}"):
                if ent in state.pages.pages or \
                        ent in getattr(state.kg, "entities", set()):
                    state.pages.surgical(ent, now)
    out = {"gaps": {k: (len(v) if isinstance(v, list) else v)
                    for k, v in gaps.items()},
           "targets": targets, "acts": acts,
           "freshness": round(state.pages.freshness(ts_of(day, 0)), 3)}
    state.audit.append("auto.research", out, "auto")
    return out


def _evidence_cids(state, day: int, keys, n: int = 3) -> list:
    now = ts_of(day, 0)
    out = []
    for key in keys:
        dv = state.kg.latest(f"analysis:{key}", "deep_dive_verdict", now)
        if dv:
            out.append(dv["cid"])
        f = state.kg.latest(f"market:{key}", "funding_rate_at", now)
        if f:
            out.append(f["cid"])
        if len(out) >= n:
            break
    return out[:n]


def mine_candidates(state, day: int) -> dict:
    br = state.trading.broker
    m = live_metrics(br, state.exg, state.pages,
                     oracle_funding_pnl(state.driver, 1e5, max(0, day - 1))) \
        if day > 0 else {"capture_eff": 0, "fp_rate": 0, "max_dd": 0}
    vt = state.exg.verified_trajectories()
    ext = [t for t in vt if abs(t.features.get("z", 0)) > 2.5]
    fp_ext = (sum(1 for t in ext if t.outcome.get("pnl", 0) < 0) / len(ext)) \
        if ext else 0.0
    hot = list(dict.fromkeys(
        t.features.get("key") for t in ext if t.features.get("key"))) or KEYS[:2]
    return mine_rules(state.harness.strategy, state.harness.routing, m,
                      fp_ext, len(ext), hot,
                      lambda keys: _evidence_cids(state, day, keys))


def mine_rules(h: dict, routing: dict, m: dict, fp_ext: float,
               ext_len: int, hot: list, ev) -> dict:
    """Pure knowledge→candidate mapping (testable in isolation)."""
    cands, evidence = [], {}

    def push(title, level, diff, cids):
        cands.append((title, level, diff))
        evidence[title] = cids

    if fp_ext > 0.25 and h["z_cap"] > 2.5:
        push(f"tighten extreme filter (wiki-mined: {ext_len} extreme trajs, "
             f"{fp_ext*100:.0f}% losers)", Priv.SKILL,
             {"strategy.z_cap": 2.5,
              "strategy.persistence_min": max(h["persistence_min"], 3),
              "prompts.market_analysis": "+[[EXTREME_DISCOUNT]]"}, ev(hot))
    elif fp_ext > 0.12 and h["persistence_min"] < 4:
        push(f"raise persistence gate to {h['persistence_min']+1} "
             f"(wiki-mined: residual extreme losses)", Priv.SKILL,
             {"strategy.persistence_min": h["persistence_min"] + 1}, ev(hot))
    if m["capture_eff"] < 0.45 and not routing.get("cross_venue_precheck"):
        push(f"cross-venue precheck (wiki-mined: capture "
             f"{m['capture_eff']*100:.0f}% of oracle)", Priv.POLICY,
             {"routing.cross_venue_precheck": True,
              "strategy.xv_gap_min": 0.0005,
              "topology": "cross_venue_precheck"}, ev(KEYS))
    if m["capture_eff"] < 0.55 and m["fp_rate"] < 0.05 and \
            h["max_leverage"] < 5:
        push(f"raise leverage to 4x (wiki-mined: clean fp "
             f"{m['fp_rate']*100:.1f}%, yield gap)", Priv.SKILL,
             {"strategy.max_leverage": 4.0}, ev(hot))
    if m["max_dd"] > 0.03 and h["dd_budget"] > 0.05:
        push(f"tighten drawdown budget to 5% (wiki-mined: maxDD "
             f"{m['max_dd']*100:.1f}%)", Priv.SKILL,
             {"strategy.dd_budget": 0.05}, ev(hot))
    return {"cands": cands, "evidence": evidence}


def auto_tick(state, cycle, day: int, cfg: dict) -> tuple[int, dict]:
    """One governed autonomous step. Returns (new_day, result)."""
    if state.governance.frozen:
        why = state.governance.freeze_reasons[-1]["reason"] \
            if state.governance.freeze_reasons else "?"
        return day, {"halted": "frozen", "reason": why, "day": day}
    ensure_days(state, day + 1)
    out = {"day": day + 1}
    if day > 0 and day % cfg["research_every"] == 0:
        out["research"] = research_pass(state, cycle, day)
    cycle.run_day(day)
    day += 1
    if day % cfg["epoch_every"] == 0 and not state.governance.frozen:
        if not state.evaluator.frozen:
            state.evaluator.freeze()
            state.audit.append("evaluator.sealed",
                               {"hash": state.evaluator.hash}, "auto")
        mined = mine_candidates(state, day)
        gov = state.governance

        def pending_same(title):
            return any(t.status == "pending"
                       and t.title == f"promote: {title}"
                       for t in gov.tickets.values())

        waiting = [t for t, lv, _ in mined["cands"]
                   if int(lv) >= int(Priv.POLICY) and pending_same(t)]
        cands = [(t, lv, df) for t, lv, df in mined["cands"]
                 if not (int(lv) >= int(Priv.POLICY) and pending_same(t))]
        if waiting:
            state.audit.append("auto.awaiting_key", {"titles": waiting},
                               "auto")
        out["awaiting"] = waiting
        if cands:
            state.audit.append("auto.mined",
                               {"n": len(cands),
                                "titles": [c[0] for c in cands]}, "auto")
            orig = gov.request

            def wrapped(level, title, payload, actor):
                t = orig(level, title, payload, actor)
                if int(level) >= int(Priv.POLICY):
                    transfer_approval(state, gov, t)
                return t

            gov.request = wrapped
            try:
                promoted, reports = state.evolution.epoch(
                    state.harness, cfg["seeds"], days=cfg["days"],
                    candidates=cands, epoch_no=cfg["epochs"])
            finally:
                gov.request = orig
            cfg["epochs"] += 1
            if promoted.version > state.harness.version:
                state.harness = promoted
                state.core.prompts = dict(promoted.prompts)
                state.core.adapter = dict(promoted.adapter)
                state.audit.append("harness.swapped",
                                   {"version": promoted.version},
                                   "governance")
            out["epoch"] = {
                "reports": [{"title": r.candidate_title,
                             "level": int(r.level),
                             "lint": list(r.lint_violations or []),
                             "p": float(r.p_value),
                             "meanDiff": float(r.mean_diff),
                             "perRegime": dict(r.per_regime or {}),
                             "promoted": bool(r.promoted),
                             "ticket": r.ticket_id,
                             "reason": r.reason} for r in reports],
                "promotedVersion": state.harness.version,
                "evidence": mined["evidence"]}
    return day, out


def transfer_approval(state, gov, ticket) -> bool:
    """A standing human approval of an identical proposal title carries over
    to a fresh re-proposal (audited). Returns True if transferred."""
    prior = next(
        (x for x in gov.tickets.values() if x is not ticket
         and x.title == ticket.title
         and str(x.approver).startswith("human")
         and x.status in ("approved", "applied")), None)
    if prior and ticket.status == "pending":
        gov.approve(ticket.tid, actor_role="human", actor=str(prior.approver))
        state.audit.append("auto.approval_transfer",
                           {"from": prior.tid, "to": ticket.tid,
                            "title": ticket.title}, "governance")
        return True
    return False
