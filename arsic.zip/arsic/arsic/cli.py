"""ARSIC CLI. Commands:
  demo     full end-to-end storyline (bootstrap -> paper run -> improvement
           epochs -> evaluator co-evolution -> kill-switch drill -> reports)
  verify   re-verify the audit hash chain of an existing run directory
"""
from __future__ import annotations

import argparse
import os
import statistics as st
import sys

from . import strategy_math as sm
from .bootstrap import (build_system, advance_autonomy, swap_harness,
                        AUTONOMY_LABELS)
from .cycle import DailyCycle
from .dashboard import render
from .evaluate import Evaluator, EvaluatorEvolution, gt_tau, live_metrics
from .events import EventLog
from .governance import Frozen, ContractError, Priv
from .perception import SyntheticMarket
from .trading import LiveTradeRejected

MAIN_SCHEDULE = [("trend", 8), ("range", 7), ("high_vol", 8), ("post_squeeze", 7)]
EPOCH_SEEDS = list(range(1, 11))


def demo(root: str, days: int = 30, quiet: bool = False) -> dict:
    P = (lambda *a: None) if quiet else print
    rep: dict = {"lines": []}
    def log(line: str):
        rep["lines"].append(line)
        P(line)

    log("== ARSIC demo: bootstrap (S7 steps 1-2) ==")
    s = build_system(seed=7, schedule=MAIN_SCHEDULE, root=root)
    log(f"constellation: {len(s.agents)} agents · wiki seeded "
        f"({len(s.pages.pages)} seed pages) · harness v{s.harness.version} "
        f"committed to git")

    log(f"\n== S7 step 3: paper-trade only, N={days} daily cycles "
        f"({AUTONOMY_LABELS[0]}) ==")
    cyc = DailyCycle(s)
    last = cyc.run(days)
    m0 = last["metrics"]
    log(f"day {days-1}: equity {s.trading.broker.equity:,.0f}  "
        f"pnl {m0['pnl']:+,.0f}  ops {m0['n_ops']}  fp {m0['fp_rate']:.1%}  "
        f"capture {m0['capture_eff']:.1%}  maxDD {m0['max_dd']:.2%}")
    log(f"experience graph: {len(s.exg.traj)} trajectories, "
        f"{len(s.exg.principles)} abstracted principles")
    log(f"improvement notes filed as tickets: "
        f"{sum(1 for t in s.governance.tickets.values() if 'candidate' in t.title)}")
    if s.governance.frozen:               # organic trip on the final day
        why = s.governance.freeze_reasons[-1]["reason"]
        s.audit.append("human.ops_review",
                       {"day": days, "freeze_reason": why,
                        "finding": "end-of-phase review; paper book within "
                                   "limits; cleared for evolution phase"},
                       "human:ops")
        s.governance.unfreeze(actor_role="human",
                              analysis=f"end-of-phase review of '{why}'")
        log(f"kill-switch trip '{why}' reviewed and reset by human ops")

    log(f"\n== S7 step 4: enable harness evolution ({AUTONOMY_LABELS[1]}) ==")
    advance_autonomy(s, 1)
    s.evaluator.freeze()
    log(f"evaluator sealed for epoch 0: hash {s.evaluator.hash}")

    # human pre-approves POLICY candidates so the A/B verdict (not the queue)
    # decides their fate — demonstrates both gates independently.
    def approver(ticket):
        if ticket.level >= int(Priv.POLICY) and ticket.status == "pending" \
                and ticket.title.startswith("promote:"):
            s.governance.approve(ticket.tid, actor_role="human")

    promoted, reports = s.evolution.epoch(s.harness, EPOCH_SEEDS, days=10,
                                          epoch_no=0)
    # second pass for the POLICY candidate with explicit human approval
    for r in reports:
        t = s.governance.tickets.get(r.ticket_id)
        if t and t.status == "pending":
            approver(t)
    log("epoch 0 A/B on held-out regime suites (10 seeds x 4 regimes):")
    for r in reports:
        verdict = "PROMOTED" if r.promoted else \
            ("LINT-REJECTED" if r.lint_violations else "REJECTED")
        log(f"  [{verdict:13s}] {r.candidate_title} (P{r.level})  "
            f"p={r.p_value:.4f}  Δ={r.mean_diff:+.3f}  {r.reason or r.lint_violations}")
    rep["epoch0"] = reports
    inc_score = st.fmean(
        [e['score'] for e in s.board.comparable(s.evaluator.hash)
         if e['subject'] == 'incumbent.v1'])
    s.governance.last_epoch_score = inc_score
    if promoted.version > s.harness.version:
        swap_harness(s, promoted)
        log(f"live constellation swapped to harness v{s.harness.version} "
            f"(git: {(s.repo.log() or ['n/a'])[0]})")

    log(f"\n== S5: bounded adapter update from VERIFIED sibling trajectories "
        f"({AUTONOMY_LABELS[2]}) ==")
    advance_autonomy(s, 2)
    bounded, at, paths = s.evolution.fit_adapter(
        s.harness, os.path.join(root, "reports", "training_data"))
    log(f"training datasets exported: "
        + ", ".join(f"{k}={os.path.basename(v)}" for k, v in paths.items())
        + f"  (n_verified={at.payload['n_verified']})")
    s.governance.approve(at.tid, actor_role="human")
    s.harness = s.evolution.apply_adapter(s.harness, bounded, at)
    swap_harness(s, s.harness)
    log(f"adapter applied (clamped ±0.25/epoch): {bounded} -> harness "
        f"v{s.harness.version}")

    log("\n== S5: evaluator co-evolution (Red Queen gate) ==")
    cand = Evaluator({"w_fp": 4.0, "w_dd": 3.0})
    ee = EvaluatorEvolution(s.governance, s.board, s.audit)
    beat, et, (t_inc, t_cand) = ee.attempt(s.evaluator, cand)
    log(f"ground-truth Kendall tau: incumbent {t_inc:.3f} vs candidate "
        f"{t_cand:.3f} -> beats: {beat}")
    s.governance.approve(et.tid, actor_role="human")
    old_hash = s.evaluator.hash
    s.evaluator = ee.replace(s.evaluator, cand, et)
    erased = len([e for e in s.board.entries if e['eval_hash'] == old_hash])
    log(f"replaced {old_hash} -> {s.evaluator.hash}; selective erasure marked "
        f"{erased} old scores non-comparable "
        f"(comparable now: {len(s.board.comparable(old_hash))})")
    s.evolution.evaluator = s.evaluator
    s.governance.last_epoch_score = None      # re-baseline under new evaluator

    log("\n== S6: kill-switch drill (rule-based circuit breaker) ==")
    hit = s.killswitch.evaluate({"max_abs_funding": 0.021})
    log(f"crafted snapshot |funding|=2.1%/8h -> tripped: {hit}; "
        f"system frozen: {s.governance.frozen}")
    tk = s.scheduler.new_task("probe", {"perception.market"},
                              {"day": 0, "period": 0})
    r = s.scheduler.dispatch("perc.market", tk)
    log(f"scheduler while frozen: dispatch -> {r} (audited frozen_skip)")
    try:
        s.trading.gateway.submit("binance:BTC-USDT-PERP", 1, 1e5, 2.0,
                                 s.driver.ticks_at(0, 0)[0], {}, False)
    except Frozen as e:
        log(f"gateway while frozen: {type(e).__name__}: {e}")
    probe = s.governance.request(Priv.SKILL, "probe: apply while frozen", {},
                                 "improve")
    try:
        s.governance.mark_applied(probe)
    except ContractError as e:
        log(f"improvement apply while frozen: ContractError: {e}")
    s.governance.unfreeze(actor_role="human",
                          analysis="drill: synthetic extreme print; feeds "
                                   "healthy; resumed after review")
    log(f"human reset with logged analysis; frozen={s.governance.frozen}")

    log("\n== S9 invariant probe: live trading requires human confirmation ==")
    try:
        s.trading.gateway.submit("binance:BTC-USDT-PERP", 1, 1e5, 2.0,
                                 s.driver.ticks_at(0, 0)[0], {}, False,
                                 live=True, human_token="forged")
    except LiveTradeRejected as e:
        log(f"live submit -> LiveTradeRejected: {e}")
    log(f"live trades executed: {s.trading.gateway.live_trades} "
        f"(rejections: {s.trading.gateway.live_rejections})")

    log("\n== S9 compounding: gap-to-oracle closure across epochs ==")
    from .improve import Harness
    from .strategy_math import oracle_funding_pnl
    fresh = SyntheticMarket(seed=8, schedule=MAIN_SCHEDULE)
    base = Harness()   # v1
    r_old = sm.simulate(base.strategy, fresh, base.adapter).metrics(1e6)
    r_new = sm.simulate(s.harness.strategy, fresh, s.harness.adapter).metrics(1e6)
    oracle = oracle_funding_pnl(fresh, 1e6)
    # gap-to-oracle on NET pnl: gross funding capture alone rewards entering
    # squeeze prints and bleeding it back on whipsaw, so it is reported only
    # as a diagnostic; the compounding metric is net-vs-oracle.
    net_old, net_new = r_old["pnl"] / oracle, r_new["pnl"] / oracle
    log(f"fresh 30d mixed-regime world (seed 8), identical shared math; "
        f"oracle bound {oracle:+,.0f}:")
    log(f"  v1  : net-capture {net_old:+.1%}  (gross funding capture "
        f"{r_old['capture_eff']:.1%})  fp {r_old['fp_rate']:.1%}  "
        f"pnl {r_old['pnl']:+,.0f}  score(new eval) "
        f"{s.evaluator.score(r_old):+.3f}")
    log(f"  v{s.harness.version}  : net-capture {net_new:+.1%}  (gross funding capture "
        f"{r_new['capture_eff']:.1%})  fp {r_new['fp_rate']:.1%}  "
        f"pnl {r_new['pnl']:+,.0f}  score(new eval) "
        f"{s.evaluator.score(r_new):+.3f}")
    gap_closed = net_new - net_old
    log(f"  oracle-gap closure this epoch: {gap_closed:+.1%} of the oracle bound "
        f"(net {net_old:+.1%} -> {net_new:+.1%})")
    rep["compounding"] = {"v1": r_old, "vN": r_new, "oracle": oracle,
                          "net_capture_v1": net_old, "net_capture_vN": net_new,
                          "gap_closed": gap_closed}
    s.board.record(s.evaluator.hash, f"incumbent.v{s.harness.version}",
                   s.evaluator.score(r_new), 1)

    log("\n== meta-improvement path (S5, META-gated) ==")
    mt = s.meta_queue.propose_meta(
        "acceptance criterion: paired sign-flip alpha=0.05 + per-regime "
        "non-regression 0.15 ratified as standing policy",
        {"alpha": 0.05, "regression_tol": 0.15}, "improve")
    s.governance.approve(mt.tid, actor_role="human")
    s.governance.mark_applied(mt)
    log(f"META ticket {mt.tid} approved by human and applied")

    ok, bad = s.audit.verify()
    inv = {"audit_chain_ok": ok, "audit_first_bad": bad,
           "audit_events": s.audit.count(),
           "live_trades": s.trading.gateway.live_trades,
           "live_rejections": s.trading.gateway.live_rejections,
           "policy_plus_applied_all_human": all(
               t.approver.startswith("human") or t.approver.startswith("auto")
               and t.level < int(Priv.POLICY)
               for t in s.governance.tickets.values() if t.status == "applied"),
           "evaluator_frozen": s.evaluator.frozen,
           "conflicts_awaiting_arbiter": len(s.kg.arbiter_queue),
           "handoffs": len(s.router.handoffs),
           "pending_tickets": len(s.governance.pending())}
    log("\n== audit & invariants ==")
    for k, v in inv.items():
        log(f"  {k}: {v}")
    rep["invariants"] = inv
    rep["metrics"] = m0
    rep["state"] = s

    # -- artifacts ---------------------------------------------------------
    os.makedirs(os.path.join(root, "reports"), exist_ok=True)
    _write_run_report(os.path.join(root, "reports", "RUN_REPORT.md"), s, rep,
                      days)
    dash = {"version": s.harness.version,
            "autonomy_label": AUTONOMY_LABELS[s.governance.autonomy_level],
            "frozen": s.governance.frozen,
            "evaluator_hash": s.evaluator.hash, "metrics": m0,
            "daily_rows": s.daily_rows,
            "promotions": [r.__dict__ for r in reports],
            "tickets": [t.__dict__ for t in s.governance.tickets.values()
                        if t.level >= int(Priv.POLICY)],
            "killswitch_log": [{"kind": e.kind, "payload": e.payload,
                                "actor": e.actor} for e in s.audit.all()
                               if e.kind.startswith("killswitch")],
            "pages": s.pages.pages, "arbiter_n": len(s.kg.arbiter_queue),
            "freshness": s.pages.freshness_cache,
            "tree": s.scheduler.tree(),
            "audit_tail": [{"seq": e.seq, "kind": e.kind, "hash": e.hash}
                           for e in s.audit.tail(14)],
            "invariants": inv, "git_log": s.repo.log()}
    render(dash, os.path.join(root, "reports", "dashboard.html"))
    log(f"\nartifacts: reports/RUN_REPORT.md, reports/dashboard.html, "
        f"reports/training_data/, harness_repo/ (git), state/audit.jsonl")
    return rep


def _write_run_report(path: str, s, rep: dict, days: int) -> None:
    rows = s.daily_rows
    pick = rows[:2] + [r for r in rows[2:-1]
                       if r["day"] in (7, 8, 14, 15, 22, 23)] + rows[-1:]
    with open(path, "w") as f:
        f.write("# ARSIC run report (generated from live objects)\n\n")
        f.write(f"Main sim: {days} days over schedule {MAIN_SCHEDULE}, "
                f"seed 7, paper equity 1,000,000.\n\n")
        f.write("## Daily cycle excerpts\n\n")
        f.write("| day | regime | equity | closed | fp_rate | capture | "
                "score | note |\n|---|---|---|---|---|---|---|---|\n")
        for r in pick:
            note = (r["notes"][0][:60] + "…") if r["notes"] else ""
            f.write(f"| {r['day']} | {r['regime']} | {r['equity']:,.0f} | "
                    f"{r['closed_total']} | {r['fp_rate']:.1%} | "
                    f"{r['capture_eff']:.1%} | {r['score']:+.3f} | {note} |\n")
        f.write("\n## Console transcript\n\n```\n")
        f.write("\n".join(rep["lines"]))
        f.write("\n```\n")


def verify(root: str) -> int:
    log = EventLog(os.path.join(root, "state", "audit.jsonl"))
    ok, bad = log.verify()
    print(f"audit chain: {'OK' if ok else f'BROKEN at seq {bad}'} "
          f"({log.count()} events)")
    return 0 if ok else 1


def serve_cmd(args):
    from .server import serve
    html = args.html
    if html and not os.path.isabs(html):
        html = os.path.abspath(html)
    serve(args.root, port=args.port, seed=args.seed, html=html)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="arsic")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("demo")
    d.add_argument("--root", default="run")
    d.add_argument("--days", type=int, default=30)
    v = sub.add_parser("verify")
    v.add_argument("--root", default="run")
    sn = sub.add_parser("sentinel",
                        help="independent out-of-process risk watchdog")
    sn.add_argument("rest", nargs=argparse.REMAINDER)
    s = sub.add_parser("serve")
    s.add_argument("--root", default="run_srv")
    s.add_argument("--port", type=int, default=8787)
    s.add_argument("--seed", type=int, default=7)
    s.add_argument("--html", default=None,
                   help="path to ARSIC.html to serve at /")
    args = ap.parse_args(argv)
    if args.cmd == "demo":
        demo(args.root, args.days)
        return 0
    if args.cmd == "sentinel":
        from .sentinel import main as sentinel_main
        return sentinel_main(args.rest)
    if args.cmd == "serve":
        serve_cmd(args)
        return 0
    return verify(args.root)


if __name__ == "__main__":
    sys.exit(main())
