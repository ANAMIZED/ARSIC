"""ARSIC human interface (spec S7: 'wiki browser + constellation dashboard +
approval queue'). Renders a single offline HTML ops console.

Design (frontend-design pass): subject = the operator's ledger for a governed,
self-improving trading-research OS; job = one-glance answer to 'is it healthy,
governed, and improving?'. Palette: deep petrol night with amber governance
accents and teal performance marks (deliberately not the black+acid-green
default). Type: serif display (Iowan/Palatino stack) for the masthead — an
audit-ledger character — over system-ui body and ui-monospace data. Signature
element: the audit hash-chain ribbon, rendering the tamper-evident chain
literally as linked prev->hash chips."""
from __future__ import annotations

import html
from typing import Optional

CSS = """
:root{--ink:#0E1A22;--panel:#14242E;--line:#24404C;--text:#D9E4E2;
--dim:#8AA3A6;--amber:#E4A339;--teal:#57B8A8;--red:#D96A5A;
--serif:'Iowan Old Style','Palatino Linotype',Palatino,Georgia,serif;
--mono:ui-monospace,'SF Mono',Menlo,Consolas,monospace}
*{box-sizing:border-box}
body{margin:0;background:var(--ink);color:var(--text);
font:15px/1.55 system-ui,-apple-system,'Segoe UI',sans-serif}
a{color:var(--teal)}
.wrap{max-width:1180px;margin:0 auto;padding:28px 20px 60px}
header{border-bottom:1px solid var(--line);padding-bottom:18px;margin-bottom:24px}
h1{font-family:var(--serif);font-weight:600;font-size:34px;margin:0;
letter-spacing:.5px}
h1 .v{color:var(--amber)}
.sub{color:var(--dim);margin-top:4px;font-size:14px}
.badges{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
.badge{font-family:var(--mono);font-size:12px;border:1px solid var(--line);
border-radius:4px;padding:4px 10px;background:var(--panel)}
.badge.ok{border-color:var(--teal);color:var(--teal)}
.badge.warn{border-color:var(--amber);color:var(--amber)}
.badge.bad{border-color:var(--red);color:var(--red)}
h2{font-family:var(--serif);font-weight:600;font-size:20px;margin:34px 0 10px;
border-bottom:1px solid var(--line);padding-bottom:6px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
gap:12px}
.card{background:var(--panel);border:1px solid var(--line);border-radius:6px;
padding:12px 14px}
.card .k{color:var(--dim);font-size:12px;text-transform:uppercase;
letter-spacing:.08em}
.card .n{font-family:var(--mono);font-size:22px;margin-top:4px}
.card .n.pos{color:var(--teal)}.card .n.neg{color:var(--red)}
table{border-collapse:collapse;width:100%;font-size:13.5px}
th{color:var(--dim);text-align:left;font-weight:500;border-bottom:1px solid
var(--line);padding:6px 8px}
td{border-bottom:1px solid #1B303B;padding:6px 8px;font-family:var(--mono);
font-size:12.5px}
td.t{font-family:inherit;font-size:13.5px}
tr.hit td{color:var(--amber)}
.pill{display:inline-block;border-radius:3px;padding:1px 7px;font-size:11px}
.pill.yes{background:#153B33;color:var(--teal)}
.pill.no{background:#3B2020;color:var(--red)}
.pill.pend{background:#3B3113;color:var(--amber)}
svg text{font-family:var(--mono)}
.ribbon{display:flex;flex-wrap:wrap;gap:0;margin-top:8px}
.chip{font-family:var(--mono);font-size:11px;background:var(--panel);
border:1px solid var(--line);border-radius:4px;padding:5px 8px;margin:3px 0}
.chip b{color:var(--amber);font-weight:600}
.link{color:var(--dim);align-self:center;padding:0 4px}
.tree{font-family:var(--mono);font-size:12.5px;white-space:pre;
background:var(--panel);border:1px solid var(--line);border-radius:6px;
padding:14px;overflow-x:auto}
.small{color:var(--dim);font-size:12.5px}
@media (max-width:700px){h1{font-size:26px}}
"""


def _e(x) -> str:
    return html.escape(str(x))


def _spark(values: list, w: int = 560, h: int = 90) -> str:
    if len(values) < 2:
        return ""
    lo, hi = min(values), max(values)
    rng = (hi - lo) or 1.0
    pts = " ".join(f"{i*(w-8)/(len(values)-1)+4:.1f},"
                   f"{h-8-(v-lo)/rng*(h-16):.1f}" for i, v in enumerate(values))
    color = "#57B8A8" if values[-1] >= values[0] else "#D96A5A"
    return (f'<svg width="100%" viewBox="0 0 {w} {h}" role="img" '
            f'aria-label="equity curve"><polyline points="{pts}" fill="none" '
            f'stroke="{color}" stroke-width="1.6"/>'
            f'<text x="4" y="12" fill="#8AA3A6" font-size="11">'
            f'{lo:,.0f}</text><text x="4" y="{h-2}" fill="#8AA3A6" '
            f'font-size="11">equity</text></svg>')


def render(d: dict, path: str) -> str:
    inv = d.get("invariants", {})
    frozen = d.get("frozen", False)
    parts = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'>"
             f"<meta name='viewport' content='width=device-width,initial-scale=1'>"
             f"<title>ARSIC console</title><style>{CSS}</style></head><body>"
             f"<div class='wrap'><header>"
             f"<h1>ARSIC <span class='v'>harness v{_e(d.get('version'))}</span></h1>"
             f"<div class='sub'>Autonomous Recursive Self-Improving Knowledge Wiki "
             f"Constellation OS — trading instantiation (paper-only)</div>"
             f"<div class='badges'>"
             f"<span class='badge {'bad' if frozen else 'ok'}'>"
             f"{'FROZEN — kill-switch' if frozen else 'RUNNING'}</span>"
             f"<span class='badge'>{_e(d.get('autonomy_label'))}</span>"
             f"<span class='badge'>evaluator {_e(d.get('evaluator_hash'))} "
             f"(frozen)</span>"
             f"<span class='badge {'ok' if inv.get('audit_chain_ok') else 'bad'}'>"
             f"audit chain {'VERIFIED' if inv.get('audit_chain_ok') else 'BROKEN'}"
             f"</span>"
             f"<span class='badge {'ok' if inv.get('live_trades',1)==0 else 'bad'}'>"
             f"live trades: {_e(inv.get('live_trades'))}</span>"
             f"</div></header>"]

    m = d.get("metrics", {})
    def card(k, v, cls=""):
        return (f"<div class='card'><div class='k'>{_e(k)}</div>"
                f"<div class='n {cls}'>{_e(v)}</div></div>")
    parts.append("<h2>Performance (paper)</h2><div class='grid'>")
    pnl = m.get("pnl", 0.0)
    parts.append(card("PnL", f"{pnl:+,.0f}", "pos" if pnl >= 0 else "neg"))
    parts.append(card("Sharpe proxy", f"{m.get('sharpe',0):.2f}"))
    parts.append(card("Capture vs oracle", f"{m.get('capture_eff',0):.1%}"))
    parts.append(card("FP rate", f"{m.get('fp_rate',0):.1%}",
                      "neg" if m.get('fp_rate',0) > .1 else ""))
    parts.append(card("Max drawdown", f"{m.get('max_dd',0):.2%}"))
    parts.append(card("Ops closed", m.get("n_ops", 0)))
    parts.append("</div>")
    eq = [r["equity"] for r in d.get("daily_rows", [])]
    if eq:
        parts.append(f"<div style='margin-top:14px'>{_spark(eq)}</div>")

    parts.append("<h2>Harness evolution — held-out A/B (frozen evaluator)</h2>"
                 "<table><tr><th>candidate</th><th>level</th><th>p</th>"
                 "<th>Δscore</th><th>per-regime Δ</th><th>outcome</th></tr>")
    for r in d.get("promotions", []):
        pill = ("<span class='pill yes'>promoted</span>" if r["promoted"] else
                "<span class='pill no'>rejected</span>")
        pr = ", ".join(f"{k}:{v:+.2f}" for k, v in r.get("per_regime", {}).items()) \
            or "—"
        parts.append(f"<tr><td class='t'>{_e(r['candidate_title'])}</td>"
                     f"<td>P{r['level']}</td>"
                     f"<td>{r['p_value']:.4f}</td><td>{r['mean_diff']:+.3f}</td>"
                     f"<td>{_e(pr)}</td><td class='t'>{pill} "
                     f"<span class='small'>{_e(r['reason'])}</span></td></tr>")
    parts.append("</table>")
    if d.get("git_log"):
        parts.append("<div class='small' style='margin-top:8px'>harness repo: "
                     + " · ".join(_e(l) for l in d["git_log"][:5]) + "</div>")

    parts.append("<h2>Approval queue &amp; tickets (POLICY+)</h2>"
                 "<table><tr><th>id</th><th>level</th><th>title</th>"
                 "<th>status</th><th>approver</th></tr>")
    for t in d.get("tickets", []):
        cls = {"approved": "yes", "applied": "yes",
               "rejected": "no"}.get(t["status"], "pend")
        parts.append(f"<tr><td>{_e(t['tid'])}</td><td>P{t['level']}</td>"
                     f"<td class='t'>{_e(t['title'])}</td>"
                     f"<td><span class='pill {cls}'>{_e(t['status'])}</span></td>"
                     f"<td>{_e(t['approver'] or '—')}</td></tr>")
    parts.append("</table>")

    parts.append("<h2>Kill-switch</h2>")
    ksl = d.get("killswitch_log", [])
    if ksl:
        parts.append("<table><tr><th>event</th><th>detail</th><th>actor</th></tr>")
        for e in ksl:
            parts.append(f"<tr class='hit'><td>{_e(e['kind'])}</td>"
                         f"<td class='t'>{_e(e['payload'])}</td>"
                         f"<td>{_e(e['actor'])}</td></tr>")
        parts.append("</table>")
    else:
        parts.append("<div class='small'>no activations</div>")

    parts.append("<h2>Knowledge wiki</h2>"
                 f"<div class='small'>freshness {_e(d.get('freshness'))} · "
                 f"conflicts queued for arbiter: {_e(d.get('arbiter_n', 0))}</div>"
                 "<table><tr><th>page</th><th>ver</th><th>hash</th></tr>")
    for name, pg in list(d.get("pages", {}).items())[:18]:
        parts.append(f"<tr><td class='t'>{_e(name)}</td><td>{pg['version']}</td>"
                     f"<td>{_e(pg['hash'][:14])}</td></tr>")
    parts.append(f"</table><div class='small'>… {len(d.get('pages', {}))} pages "
                 f"total</div>")

    parts.append("<h2>Constellation</h2><div class='tree'>")
    def walk(n, depth=0):
        parts.append(_e("  " * depth + f"{n['id']}  [{n['role']}]  "
                                       f"{n['status'].get('state','')}") + "\n")
        for c in n.get("children", []):
            walk(c, depth + 1)
    for n in d.get("tree", {}).get("agents", []):
        walk(n)
    parts.append("</div>")

    parts.append("<h2>Audit chain (tail)</h2><div class='ribbon'>")
    tail = d.get("audit_tail", [])
    for i, e in enumerate(tail):
        parts.append(f"<span class='chip'>#{e['seq']} <b>{_e(e['kind'])}</b> "
                     f"{_e(e['hash'][:8])}</span>")
        if i < len(tail) - 1:
            parts.append("<span class='link'>→</span>")
    parts.append("</div><div class='small' style='margin-top:6px'>each chip's "
                 "hash seeds the next event's <i>prev</i>; verify() recomputes "
                 "the full chain.</div>")

    parts.append("</div></body></html>")
    out = "".join(parts)
    with open(path, "w") as f:
        f.write(out)
    return out
