"""S11: L3 execution plane — human-lent live autonomy with HOTL/HITL controls.

The privilege ladder never reaches L3: `Governance.autonomy_level` is capped
at 2 and the advance path still refuses. L3 exists only as a MANDATE — a
human-issued, dual-acknowledged, time-boxed, scoped loan of execution
authority that expires on TTL, lapses on a missed dead-man heartbeat, and is
revoked instantly by any breaker, loss-cap breach, or human action.

Execution routes through a ShadowLiveAdapter (slippage, partial fills,
rejects, staleness on HITL re-quotes) so every control is exercised against
adversarial fill semantics. The LiveAdapter below is a hard boundary: it
refuses to arm. No real venue connectivity ships in this build, because none
of it could be tested here — integrating and verifying a real connector is
deliberately left on the human side of the boundary.

The pre-trade RiskGate binds at the ExecutionGateway — *below* the agents —
so no strategy, adapter, or self-modification can out-trade the mandate.
"""
from __future__ import annotations

import dataclasses
import hashlib
import os
from dataclasses import dataclass, field

from .trading import LiveTradeRejected, RiskVeto

ACK_1 = "I understand this is shadow-live execution with real-loss semantics"
ACK_2 = "risk of total loss accepted; the mandate is temporary and revocable"


class QueuedForApproval(RiskVeto):
    """HITL: order intent captured for human approval; not executed."""


class NotArmed(RuntimeError):
    pass


class LiveAdapter:
    """The live boundary — now a real, conformance-tested HTTP connector.
    Arms from environment credentials only:
      ARSIC_VENUE_URL / ARSIC_VENUE_KEY / ARSIC_VENUE_SECRET
    Loopback URLs (the in-sandbox venue simulator, or your own local venue
    gateway) arm directly. A NON-loopback URL additionally requires
      ARSIC_LIVE_ACK=I_UNDERSTAND_EXTERNAL_EXECUTION_RISK
    — deliberate friction: pointing this at a real venue is a human act,
    with real custody at the venue and real risk of total loss."""

    def __init__(self, mid: str = "M00000"):
        url = os.environ.get("ARSIC_VENUE_URL", "")
        key = os.environ.get("ARSIC_VENUE_KEY", "")
        sec = os.environ.get("ARSIC_VENUE_SECRET", "")
        if not (url and key and sec):
            raise NotArmed(
                "external route not configured: set ARSIC_VENUE_URL, "
                "ARSIC_VENUE_KEY and ARSIC_VENUE_SECRET (the shadow "
                "adapter remains the default execution path)")
        host = url.split("//")[-1].split("/")[0].split(":")[0]
        if host not in ("127.0.0.1", "localhost") and                 os.environ.get("ARSIC_LIVE_ACK") !=                 "I_UNDERSTAND_EXTERNAL_EXECUTION_RISK":
            raise NotArmed(
                "non-loopback venue requires "
                "ARSIC_LIVE_ACK=I_UNDERSTAND_EXTERNAL_EXECUTION_RISK "
                "(test against the simulator and a venue testnet first)")
        from .venue_client import ExternalVenueAdapter, VenueClient
        self.client = VenueClient(url, key, sec)
        self.client.health()                 # fail fast on arm
        self._adapter = ExternalVenueAdapter(self.client, mid)
        self.venue = url

    def fill(self, intent, tick):
        return self._adapter.fill(intent, tick)


def _h(*parts) -> int:
    return int(hashlib.sha256("|".join(map(str, parts)).encode())
               .hexdigest()[:12], 16)


@dataclass
class Mandate:
    mid: str
    mode: str                       # "hotl" | "hitl"
    route: str                      # "shadow" | "external"
    issued_day: int
    ttl_days: int
    heartbeat_every: int
    max_notional_per_order: float
    max_gross_notional: float
    max_leverage: float
    loss_cap: float
    order_rate_per_day: int
    max_requote_drift_bps: float
    venues: list
    acks: list
    ticket_id: str
    status: str = "active"          # active | revoked
    heartbeat_day: int = 0
    revoke_reason: str = ""


@dataclass
class OrderIntent:
    oid: str
    day: int
    key: str
    side: int
    notional: float
    leverage: float
    quoted_premium: float
    extreme: bool
    extra: dict = field(default_factory=dict)
    status: str = "pending"   # pending|stale_requote|approved|rejected|expired|filled
    verdict: list = field(default_factory=list)
    requotes: int = 0
    period: int = 0


class ShadowLiveAdapter:
    """Deterministic adversarial fills: adverse slippage, partial fills,
    occasional rejects — harsher than the idealized paper path."""

    def __init__(self, seed_salt: str):
        self.salt = seed_salt

    def fill(self, intent: OrderIntent, tick):
        h = _h(self.salt, intent.oid)
        if h % 23 == 0:
            return None                                   # venue reject
        slip_bps = 1 + (h % 7)                            # 1..7 bps adverse
        ratio = 0.6 if h % 11 == 0 else 1.0               # partial fill
        slip = intent.side * slip_bps * 1e-4
        t2 = dataclasses.replace(tick, perp=tick.perp * (1 + slip))
        extra_fee = 0.5e-4 * intent.notional * ratio      # taker premium
        return {"tick": t2, "ratio": ratio, "slip_bps": slip_bps,
                "extra_fee": extra_fee}


class RiskGate:
    """Backend-enforced pre-trade checks. Every verdict is audited."""

    def __init__(self, session):
        self.s = session

    def check(self, intent: OrderIntent, day: int) -> list:
        ses, m = self.s, self.s.mandate
        why = []
        if not m or m.status != "active":
            why.append("no_active_mandate")
            return why
        if ses.paused:
            why.append("paused")
        if day > m.issued_day + m.ttl_days:
            why.append("ttl_expired")
        if day - m.heartbeat_day > m.heartbeat_every:
            why.append("deadman_lapsed")
        if intent.key.split(":")[0] not in m.venues:
            why.append("venue_not_allowed")
        if intent.notional > m.max_notional_per_order:
            why.append("notional_per_order")
        gross = sum(p.notional for p in ses.broker.positions.values())
        if gross + intent.notional > m.max_gross_notional:
            why.append("gross_notional")
        if intent.leverage > m.max_leverage:
            why.append("leverage")
        if ses.orders_today >= m.order_rate_per_day:
            why.append("order_rate")
        if ses.loss_today() >= m.loss_cap:
            why.append("loss_cap")
        if ses.state.governance.frozen:
            why.append("kill_switch")
        if not ses.state.evaluator.frozen:
            why.append("evaluator_unsealed")
        return why


class L3Session:
    """Attaches to the system state + gateway. Owns the mandate lifecycle,
    the HITL queue, the shadow adapter, and every demotion path."""

    def __init__(self, state, gateway):
        self.state = state
        self.gateway = gateway
        self.broker = gateway.broker
        self.gov = state.governance
        self.audit = state.audit
        self.mandate: Mandate | None = None
        self.paused = False
        self.queue: list[OrderIntent] = []
        self._shadow_salt = f"shadow:{id(self) & 0xffff}"
        self.adapter = ShadowLiveAdapter(self._shadow_salt)
        self.gate = RiskGate(self)
        self.orders_today = 0
        self._day_equity_mark = self.broker.equity
        self._oid = 0
        self.fills = 0
        self.gated = 0
        self.queued = 0
        self.mkt = (0, 0)               # freshest (day, period) seen
        self.demote_log: list[dict] = []
        gateway.l3 = self
        state.l3 = self

    # ---------------- lifecycle ----------------
    def request_mandate(self, params: dict, actor: str = "human:web"):
        acks = params.get("acks", [])
        if ACK_1 not in acks or ACK_2 not in acks:
            raise LiveTradeRejected("both risk acknowledgments are required")
        mode = params.get("mode", "hotl")
        if mode not in ("hotl", "hitl"):
            raise LiveTradeRejected("mode must be hotl or hitl")
        route = params.get("route") or "shadow"
        if route not in ("shadow", "external"):
            raise LiveTradeRejected("route must be shadow or external")
        caps = {
            "mode": mode,
            "route": route,
            "ttl_days": int(params.get("ttl_days", 5)),
            "heartbeat_every": int(params.get("heartbeat_every", 2)),
            "max_notional_per_order": float(params.get(
                "max_notional_per_order", 5e4)),
            "max_gross_notional": float(params.get("max_gross_notional", 2e5)),
            "max_leverage": float(params.get("max_leverage", 2.0)),
            "loss_cap": float(params.get("loss_cap", 2e4)),
            "order_rate_per_day": int(params.get("order_rate_per_day", 12)),
            "max_requote_drift_bps": float(params.get(
                "max_requote_drift_bps", 25.0)),
            "venues": list(params.get(
                "venues", ["binance", "bybit", "hyperliquid"])),
        }
        title = (f"L3 execution mandate — {mode.upper()} · "
                 f"{route.upper()} route · "
                 f"≤${caps['max_notional_per_order']/1e3:.0f}k/order · "
                 f"≤{caps['max_leverage']:.0f}x · "
                 f"loss cap ${caps['loss_cap']/1e3:.0f}k · "
                 f"TTL {caps['ttl_days']}d · deadman "
                 f"{caps['heartbeat_every']}d")
        t = self.gov.request(5, title, {"l3_mandate": caps, "acks": acks},
                             actor)
        self.audit.append("l3.mandate_requested",
                          {"tid": t.tid, **caps}, actor)
        return t, caps

    def activate(self, tid: str, day: int, actor: str = "human:web"):
        t = self.gov.tickets[tid]
        if t.status != "approved" or not str(t.approver).startswith("human"):
            raise LiveTradeRejected(
                "mandate ticket must be approved by the human role")
        if self.gov.frozen:
            raise LiveTradeRejected("kill-switch active: cannot arm L3")
        if not self.state.evaluator.frozen:
            raise LiveTradeRejected(
                "evaluator must be sealed before L3 activation")
        caps = t.payload["l3_mandate"]
        self._oid = 0
        mid = f"M{_h(tid, day) % 100000:05d}"
        if caps.get("route") == "external":
            try:
                self.adapter = LiveAdapter(mid)
            except NotArmed as e:
                raise LiveTradeRejected(str(e)) from None
            self.audit.append("l3.external_armed",
                              {"mid": mid, "venue": self.adapter.venue},
                              actor)
        else:
            self.adapter = ShadowLiveAdapter(self._shadow_salt)
        self.mandate = Mandate(
            mid=mid, ticket_id=tid,
            issued_day=day, heartbeat_day=day, acks=t.payload["acks"],
            **caps)
        self.paused = False
        self.orders_today = 0
        self._day_equity_mark = self.broker.equity
        self.audit.append("l3.mandate_activated",
                          {"mid": self.mandate.mid, "tid": tid, "day": day,
                           "mode": caps["mode"]}, actor)
        return self.mandate

    def active(self, day: int | None = None) -> bool:
        m = self.mandate
        if not m or m.status != "active":
            return False
        if day is not None:
            if day > m.issued_day + m.ttl_days:
                return False
            if day - m.heartbeat_day > m.heartbeat_every:
                return False
        return True

    def heartbeat(self, day: int, actor: str = "human:web"):
        if not self.mandate or self.mandate.status != "active":
            raise LiveTradeRejected("no active mandate")
        self.mandate.heartbeat_day = day
        self.audit.append("l3.heartbeat", {"day": day,
                                           "mid": self.mandate.mid}, actor)

    def pause(self, actor="human:web"):
        self.paused = True
        self.audit.append("l3.paused", {}, actor)

    def resume(self, actor="human:web"):
        self.paused = False
        self.audit.append("l3.resumed", {}, actor)

    def flatten(self, actor="human:web", reason="human_flatten"):
        closed = [self.broker.close(k)
                  for k in list(self.broker.positions.keys())]
        self.audit.append("l3.flatten",
                          {"closed": len(closed), "reason": reason}, actor)
        if isinstance(self.adapter, LiveAdapter):
            try:
                r = self.adapter.client.cancel_all()
                self.audit.append("l3.venue_flatten",
                                  {"closed": r.get("closed", 0),
                                   "reason": reason}, actor)
            except Exception as e:            # noqa: BLE001 — audited
                self.audit.append("l3.venue_flatten_failed",
                                  {"why": str(e), "reason": reason}, actor)
        return len(closed)

    def demote(self, reason: str, day: int, actor="system"):
        if not self.mandate or self.mandate.status != "active":
            return
        n = self.flatten(actor="l3.session", reason=f"demote:{reason}")
        self.mandate.status = "revoked"
        self.mandate.revoke_reason = reason
        self.paused = False
        for i in self.queue:
            if i.status in ("pending", "approved"):
                i.status = "expired"
        self.demote_log.append({"day": day, "reason": reason})
        self.audit.append("l3.demoted",
                          {"reason": reason, "day": day, "flattened": n,
                           "mid": self.mandate.mid}, actor)

    def revoke(self, day: int, actor="human:web"):
        self.demote("human_revoked", day, actor)

    # ---------------- per-day machinery ----------------
    def on_day_start(self, day: int):
        m = self.mandate
        if not m or m.status != "active":
            return
        if day > m.issued_day + m.ttl_days:
            self.demote("ttl_expired", day)
            return
        if day - m.heartbeat_day > m.heartbeat_every:
            self.demote("deadman_expired", day)
            return
        if self.loss_today() >= m.loss_cap:
            self.demote("loss_cap", day)
            return
        self.orders_today = 0
        self._day_equity_mark = self.broker.equity
        self.mkt = (day, 0)
        if isinstance(self.adapter, LiveAdapter):
            try:
                vg = self.adapter.client.gross()
            except Exception as e:            # noqa: BLE001
                vg = None
                self.audit.append("l3.reconcile_unreachable",
                                  {"why": str(e)}, "l3.session")
            if vg is not None:
                bg = sum(p.notional
                         for p in self.broker.positions.values())
                if abs(vg - bg) > max(1.0, 0.001 * max(bg, vg)):
                    self.audit.append(
                        "l3.reconcile_mismatch",
                        {"venue_gross": round(vg, 2),
                         "broker_gross": round(bg, 2)}, "l3.session")
                    self.state.killswitch.human_trip(
                        "l3 reconcile mismatch: venue book diverged")
                    self.demote("reconcile_mismatch", day)
                    return
        # HITL pump (fallback): execute human-approved intents at TODAY's quotes
        ticks = {t.key(): t for t in self.state.driver.ticks_at(
            min(day, self.state.driver.total_days - 1), 0)}
        for i in self.queue:
            if i.status == "pending" and day > i.day:
                i.status = "expired"
                self.audit.append("l3.intent_expired", {"oid": i.oid},
                                  "l3.session")
            elif i.status == "approved":
                t = ticks.get(i.key)
                if not t:
                    continue
                token = self.gov.human_token(
                    f"l3:{m.mid}:{i.oid}")
                try:
                    self.gateway.submit(
                        i.key, i.side, i.notional, i.leverage, t,
                        dict(i.extra), i.extreme, live=True,
                        human_token=token, _approved_oid=i.oid)
                    i.status = "filled"
                    self.audit.append(
                        "l3.stale_fill",
                        {"oid": i.oid, "quoted_prem":
                         round(i.quoted_premium, 6),
                         "fill_prem": round(t.premium, 6),
                         "drift_bps": round(
                             (t.premium - i.quoted_premium) * 1e4, 2)},
                        "l3.session")
                except (LiveTradeRejected, RiskVeto) as e:
                    i.status = "rejected"
                    self.audit.append("l3.pump_rejected",
                                      {"oid": i.oid, "why": str(e)},
                                      "l3.session")

    def on_freeze(self, day: int):
        if self.active():
            self.demote("breaker", day)

    def loss_today(self) -> float:
        return max(0.0, self._day_equity_mark - self.broker.equity)

    # ---------------- order path (called by the gateway) ----------------
    def route(self, key, side, notional, lev, tick, extra, extreme,
              human_token, _approved_oid=None):
        """Returns a possibly-adjusted (tick, notional, extra_fee) for
        execution, raises to reject/queue. The gateway is the only caller."""
        m = self.mandate
        self._oid += 1
        oid = _approved_oid or f"O{self._oid:05d}"
        intent = OrderIntent(oid=oid, day=tick.day, key=key, side=side,
                             notional=notional, leverage=lev,
                             quoted_premium=tick.premium, extreme=extreme,
                             extra=dict(extra), period=tick.period)
        self.mkt = (tick.day, tick.period)
        why = self.gate.check(intent, tick.day)
        if why:
            self.gated += 1
            intent.verdict = why
            self.audit.append("l3.gated", {"oid": oid, "key": key,
                                           "why": why}, "l3.gate")
            if "loss_cap" in why:
                self.demote("loss_cap", tick.day)
            raise LiveTradeRejected("risk gate: " + ",".join(why))
        expected = self.gov.human_token(f"l3:{m.mid}:{oid}")
        if human_token and human_token != expected:
            self.gated += 1
            self.audit.append("l3.gated", {"oid": oid,
                                           "why": ["forged_token"]},
                              "l3.gate")
            raise LiveTradeRejected("risk gate: forged or stale human token")
        if m.mode == "hitl" and _approved_oid is None:
            intent.status = "pending"
            self.queue.append(intent)
            self.queued += 1
            self.audit.append("l3.queued",
                              {"oid": oid, "key": key, "side": side,
                               "notional": round(notional, 2)}, "l3.gate")
            raise QueuedForApproval(f"intent {oid} awaits human approval")
        # HOTL (or approved pump): mandate-scoped token mint, audited
        self.audit.append("l3.token_minted",
                          {"oid": oid, "basis": "mandate", "mid": m.mid},
                          "governance")
        f = self.adapter.fill(intent, tick)
        if f is None:
            self.gated += 1
            self.audit.append("l3.shadow_reject", {"oid": oid, "key": key},
                              "shadow.venue")
            raise LiveTradeRejected("shadow venue rejected the order")
        self.orders_today += 1
        self.fills += 1
        self.audit.append("l3.fill",
                          {"oid": oid, "key": key,
                           "slip_bps": f["slip_bps"], "ratio": f["ratio"],
                           "extra_fee": round(f["extra_fee"], 2)},
                          "shadow.venue")
        return f["tick"], notional * f["ratio"], f["extra_fee"]

    def _latest_tick(self, key: str):
        day = min(self.mkt[0], self.state.driver.total_days - 1)
        for period in (self.mkt[1], 0):
            for t in self.state.driver.ticks_at(day, period):
                if t.key() == key:
                    return t
        return None

    def approve_intent(self, oid: str, actor="human:web"):
        i = next(x for x in self.queue if x.oid == oid)
        if i.status not in ("pending", "stale_requote"):
            raise LiveTradeRejected(f"intent {oid} is {i.status}")
        i.status = "approved"
        self.audit.append("l3.intent_approved", {"oid": oid}, actor)
        m = self.mandate
        t = self._latest_tick(i.key)
        if not m or m.status != "active" or t is None:
            return i                      # day-start pump remains the fallback
        drift = (t.premium - i.quoted_premium) * 1e4
        if abs(drift) > m.max_requote_drift_bps:
            i.status = "stale_requote"
            i.requotes += 1
            i.quoted_premium = t.premium
            self.audit.append("l3.requote_required",
                              {"oid": oid, "drift_bps": round(drift, 2),
                               "requotes": i.requotes}, "l3.session")
            return i
        token = self.gov.human_token(f"l3:{m.mid}:{i.oid}")
        try:
            self.gateway.submit(i.key, i.side, i.notional, i.leverage, t,
                                dict(i.extra), i.extreme, live=True,
                                human_token=token, _approved_oid=i.oid)
            i.status = "filled"
            self.audit.append("l3.fresh_fill",
                              {"oid": oid, "drift_bps": round(drift, 2),
                               "day": t.day, "period": t.period}, "l3.session")
        except (LiveTradeRejected, RiskVeto) as e:
            i.status = "rejected"
            self.audit.append("l3.fresh_rejected",
                              {"oid": oid, "why": str(e)}, "l3.session")
        return i

    def reject_intent(self, oid: str, actor="human:web"):
        i = next(x for x in self.queue if x.oid == oid)
        i.status = "rejected"
        self.audit.append("l3.intent_rejected", {"oid": oid}, actor)
        return i

    # ---------------- snapshot ----------------
    def snapshot(self, day: int) -> dict:
        m = self.mandate
        if not m:
            return {"active": False}
        return {
            "active": self.active(day), "mode": m.mode, "mid": m.mid,
            "route": m.route,
            "venue": (getattr(self.adapter, "venue", "")
                      if isinstance(self.adapter, LiveAdapter)
                      else "shadow-sim"),
            "paused": self.paused, "status": m.status,
            "revokeReason": m.revoke_reason,
            "ttlDaysLeft": max(0, m.issued_day + m.ttl_days - day),
            "deadmanDaysLeft": max(
                0, m.heartbeat_day + m.heartbeat_every - day),
            "caps": {"perOrder": m.max_notional_per_order,
                     "gross": m.max_gross_notional,
                     "leverage": m.max_leverage, "lossCap": m.loss_cap,
                     "rate": m.order_rate_per_day,
                     "requoteDrift": m.max_requote_drift_bps,
                     "venues": m.venues},
            "used": {"ordersToday": self.orders_today,
                     "lossToday": round(self.loss_today(), 2),
                     "gross": round(sum(
                         p.notional
                         for p in self.broker.positions.values()), 2)},
            "counters": {"fills": self.fills, "gated": self.gated,
                         "queued": self.queued},
            "queue": [{"oid": i.oid, "key": i.key, "side": i.side,
                       "notional": round(i.notional, 2),
                       "lev": i.leverage, "status": i.status,
                       "day": i.day, "requotes": i.requotes,
                       "driftBps": (round(((t.premium - i.quoted_premium)
                                           * 1e4), 1)
                                    if (t := self._latest_tick(i.key))
                                    else 0.0)}
                      for i in self.queue[-12:]],
        }
