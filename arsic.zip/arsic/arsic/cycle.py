"""ARSIC daily operational cycle (spec S8) — exactly the spec's step order:

1. Perception plane refreshes wiki pages and graph edges.
2. Constellation agents run (Market Analyst -> Research -> Sentiment ->
   Opportunity), with recursive deep-dive children on extremes.
3. Strategy agents emit ranked proposals (entry/exit rules, size guidelines,
   risk limits, expected edge).
4. Experience Graph writer records trajectories + outcomes (paper results).
5. Improvement Proposer scans for gaps / prompt mutations / tool needs /
   topology changes -> tickets in the meta queue.
6. Governance reviews high-privilege proposals (pending queue surfaced).
7. Wiki Curator merges, cross-links and enriches pages overnight.
"""
from __future__ import annotations

from . import strategy_math as sm
from .bootstrap import SystemState, KEYS, SYMBOLS, VENUE_PAIRS
from .constellation import ts_of
from .evaluate import live_metrics
from .perception import PERIODS_PER_DAY


class DailyCycle:
    def __init__(self, state: SystemState):
        self.s = state

    def _dispatch(self, aid: str, kind: str, payload: dict):
        s = self.s
        task = s.scheduler.new_task(kind, s.agents[aid].scopes, payload)
        return s.scheduler.dispatch(aid, task)

    def run_day(self, day: int) -> dict:
        s = self.s
        regime = s.driver.regime_of(day)
        if getattr(s, "l3", None):
            s.l3.on_day_start(day)
        # -- morning human ops review (S8 step 6; bootstrap runs paper-only
        #    under daily human review): analyze + reset any organic trip so
        #    the freeze bites for the rest of trip-day, then trading resumes.
        if s.governance.frozen:
            why = s.governance.freeze_reasons[-1]["reason"] if \
                s.governance.freeze_reasons else "unknown"
            s.audit.append("human.ops_review",
                           {"day": day, "freeze_reason": why,
                            "finding": "synthetic squeeze print; paper book "
                                       "flat within limits; resume paper trading"},
                           "human:ops")
            s.governance.unfreeze(actor_role="human",
                                  analysis=f"day {day} ops review of '{why}'")
        for period in range(PERIODS_PER_DAY):
            # -- step 1: perception refresh (market every period; slower
            #    feeds once per day)
            self._dispatch("perc.market", "ingest_market",
                           {"day": day, "period": period})
            if period == 0:
                self._dispatch("perc.onchain", "ingest_onchain", {"day": day})
                self._dispatch("perc.sentiment", "ingest_sentiment", {"day": day})
                self._dispatch("perc.rwa", "ingest_rwa", {"day": day})
            # -- step 2: research
            self._dispatch("res.market_analyst", "analyze",
                           {"day": day, "period": period, "keys": KEYS})
            if period == 0:
                self._dispatch("res.research_analyst", "rwa_context", {"day": day})
                self._dispatch("res.sentiment", "narrative",
                               {"day": day, "symbols": SYMBOLS})
            self._dispatch("res.opportunity_scanner", "scan",
                           {"day": day, "period": period, "keys": KEYS})
            # -- step 3: strategy proposals
            self._dispatch("strat.funding_arb", "propose",
                           {"day": day, "period": period})
            self._dispatch("strat.basis_carry", "propose",
                           {"day": day, "period": period, "keys": KEYS})
            if period == 0:
                self._dispatch("strat.rwa_spread", "propose", {"day": day})
            self._dispatch("strat.cross_venue", "propose",
                           {"day": day, "period": period,
                            "venue_pairs": VENUE_PAIRS})
            # -- exec & risk (paper) on this period's snapshot
            ticks = s.agents["perc.market"].memory.get("last_ticks", {})
            self._dispatch("risk.sizing_exec", "exec",
                           {"day": day, "period": period, "ticks": ticks})
            self._dispatch("risk.liq_monitor", "monitor",
                           {"day": day, "period": period, "ticks": ticks})
            self._dispatch("risk.killswitch", "breakers",
                           {"day": day, "period": period, "keys": KEYS})
        # -- step 4: EXG writes the day's closed trajectories
        self._dispatch("meta.exg_writer", "record",
                       {"day": day, "regime": regime})
        # -- metrics + frozen-evaluator score for the day
        oracle = sm.oracle_funding_pnl(s.driver, s.trading.broker.equity0 * 0.10,
                                       upto_day=day)
        m = live_metrics(s.trading.broker, s.exg, s.pages, oracle)
        score = s.evaluator.score(m)
        s.agents["risk.killswitch"].memory["last_score"] = score
        if s.governance.frozen and getattr(s, "l3", None):
            s.l3.on_freeze(day)
        # -- step 5: improvement proposer -> tickets
        imp = self._dispatch("meta.improvement_proposer", "scan",
                             {"day": day, "metrics": m}) or {}
        # -- step 6: governance review surface
        pending = [t.tid for t in s.governance.pending()]
        s.audit.append("governance.review",
                       {"day": day, "pending_policy_plus": pending}, "governance")
        # -- step 7: curator overnight merge + enrich
        cur = self._dispatch("meta.wiki_curator", "curate", {"day": day}) or {}
        s.pages.freshness_cache = cur.get("freshness")
        self._dispatch("meta.evaluator", "score",
                       {"day": day, "metrics": m, "score": score})
        row = {"day": day, "regime": regime,
               "equity": round(s.trading.broker.equity, 2),
               "open_pos": len(s.trading.broker.positions),
               "closed_total": len(s.trading.broker.closed),
               "score": round(score, 4),
               "fp_rate": round(m["fp_rate"], 4),
               "capture_eff": round(m["capture_eff"], 4),
               "max_dd": round(m["max_dd"], 4),
               "notes": (imp.get("notes") or [])[:1],
               "pending_tickets": pending,
               "pages": cur.get("pages"), "freshness": cur.get("freshness")}
        s.daily_rows.append(row)
        return {"metrics": m, "score": score, "row": row}

    def run(self, days: int) -> dict:
        last = {}
        for d in range(days):
            last = self.run_day(d)
        return last
