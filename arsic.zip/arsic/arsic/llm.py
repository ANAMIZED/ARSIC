"""ARSIC agent cores (spec S7: 'LLM cores + tool-calling; harness as code').

The sandbox has no network, so DeterministicCore is a rule-based analyst whose
behaviour is steered by two things the improvement loops are allowed to
rewrite:

1. harness prompts — real template strings; the core parses bracketed
   directives (e.g. [[EXTREME_DISCOUNT]]) so a 'prompt mutation' visibly
   changes behaviour and can be A/B-tested + versioned in git;
2. an adapter table — the bounded 'model adapter (LoRA etc.)' slot (S5),
   fit only from verified sibling trajectories and clamped per epoch.

ProviderCore is the documented seam for a real LLM (raises offline)."""
from __future__ import annotations

from typing import Optional

from . import strategy_math as sm

ADAPTER_DEFAULT = {"risk_aversion": 1.0, "extreme_discount": 1.0}
ADAPTER_BOUND_PER_EPOCH = 0.25     # S5: bounded adapter updates


class LLMCore:
    def complete(self, template_name: str, prompt: str, context: dict) -> dict:
        raise NotImplementedError                     # pragma: no cover


class DeterministicCore(LLMCore):
    def __init__(self, prompts: dict, adapter: Optional[dict] = None):
        self.prompts = dict(prompts)
        self.adapter = {**ADAPTER_DEFAULT, **(adapter or {})}

    def _directives(self, name: str) -> set:
        import re
        return set(re.findall(r"\[\[([A-Z_]+)\]\]", self.prompts.get(name, "")))

    def complete(self, template_name: str, prompt: str, context: dict) -> dict:
        if template_name == "market_analysis":
            s: sm.SymStats = context["stats"]
            d = self._directives("market_analysis")
            note = "extreme print — discount as likely mean-reversion" \
                if ("EXTREME_DISCOUNT" in d and abs(s.z) > 2.5) else "within regime norms"
            return {"summary": f"{s.key}: f={s.funding:+.4%}/8h streak={s.streak} "
                               f"z={s.z:+.2f} basis={s.basis:+.3%} — {note}",
                    "discount_extreme": ("EXTREME_DISCOUNT" in d and abs(s.z) > 2.5)}
        if template_name == "opportunity_rank":
            ops = context["ops"]
            ra = self.adapter["risk_aversion"]
            ranked = sorted(ops, key=lambda o: o["edge"] / max(1e-9, ra), reverse=True)
            return {"ranked": ranked}
        if template_name == "deep_dive":
            histz = context["z_history"]
            reverted = sum(1 for a, b in zip(histz, histz[1:])
                           if abs(a) > 2.5 and abs(b) < abs(a) * 0.6)
            verdict = "unsustainable_extreme" if reverted >= 1 else "possibly_persistent"
            return {"verdict": verdict, "evidence_reversions": reverted}
        if template_name == "principle_abstract":
            trajs = context["trajs"]
            fps = [t for t in trajs if t["outcome"].get("fp")]
            if fps:
                return {"principle": ("extreme |z|>2.5 funding prints on low-liquidity "
                                      "symbols mean-revert within ~3 periods; treat as "
                                      f"traps (support n={len(fps)})")}
            return {"principle": f"persistent moderate funding was capturable "
                                 f"(support n={len(trajs)})"}
        raise KeyError(f"unknown template {template_name}")


class ProviderCore(LLMCore):
    """Seam for a real LLM provider. This sandbox has no network egress."""

    def complete(self, template_name: str, prompt: str, context: dict) -> dict:
        raise RuntimeError("network egress disabled in this environment; "
                           "wire your LLM provider here (see COMPLIANCE_MATRIX.md)")


def bounded_adapter_update(current: dict, proposed: dict) -> dict:
    out = {}
    for k, v in {**ADAPTER_DEFAULT, **current}.items():
        p = proposed.get(k, v)
        lo, hi = v - ADAPTER_BOUND_PER_EPOCH, v + ADAPTER_BOUND_PER_EPOCH
        out[k] = min(hi, max(lo, p))
    return out
