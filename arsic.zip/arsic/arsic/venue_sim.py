"""Loopback venue simulator — a real exchange wire protocol over HTTP.

Speaks the protocol a production connector must handle: HMAC-signed requests
with strictly-increasing nonces, idempotent client order ids, 429 throttling
with retry, partial fills, engineered rejects, scoped API keys (the sentinel
credential may cancel and read but never place), and a venue-side position
ledger so reconciliation against the ARSIC book is meaningful.

Fill semantics are deterministic and IDENTICAL to ShadowLiveAdapter (same
hash, same reject/slip/partial/fee math) so the external route is
conformance-testable against the shadow route bit-for-bit.

This is the in-sandbox test venue. Pointing the client at a real venue is a
human act outside this environment (env credentials + explicit risk ack).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def _h(*parts) -> int:
    return int(hashlib.sha256("|".join(map(str, parts)).encode())
               .hexdigest()[:12], 16)


def sign(secret: str, method: str, path: str, body: str, nonce: str) -> str:
    msg = f"{method}|{path}|{body}|{nonce}".encode()
    return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()


class VenueSim:
    """State + matching logic. `keys` maps api_key -> {"secret", "scope"}
    where scope is "trade" (full) or "cancel" (cancel/read only)."""

    def __init__(self, keys: dict, salt: str = "shadow:0"):
        self.keys = keys
        self.salt = salt
        self.lock = threading.Lock()
        self.positions: dict[str, dict] = {}
        self.fills: list[dict] = []
        self.fees = 0.0
        self.orders: dict[str, dict] = {}       # client_oid -> response (idempotency)
        self.throttled_once: set[str] = set()
        self.nonces: dict[str, int] = {}
        self.requests = 0

    # ---------------- auth ----------------
    def auth(self, api_key, nonce, sig, method, path, body):
        k = self.keys.get(api_key)
        if not k:
            return 401, {"error": "unknown api key"}
        try:
            n = int(nonce)
        except (TypeError, ValueError):
            return 401, {"error": "bad nonce"}
        if n <= self.nonces.get(api_key, -1):
            return 409, {"error": "nonce replay"}
        expected = sign(k["secret"], method, path, body, nonce)
        if not hmac.compare_digest(expected, sig or ""):
            return 401, {"error": "bad signature"}
        self.nonces[api_key] = n
        return 200, k

    # ---------------- endpoints ----------------
    def place(self, key_info, body: dict):
        if key_info["scope"] != "trade":
            return 403, {"error": "credential scope: cancel/read only"}
        coid = str(body.get("client_oid", ""))
        if not coid:
            return 400, {"error": "client_oid required"}
        with self.lock:
            if coid in self.orders:              # idempotent replay
                return 200, self.orders[coid]
            h = _h(self.salt, coid)
            if h % 13 == 0 and coid not in self.throttled_once:
                self.throttled_once.add(coid)    # first attempt throttled
                return 429, {"error": "throttled", "retry_after": 0}
            if h % 23 == 0:
                resp = {"client_oid": coid, "status": "rejected",
                        "reason": "venue_reject"}
                self.orders[coid] = resp
                return 200, resp
            slip_bps = 1 + (h % 7)
            ratio = 0.6 if h % 11 == 0 else 1.0
            notional = float(body["notional"]) * ratio
            fee = 0.5e-4 * notional
            mkey = str(body["key"])
            side = int(body["side"])
            p = self.positions.get(mkey)
            with_side = notional * side
            if p and p["side"] != side:
                # netting: opposite side reduces/closes
                new = p["notional"] * p["side"] + with_side
                if abs(new) < 1e-9:
                    self.positions.pop(mkey, None)
                else:
                    self.positions[mkey] = {
                        "side": 1 if new > 0 else -1,
                        "notional": abs(new),
                        "leverage": float(body.get("leverage", 1.0))}
            else:
                cur = p["notional"] if p else 0.0
                self.positions[mkey] = {
                    "side": side, "notional": cur + notional,
                    "leverage": float(body.get("leverage", 1.0))}
            self.fees += fee
            resp = {"client_oid": coid, "status":
                    "partial" if ratio < 1.0 else "filled",
                    "fill_ratio": ratio, "slip_bps": slip_bps, "fee": fee}
            self.orders[coid] = resp
            self.fills.append({"client_oid": coid, "key": mkey,
                               "side": side, "notional": notional})
            return 200, resp

    def cancel_all(self, key_info):
        with self.lock:
            n = len(self.positions)
            self.positions.clear()
            return 200, {"closed": n}

    def get_positions(self, key_info):
        with self.lock:
            return 200, {"positions": [
                {"key": k, **v} for k, v in sorted(self.positions.items())]}


def make_handler(sim: VenueSim):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            data = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _handle(self, method):
            sim.requests += 1
            path = self.path
            if method == "GET" and path == "/v1/health":
                return self._json(200, {"ok": True, "venue": "sim"})
            length = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(length).decode() if length else ""
            code, k = sim.auth(self.headers.get("X-API-KEY"),
                               self.headers.get("X-NONCE"),
                               self.headers.get("X-SIGNATURE"),
                               method, path, body)
            if code != 200:
                return self._json(code, k)
            if method == "POST" and path == "/v1/order":
                return self._json(*sim.place(k, json.loads(body or "{}")))
            if method == "POST" and path == "/v1/cancel_all":
                return self._json(*sim.cancel_all(k))
            if method == "GET" and path == "/v1/positions":
                return self._json(*sim.get_positions(k))
            self._json(404, {"error": "not found"})

        def do_GET(self):
            self._handle("GET")

        def do_POST(self):
            self._handle("POST")

    return H


def serve_venue(keys: dict, port: int, salt: str = "shadow:0"):
    sim = VenueSim(keys, salt)
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(sim))
    th = threading.Thread(target=httpd.serve_forever, daemon=True)
    th.start()
    return sim, httpd
