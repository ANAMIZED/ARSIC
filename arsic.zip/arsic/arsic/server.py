"""ARSIC backend server: exposes the live Python SystemState over a local
JSON API in exactly the snapshot shape the ARSIC.html console renders, plus
action endpoints for every human key (approvals, kill-switch, epochs,
adapters, arbiter). Stdlib only; paper-only invariants are enforced by the
underlying governance/gateway exactly as in the CLI.

Run:  python3 -m arsic serve --root run_srv --port 8787
Then open http://127.0.0.1:8787/ — the console auto-wires to this backend.
"""
from __future__ import annotations

import json
import os
import shutil
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from .bootstrap import build_system
from .cycle import DailyCycle
from .governance import Priv, ContractError
from .improve import Harness
from .evaluate import Evaluator, EvaluatorEvolution, live_metrics
from .perception import SyntheticMarket
from .strategy_math import oracle_funding_pnl, simulate
from . import autonomy
from .execution_l3 import L3Session, ACK_1, ACK_2

SCHEDULE = [("trend", 8), ("range", 7), ("high_vol", 8), ("post_squeeze", 7)]
TOTAL_DAYS = sum(n for _, n in SCHEDULE)

CANDIDATES = [
    ("tighten extreme filter (+prompt directive)", Priv.SKILL,
     {"strategy.z_cap": 2.5, "strategy.persistence_min": 3,
      "prompts.market_analysis": "+[[EXTREME_DISCOUNT]]"}),
    ("raise leverage to 5x", Priv.SKILL, {"strategy.max_leverage": 5.0}),
    ("cross-venue precheck in topology", Priv.POLICY,
     {"routing.cross_venue_precheck": True, "strategy.xv_gap_min": 0.0005,
      "topology": "cross_venue_precheck"}),
]

GROUPS = ("market", "analysis", "strategy", "rwa", "onchain", "sent", "meta", "seed")


class Srv:
    """Mutable server session: one live constellation + flow caches."""

    def __init__(self, root: str, seed: int = 7, html: str | None = None):
        self.lock = threading.RLock()
        self.root_base = root
        self.html = html
        self.fits: dict = {}     # tid -> (bounded, ticket)
        self.evals: dict = {}    # tid -> (candidate, ticket)
        self.epoch_no = 0
        self.evo = None
        self.reset(seed)

    # ---------------- lifecycle ----------------
    def reset(self, seed: int):
        root = os.path.join(self.root_base, f"s{seed}")
        shutil.rmtree(root, ignore_errors=True)
        self.state = build_system(seed, SCHEDULE, root)
        self.cycle = DailyCycle(self.state)
        self.day = 0
        self.seed = seed
        self.fits.clear()
        self.evals.clear()
        self.epoch_no = 0
        self.evo = EvaluatorEvolution(self.state.governance, self.state.board,
                                      self.state.audit)
        self.sentinel_ping = None
        self.auto_cfg = {"research_every": 5, "epoch_every": 10,
                         "seeds": [1, 2, 3, 4], "days": 5, "epochs": 0}
        return {"seed": seed, "days": TOTAL_DAYS}

    # ---------------- snapshot ----------------
    def snapshot(self) -> dict:
        s = self.state
        g = s.governance
        br = s.trading.broker
        upto = max(0, self.day - 1)
        live = live_metrics(br, s.exg, s.pages,
                            oracle_funding_pnl(s.driver, 1e5, upto)) \
            if self.day else {"pnl": 0, "sharpe": 0, "max_dd": 0,
                              "capture_eff": 0, "fp_rate": 0, "n_ops": 0}
        pages = {}
        for name, pg in s.pages.pages.items():
            rows = []
            for r in getattr(pg, "rows", None) or self._page_rows(name):
                rows.append(r)
            pages[name] = {"version": pg["version"], "ts": pg["ts"],
                           "hash": pg["hash"][:16],
                           "seedText": pg.get("seed_text") or self._seed_text(pg),
                           "rows": rows}
        now = time.time()
        pol = [t for t in g.tickets.values()
               if t.level >= int(Priv.POLICY) and t.status in ("approved", "applied")]
        return {
            "mode": "python", "seed": self.seed,
            "day": self.day, "totalDays": TOTAL_DAYS,
            "l3": (self.state.l3.snapshot(self.day)
                   if getattr(self.state, "l3", None) else {"active": False}),
            "l3Acks": [ACK_1, ACK_2],
            "frozen": g.frozen,
            "freezeReason": (g.freeze_reasons[-1]["reason"]
                             if g.freeze_reasons else None),
            "autonomy": g.autonomy_level,
            "equity": br.equity, "equity0": br.equity0,
            "sentinel": ({"alive": (time.time() -
                                    self.sentinel_ping["ts"]) < 5.0,
                          "ageS": round(time.time() -
                                        self.sentinel_ping["ts"], 1),
                          "status": self.sentinel_ping.get("status"),
                          "detail": self.sentinel_ping.get("detail", ""),
                          "acted": self.sentinel_ping.get("acted", 0)}
                         if self.sentinel_ping else None),
            "curve": [round(x, 2) for x in br.curve[-400:]],
            "positions": [{"key": p.key, "side": p.side,
                           "notional": round(p.notional, 2),
                           "hold": p.hold, "net": round(p.net, 2)}
                          for p in br.positions.values()],
            "closedCount": len(br.closed),
            "dailyRows": [{"day": r["day"], "regime": r["regime"],
                           "equity": r["equity"], "openPos": r["open_pos"],
                           "closedTotal": r["closed_total"], "score": r["score"],
                           "fp": r["fp_rate"]}
                          for r in s.daily_rows],
            "live": live,
            "agents": [{"id": a.id,
                        "plane": {"perception": "perception", "research": "research",
                                  "strategy": "strategy", "risk": "risk",
                                  "meta": "meta"}.get(a.ROLE.split(".")[0], "meta"),
                        "status": (a.status or {}).get("state", "idle"),
                        "suspended": a.suspended,
                        "children": [{"id": c.id,
                                      "status": (c.status or {}).get("state", "child")}
                                     for c in a.children[-4:]]}
                       for a in s.agents.values()],
            "pages": pages,
            "freshness": s.pages.freshness(now),
            "conflictRate": s.kg.conflict_rate(),
            "arbiter": [{"key": list(c["key"]),
                         "incumbent": {"value": c["incumbent"]["value"],
                                       "prov": {"source_id":
                                                c["incumbent"]["prov"]["source_id"]}},
                         "challenger": {"value": c["challenger"]["value"],
                                        "prov": {"source_id":
                                                 c["challenger"]["prov"]["source_id"]}}}
                        for c in s.kg.arbiter_queue],
            "graph": self._graph(now),
            "tickets": [{"tid": t.tid, "level": t.level, "title": t.title,
                         "status": t.status, "approver": t.approver,
                         "kind": (t.payload or {}).get("kind")}
                        for t in g.tickets.values()],
            "pendingCount": len(g.pending()),
            "ksCfg": s.killswitch.cfg,
            "evaluator": {"frozen": s.evaluator.frozen, "hash": s.evaluator.hash},
            "repo": [{"version": c["version"], "msg": c["msg"], "hash": c["hash"]}
                     for c in self._commits()],
            "candidates": [{"title": t, "level": int(l)} for t, l, _ in CANDIDATES],
            "gateway": {"liveTrades": s.trading.gateway.live_trades,
                        "liveRejections": s.trading.gateway.live_rejections},
            "handoffs": len(s.router.handoffs),
            "auditCount": s.audit.count(),
            "policyPlusAllHuman": all(str(t.approver).startswith("human")
                                      for t in pol),
            "harnessVersion": s.harness.version,
        }

    def _commits(self):
        out = []
        for c in getattr(self.state.repo, "commits", []):
            if isinstance(c, dict):
                out.append({"version": c.get("version"), "msg": c.get("msg", ""),
                            "hash": str(c.get("hash", ""))[:12]})
            else:
                out.append({"version": getattr(c, "version", "?"),
                            "msg": getattr(c, "msg", str(c)),
                            "hash": str(getattr(c, "hash", ""))[:12]})
        return out

    def _seed_text(self, pg) -> str | None:
        md = pg.get("md", "")
        return md if md and "| predicate |" not in md else None

    def _page_rows(self, entity: str) -> list:
        rows = []
        for (sub, pred), hist in self.state.kg.edges.items():
            if sub != entity or not hist:
                continue
            r = hist[-1]
            rows.append({"pred": pred, "value": r["value"], "conf": r["conf"],
                         "src": r["prov"]["source_id"],
                         "src_hash": r["prov"]["source_hash"][:16],
                         "cid": r["cid"], "ts": r["ts"]})
        rows.sort(key=lambda x: x["pred"])
        return rows

    def _graph(self, now: float) -> dict:
        kg = self.state.kg
        ids = set(kg.entities) | set(self.state.pages.pages)
        links, seen = [], set()

        def add(a, b, label):
            if a == b or a not in ids or b not in ids:
                return
            k = (a, b) if a < b else (b, a)
            if k in seen:
                return
            seen.add(k)
            links.append({"a": a, "b": b, "label": label})

        for (sub, pred), hist in kg.edges.items():
            for r in hist:
                if isinstance(r["value"], str) and r["value"] in ids:
                    add(sub, r["value"], pred)
        tail = lambda i: i.split(":")[-1]
        markets = [i for i in ids if i.startswith("market:")]
        for i in ids:
            if i.startswith(("onchain:", "sent:")):
                for m in markets:
                    if tail(m) == tail(i):
                        add(i, m, "observes")
            if i.startswith("rwa:"):
                for m in markets:
                    if tail(i).split("-")[0] in tail(m).lower():
                        add(i, m, "underlies")
            if i == "analysis:rwa":
                for r in ids:
                    if r.startswith("rwa:"):
                        add(i, r, "covers")
            if i == "analysis:sentiment":
                for x in ids:
                    if x.startswith("sent:"):
                        add(i, x, "covers")
            if i.startswith("strategy:") and "seed:strategy_templates" in ids:
                add(i, "seed:strategy_templates", "template")
            if (i.startswith("meta:") or (i.startswith("seed:")
                                          and i != "seed:system")) \
                    and "seed:system" in ids:
                add(i, "seed:system", "system")
        deg: dict = {}
        for l in links:
            deg[l["a"]] = deg.get(l["a"], 0) + 1
            deg[l["b"]] = deg.get(l["b"], 0) + 1
        nodes = []
        for i in sorted(ids):
            pg = self.state.pages.pages.get(i)
            rows = len(self._page_rows(i)) if pg else 0
            grp = i.split(":")[0]
            nodes.append({"id": i, "group": grp if grp in GROUPS else "meta",
                          "size": 3.4 + min(6.5, deg.get(i, 0) * 0.75 + rows / 6),
                          "fresh": bool(pg) and now - pg["ts"] <= 86400})
        return {"nodes": nodes, "links": links}

    # ---------------- actions ----------------
    def run_day(self):
        if self.day >= TOTAL_DAYS:
            return {"done": True}
        row = self.cycle.run_day(self.day)
        self.day += 1
        return {"row": row, "day": self.day}

    def autonomy(self, level: int):
        if level >= 3:
            raise ContractError("L3 live-eligible is never grantable in this build")
        g = self.state.governance
        if level != g.autonomy_level + 1:
            raise ContractError(f"advance must be stepwise (currently L{g.autonomy_level})")
        t = g.request(Priv.META, f"advance autonomy to L{level}",
                      {"kind": "autonomy", "level": level}, "human:web")
        return {"ticket": {"tid": t.tid, "status": t.status}}

    def approve(self, tid: str):
        g = self.state.governance
        t = g.tickets[tid]
        g.approve(tid, actor_role="human", actor="human:web")
        if (t.payload or {}).get("kind") == "autonomy":
            g.mark_applied(t)
            g.autonomy_level = t.payload["level"]
            self.state.audit.append("autonomy.advanced",
                                    {"level": t.payload["level"]}, "governance")
        return {"tid": tid, "status": t.status}

    def epoch(self, pre_approve: bool, seeds=None, days=None):
        s = self.state
        cands = [(t, l, dict(d)) for t, l, d in CANDIDATES]
        orig = s.governance.request
        if pre_approve:
            def wrapped(level, title, payload, actor):
                t = orig(level, title, payload, actor)
                if int(level) >= int(Priv.POLICY) and t.status == "pending":
                    s.governance.approve(t.tid, actor_role="human",
                                         actor="human:web")
                return t
            s.governance.request = wrapped
        try:
            promoted, reports = s.evolution.epoch(
                s.harness, seeds or list(range(1, 11)), days=days or 8,
                candidates=cands, epoch_no=self.epoch_no)
        finally:
            s.governance.request = orig
        self.epoch_no += 1
        if promoted.version > s.harness.version:
            s.harness = promoted
            s.core.prompts = dict(promoted.prompts)
            s.core.adapter = dict(promoted.adapter)
            s.audit.append("harness.swapped", {"version": promoted.version},
                           "governance")
        out = [{"title": r.candidate_title, "level": int(r.level),
                "lint": list(r.lint_violations or []),
                "p": float(r.p_value), "meanDiff": float(r.mean_diff),
                "perRegime": dict(r.per_regime or {}),
                "promoted": bool(r.promoted), "ticket": r.ticket_id,
                "reason": r.reason} for r in reports]
        return {"reports": out, "promotedVersion": s.harness.version}

    def adapter_fit(self):
        s = self.state
        out_dir = os.path.join(s.root, "reports", "training_data")
        bounded, ticket, paths = s.evolution.fit_adapter(s.harness, out_dir)
        self.fits[ticket.tid] = (bounded, ticket)
        n = ticket.payload.get("n_verified", 0)
        counts = {}
        for k, p in paths.items():
            try:
                with open(p) as f:
                    counts[k] = sum(1 for _ in f)
            except OSError:
                counts[k] = 0
        return {"bounded": bounded, "nVerified": n,
                "ticket": {"tid": ticket.tid, "status": ticket.status},
                "datasets": counts}

    def adapter_apply(self, tid: str):
        bounded, ticket = self.fits.pop(tid)
        h2 = self.state.evolution.apply_adapter(self.state.harness, bounded, ticket)
        self.state.harness = h2
        self.state.core.adapter = dict(h2.adapter)
        self.state.audit.append("harness.swapped", {"version": h2.version},
                                "governance")
        return {"version": h2.version, "adapter": h2.adapter}

    def evalco_attempt(self):
        cand = Evaluator({"w_fp": 4.0, "w_dd": 3.0})
        beat, ticket, taus = self.evo.attempt(self.state.evaluator, cand)
        self.evals[ticket.tid] = (cand, ticket)
        return {"beat": beat, "taus": list(taus),
                "ticket": {"tid": ticket.tid, "status": ticket.status}}

    def evalco_replace(self, tid: str):
        cand, ticket = self.evals.pop(tid)
        old = self.state.evaluator.hash
        new_eval = self.evo.replace(self.state.evaluator, cand, ticket)
        self.state.evaluator = new_eval
        self.state.evolution.evaluator = new_eval
        last = self.state.audit.tail(3)
        erased = next((e.payload.get("scores_erased") for e in reversed(last)
                       if e.kind == "evaluator.replaced"), 0)
        return {"hash": new_eval.hash, "old": old, "erased": erased}

    def compounding(self, seed: int = 8):
        s = self.state
        fresh = SyntheticMarket(seed=seed, schedule=SCHEDULE)
        base = Harness()
        r1 = simulate(base.strategy, fresh, base.adapter).metrics(1e6)
        rN = simulate(s.harness.strategy, fresh, s.harness.adapter).metrics(1e6)
        oracle = oracle_funding_pnl(fresh, 1e6)
        return {"seed": seed, "oracle": oracle,
                "net1": r1["pnl"] / oracle, "netN": rN["pnl"] / oracle,
                "gapClosed": (rN["pnl"] - r1["pnl"]) / oracle,
                "v1": {"pnl": r1["pnl"], "fp_rate": r1["fp_rate"]},
                "vN": {"pnl": rN["pnl"], "fp_rate": rN["fp_rate"]},
                "version": s.harness.version}

    def auto_tick(self, opts: dict):
        for k in ("research_every", "epoch_every", "seeds", "days"):
            if k in opts:
                self.auto_cfg[k] = opts[k]
        self.day, out = autonomy.auto_tick(self.state, self.cycle, self.day,
                                           self.auto_cfg)
        return out

    def selftest(self):
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        tdir = os.path.join(here, "tests")
        names = sorted(f[:-3] for f in os.listdir(tdir)
                       if f.startswith("test_") and f.endswith(".py")
                       and f != "test_server.py")
        results = []

        class R(unittest.TestResult):
            def addSuccess(self, test):
                results.append({"name": str(test.id()).split(".")[-1]
                                + " (" + test.id().split(".")[0] + ")",
                                "pass": True})

            def addFailure(self, test, err):
                results.append({"name": test.id(), "pass": False,
                                "info": str(err[1])[:160]})

            def addError(self, test, err):
                results.append({"name": test.id(), "pass": False,
                                "info": str(err[1])[:160]})

        import sys
        if tdir not in sys.path:
            sys.path.insert(0, tdir)
        t0 = time.time()
        suite = unittest.defaultTestLoader.loadTestsFromNames(names)
        cwd = os.getcwd()
        os.chdir(here)                      # tests use relative tmp roots
        try:
            suite.run(R())
        finally:
            os.chdir(cwd)
        ok = sum(1 for r in results if r["pass"])
        return {"passed": ok, "total": len(results),
                "results": results, "ms": int((time.time() - t0) * 1000)}


def make_handler(srv: Srv):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, obj, code=200):
            b = json.dumps(obj, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def do_GET(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            try:
                with srv.lock:
                    if u.path == "/api/health":
                        return self._json({"ok": True, "engine": "python",
                                           "days": TOTAL_DAYS})
                    if u.path == "/api/state":
                        since = int(q.get("since", ["0"])[0])
                        rows = [e for e in srv.state.audit.all()
                                if e.seq >= since]
                        return self._json({
                            "snapshot": srv.snapshot(),
                            "events": [{"seq": e.seq, "kind": e.kind,
                                        "actor": e.actor, "payload": e.payload,
                                        "hash": e.hash} for e in rows[-250:]],
                            "cursor": (rows[-1].seq + 1) if rows
                                      else since})
                    if u.path == "/api/audit/verify":
                        ok, bad = srv.state.audit.verify()
                        return self._json({"ok": ok, "firstBad": bad,
                                           "count": srv.state.audit.count()})
                    if u.path == "/api/audit/tail":
                        n = int(q.get("n", ["12"])[0])
                        return self._json([{"seq": e.seq, "kind": e.kind,
                                            "hash": e.hash}
                                           for e in srv.state.audit.tail(n)])
                    if u.path == "/api/audit/export":
                        p = srv.state.audit.path
                        with open(p, "rb") as f:
                            b = f.read()
                        self.send_response(200)
                        self.send_header("Content-Type",
                                         "application/x-ndjson")
                        self.send_header("Content-Disposition",
                                         "attachment; filename=arsic-audit.jsonl")
                        self.send_header("Content-Length", str(len(b)))
                        self.end_headers()
                        self.wfile.write(b)
                        return
                    if u.path == "/api/wiki/trace":
                        cid = q.get("cid", [""])[0]
                        return self._json(srv.state.pages.trace(cid) or {})
                if u.path in ("/", "/index.html") and srv.html \
                        and os.path.exists(srv.html):
                    with open(srv.html, "rb") as f:
                        b = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(b)))
                    self.end_headers()
                    self.wfile.write(b)
                    return
                self._json({"error": "not found"}, 404)
            except Exception as e:                       # noqa: BLE001
                self._json({"error": str(e)}, 500)

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            u = urlparse(self.path).path
            try:
                with srv.lock:
                    if u == "/api/reset":
                        return self._json(srv.reset(int(body.get("seed", 7))))
                    if u == "/api/day":
                        return self._json(srv.run_day())
                    if u == "/api/autonomy":
                        return self._json(srv.autonomy(int(body["level"])))
                    if u == "/api/ticket/approve":
                        return self._json(srv.approve(body["tid"]))
                    if u == "/api/ticket/reject":
                        srv.state.governance.reject(body["tid"],
                                                    actor_role="human",
                                                    actor="human:web")
                        return self._json({"tid": body["tid"],
                                           "status": "rejected"})
                    if u == "/api/seal":
                        ev = srv.state.evaluator
                        return self._json({"hash": ev.hash if ev.frozen
                                           else ev.freeze()})
                    if u == "/api/epoch":
                        return self._json(srv.epoch(
                            bool(body.get("preApprovePolicy")),
                            body.get("seeds"), body.get("days")))
                    if u == "/api/adapter/fit":
                        return self._json(srv.adapter_fit())
                    if u == "/api/adapter/apply":
                        return self._json(srv.adapter_apply(body["tid"]))
                    if u == "/api/evalco/attempt":
                        return self._json(srv.evalco_attempt())
                    if u == "/api/evalco/replace":
                        return self._json(srv.evalco_replace(body["tid"]))
                    if u == "/api/killswitch/drill":
                        hits = srv.state.killswitch.evaluate(
                            {"max_abs_funding": 0.021})
                        return self._json({"hits": hits,
                                           "frozen": srv.state.governance.frozen})
                    if u == "/api/killswitch/trip":
                        srv.state.killswitch.human_trip(
                            body.get("reason", "operator"))
                        return self._json({"frozen": True})
                    if u == "/api/killswitch/reset":
                        a = (body.get("analysis") or "").strip()
                        if not a:
                            return self._json({"error": "analysis required"},
                                              400)
                        srv.state.audit.append("human.ops_review",
                                               {"phase": "web reset"},
                                               "human:web")
                        srv.state.governance.unfreeze(actor_role="human",
                                                      analysis=a,
                                                      actor="human:web")
                        return self._json({"frozen": False})
                    if u == "/api/sentinel/ping":
                        srv.sentinel_ping = {**(body or {}),
                                             "ts": time.time()}
                        return self._json({"ok": True})
                    if u == "/api/l3/request":
                        ses = getattr(srv.state, "l3", None) or \
                            L3Session(srv.state, srv.state.trading.gateway)
                        t, caps = ses.request_mandate(body or {},
                                                      actor="human:web")
                        return self._json({"tid": t.tid, "caps": caps,
                                           "title": t.title})
                    if u == "/api/l3/activate":
                        m = srv.state.l3.activate(body["tid"], srv.day,
                                                  actor="human:web")
                        return self._json({"mid": m.mid, "mode": m.mode})
                    if u == "/api/l3/heartbeat":
                        srv.state.l3.heartbeat(srv.day, actor="human:web")
                        return self._json({"ok": True, "day": srv.day})
                    if u == "/api/l3/pause":
                        srv.state.l3.pause(actor="human:web")
                        return self._json({"ok": True})
                    if u == "/api/l3/resume":
                        srv.state.l3.resume(actor="human:web")
                        return self._json({"ok": True})
                    if u == "/api/l3/flatten":
                        n = srv.state.l3.flatten(actor="human:web")
                        return self._json({"closed": n})
                    if u == "/api/l3/revoke":
                        srv.state.l3.revoke(srv.day, actor="human:web")
                        return self._json({"ok": True})
                    if u == "/api/l3/order/approve":
                        i = srv.state.l3.approve_intent(body["oid"],
                                                        actor="human:web")
                        return self._json({"oid": i.oid, "status": i.status})
                    if u == "/api/l3/order/reject":
                        i = srv.state.l3.reject_intent(body["oid"],
                                                       actor="human:web")
                        return self._json({"oid": i.oid, "status": i.status})
                    if u == "/api/auto/tick":
                        return self._json(srv.auto_tick(body or {}))
                    if u == "/api/compounding":
                        return self._json(
                            srv.compounding(int(body.get("seed", 8))))
                    if u == "/api/probe":
                        s = srv.state
                        t = s.driver.ticks_at(min(max(srv.day - 1, 0),
                                                  TOTAL_DAYS - 1), 0)[0]
                        try:
                            s.trading.gateway.submit(
                                t.key(), 1, 50_000, 2.0, t, {}, False,
                                live=True, human_token="forged")
                            rejected = False
                        except Exception:                # noqa: BLE001
                            rejected = True
                        return self._json(
                            {"rejected": rejected,
                             "liveTrades": s.trading.gateway.live_trades,
                             "liveRejections":
                                 s.trading.gateway.live_rejections})
                    if u == "/api/arbiter":
                        srv.state.kg.resolve_conflict(int(body["idx"]),
                                                      body["pick"],
                                                      actor_role="human",
                                                      actor="human:web")
                        return self._json({"ok": True})
                    if u == "/api/selftest":
                        return self._json(srv.selftest())
                self._json({"error": "not found"}, 404)
            except (ContractError, KeyError) as e:
                self._json({"error": str(e)}, 400)
            except Exception as e:                       # noqa: BLE001
                self._json({"error": str(e)}, 500)

    return H


def serve(root: str, port: int = 8787, seed: int = 7,
          html: str | None = None, block: bool = True):
    srv = Srv(root, seed, html)
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(srv))
    print(f"ARSIC backend on http://127.0.0.1:{port}/  root={root} seed={seed}"
          f"  console={'served' if html else 'api-only'}")
    if block:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
    else:
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return srv, httpd
