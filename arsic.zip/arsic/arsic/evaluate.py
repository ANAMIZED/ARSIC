"""ARSIC evaluators (spec S5 'Evaluator Co-Evolution', S9 metrics).

- Evaluator: parameterised composite score; freeze() seals params (hash);
  mutation after freeze raises. Promotion decisions reference the hash.
- Ground truth: a small human-curated ranking of archetypal run outcomes;
  a candidate evaluator replaces the incumbent ONLY if it beats it on this
  set (Kendall tau), and only via a human-approved POLICY ticket.
- Scoreboard with selective erasure: after replacement, scores from the old
  evaluator are marked non-comparable (contamination guard).
"""
from __future__ import annotations

import math
import statistics as st
from dataclasses import dataclass, field
from typing import Optional

from .events import sha, EventLog
from .governance import Governance, Priv


class FrozenEvaluatorError(Exception):
    pass


DEFAULT_EVAL_PARAMS = {"w_sharpe": 1.0, "w_capture": 2.0,
                       "w_fp": 3.0, "w_dd": 2.0}


class Evaluator:
    def __init__(self, params: Optional[dict] = None):
        self._params = {**DEFAULT_EVAL_PARAMS, **(params or {})}
        self.frozen = False
        self._hash = ""

    @property
    def params(self) -> dict:
        return dict(self._params)

    @property
    def hash(self) -> str:
        return self._hash or sha(self._params)[:16]

    def freeze(self) -> str:
        self.frozen = True
        self._hash = sha(self._params)[:16]
        return self._hash

    def set_param(self, k: str, v: float) -> None:
        if self.frozen:
            raise FrozenEvaluatorError("evaluator is frozen for this epoch (S5)")
        self._params[k] = v

    def score(self, m: dict) -> float:
        p = self._params
        return (p["w_sharpe"] * math.tanh(m.get("sharpe", 0.0) / 3.0)
                + p["w_capture"] * m.get("capture_eff", 0.0)
                - p["w_fp"] * m.get("fp_rate", 0.0)
                - p["w_dd"] * m.get("max_dd", 0.0))


# ---------------------------------------------------------------------------
# Human-curated ground truth (S5): archetypal run outcomes with the ranking a
# careful human desk would give (1 = best). Curated once, versioned here.
# ---------------------------------------------------------------------------

GROUND_TRUTH = [
    # (label, metrics, human_rank)
    ("steady_capture",   {"sharpe": 2.2, "capture_eff": 0.45, "fp_rate": 0.02, "max_dd": 0.02}, 1),
    ("good_capture_dd",  {"sharpe": 1.8, "capture_eff": 0.40, "fp_rate": 0.05, "max_dd": 0.05}, 2),
    ("modest_clean",     {"sharpe": 1.0, "capture_eff": 0.25, "fp_rate": 0.03, "max_dd": 0.03}, 3),
    ("lucky_but_trappy", {"sharpe": 2.6, "capture_eff": 0.50, "fp_rate": 0.30, "max_dd": 0.12}, 4),
    ("high_ret_huge_dd", {"sharpe": 2.9, "capture_eff": 0.55, "fp_rate": 0.10, "max_dd": 0.30}, 5),
    ("churner",          {"sharpe": 0.2, "capture_eff": 0.10, "fp_rate": 0.15, "max_dd": 0.06}, 6),
    ("bleeder",          {"sharpe": -0.5, "capture_eff": 0.05, "fp_rate": 0.20, "max_dd": 0.10}, 7),
    ("blown_up",         {"sharpe": -1.5, "capture_eff": 0.02, "fp_rate": 0.40, "max_dd": 0.35}, 8),
]


def kendall_tau(rank_a: list, rank_b: list) -> float:
    n = len(rank_a)
    conc = disc = 0
    for i in range(n):
        for j in range(i + 1, n):
            s = (rank_a[i] - rank_a[j]) * (rank_b[i] - rank_b[j])
            conc += 1 if s > 0 else 0
            disc += 1 if s < 0 else 0
    tot = n * (n - 1) / 2
    return (conc - disc) / tot if tot else 0.0


def gt_tau(ev: Evaluator) -> float:
    human = [r for _, _, r in GROUND_TRUTH]
    scores = [ev.score(m) for _, m, _ in GROUND_TRUTH]
    order = sorted(range(len(scores)), key=lambda i: -scores[i])
    ev_rank = [0] * len(scores)
    for pos, i in enumerate(order):
        ev_rank[i] = pos + 1
    return kendall_tau(ev_rank, human)


@dataclass
class Scoreboard:
    """S5 selective erasure: scores keyed by evaluator hash; after a
    replacement the old hash is marked stale and excluded from comparisons
    (raw entries kept for audit)."""
    entries: list = field(default_factory=list)
    stale_hashes: set = field(default_factory=set)

    def record(self, eval_hash: str, subject: str, score: float, epoch: int) -> None:
        self.entries.append({"eval_hash": eval_hash, "subject": subject,
                             "score": score, "epoch": epoch})

    def comparable(self, eval_hash: str) -> list:
        if eval_hash in self.stale_hashes:
            return []
        return [e for e in self.entries if e["eval_hash"] == eval_hash]

    def mark_stale(self, eval_hash: str) -> int:
        self.stale_hashes.add(eval_hash)
        return sum(1 for e in self.entries if e["eval_hash"] == eval_hash)


class EvaluatorEvolution:
    def __init__(self, gov: Governance, board: Scoreboard, audit: EventLog):
        self.gov = gov
        self.board = board
        self.audit = audit

    def attempt(self, incumbent: Evaluator, candidate: Evaluator,
                actor: str = "meta.evaluator") -> tuple:
        """Candidate must beat incumbent on the human-curated ground truth,
        then pass a human-approved POLICY ticket, before replacement."""
        t_inc, t_cand = gt_tau(incumbent), gt_tau(candidate)
        beat = t_cand > t_inc
        ticket = self.gov.request(Priv.POLICY,
                                  f"evaluator replacement (tau {t_inc:.3f} -> {t_cand:.3f})",
                                  {"beat_ground_truth": beat,
                                   "params": candidate.params}, actor)
        self.audit.append("evaluator.candidate",
                          {"tau_incumbent": t_inc, "tau_candidate": t_cand,
                           "beat": beat, "ticket": ticket.tid}, actor)
        return beat, ticket, (t_inc, t_cand)

    def replace(self, incumbent: Evaluator, candidate: Evaluator, ticket) -> Evaluator:
        if ticket.payload.get("beat_ground_truth") is not True:
            raise FrozenEvaluatorError("candidate did not beat incumbent on ground truth")
        self.gov.mark_applied(ticket)
        erased = self.board.mark_stale(incumbent.hash)
        candidate.freeze()
        self.audit.append("evaluator.replaced",
                          {"old": incumbent.hash, "new": candidate.hash,
                           "scores_erased": erased}, "governance")
        return candidate


# ---------------------------------------------------------------------------
# S9 live metrics from the running constellation
# ---------------------------------------------------------------------------

def live_metrics(broker, exg, pages, oracle_to_date: float) -> dict:
    curve = broker.curve
    rets = [(b - a) / a for a, b in zip(curve, curve[1:]) if a > 0]
    sd = st.pstdev(rets) if len(rets) > 2 else 0.0
    sharpe = (st.fmean(rets) / sd * math.sqrt(365 * 3)) if sd > 1e-12 else 0.0
    closed = broker.closed
    n = len(closed)
    fund = sum(p.funding_pnl for p in closed) + \
        sum(p.funding_pnl for p in broker.positions.values())
    fp = sum(1 for p in closed if p.extreme_entry and p.hold <= 3 and p.net < 0)
    return {"pnl": broker.equity - broker.equity0,
            "sharpe": sharpe, "max_dd": broker.max_dd(),
            "capture_eff": max(0.0, fund / oracle_to_date) if oracle_to_date > 0 else 0.0,
            "fp_rate": (fp / n) if n else 0.0, "n_ops": n,
            "win_rate": (sum(1 for p in closed if p.net > 0) / n) if n else 0.0,
            "funding_pnl": fund,
            "wiki_freshness": pages.freshness_cache if hasattr(pages, "freshness_cache") else None,
            "principles": len(exg.principles)}
