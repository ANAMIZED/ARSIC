"""Sentinel tests. The integration test is the independence proof: the
ARSIC process is SIGSTOPped mid-mandate and the sentinel — a separate
process-in-spirit here, sharing nothing with the runtime — flattens the
venue with its own cancel-scope credentials while ARSIC is frozen. On
SIGCONT, ARSIC's reconciliation detects the out-of-band flatten, trips the
breaker, and revokes the mandate."""
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import unittest
import urllib.request

from arsic.execution_l3 import ACK_1, ACK_2
from arsic.sentinel import Sentinel
from arsic.venue_client import VenueClient
from arsic.venue_sim import serve_venue

API = 8917
VEN = 8918
KEYS = {"trader-key": {"secret": "trader-sec", "scope": "trade"},
        "sentinel-key": {"secret": "sentinel-sec", "scope": "cancel"}}


def call(path, body=None, timeout=8):
    req = urllib.request.Request(
        f"http://127.0.0.1:{API}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Content-Type": "application/json"},
        method="POST" if body is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:      # noqa: F821
        return json.loads(e.read().decode())


class TestSentinelUnits(unittest.TestCase):
    def _stub(self, snaps):
        st = Sentinel("http://x", "http://y", "k", "s",
                      deadman_s=0.2, max_gross=1e5, loss_cap=5e4)
        st.trips, st.flats = [], []
        it = iter(snaps)

        def fake_api(path, body=None, timeout=1.0):
            if path == "/api/state":
                return next(it)
            if path == "/api/killswitch/trip":
                st.trips.append(body)
                return {"frozen": True}
            return {"ok": True}
        st._api = fake_api
        st._ping = lambda *a, **k: None
        st._flatten = lambda reason: (st.flats.append(reason)
                                      or f"venue_cancel_all:{reason}")
        return st

    def _snap(self, seq, gross=0, equity=1e6, day=1, active=True):
        return {"cursor": seq,
                "snapshot": {"day": day, "equity": equity, "frozen": False,
                             "l3": {"active": active,
                                    "used": {"gross": gross}}}}

    def test_1_breach_escalates_trip_then_flatten(self):
        st = self._stub([self._snap(1, gross=2e5),
                         self._snap(2, gross=2e5),
                         self._snap(3, gross=5e4)])
        r1 = st.check(now=100.0)
        self.assertEqual(r1["action"], "api_trip")
        self.assertEqual(len(st.trips), 1)
        r2 = st.check(now=100.5)
        self.assertTrue(r2["action"].startswith("venue_cancel_all"))
        self.assertEqual(st.flats, ["gross 200000 > 100000"])
        r3 = st.check(now=101.0)                  # back inside limits
        self.assertNotIn("action", r3)

    def test_2_stall_with_active_mandate_flattens(self):
        st = self._stub([self._snap(7, gross=3e4),
                         self._snap(7, gross=3e4),
                         self._snap(7, gross=3e4)])
        st.check(now=200.0)
        st.check(now=200.1)                       # seq frozen, inside window
        r = st.check(now=200.5)                   # past deadman_s=0.2
        self.assertTrue(str(r.get("action", "")).startswith(
            "venue_cancel_all:stall"))

    def test_3_day_loss_trigger(self):
        st = self._stub([self._snap(1, equity=1e6, day=3),
                         self._snap(2, equity=9.2e5, day=3),
                         self._snap(3, equity=9.2e5, day=3)])
        st.check(now=300.0)                       # day baseline
        r = st.check(now=300.1)
        self.assertEqual(r["action"], "api_trip")
        r2 = st.check(now=300.2)
        self.assertTrue(r2["action"].startswith("venue_cancel_all"))


class TestSentinelIndependence(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        shutil.rmtree("run_sent_t", ignore_errors=True)
        cls.sim, cls.vhttpd = serve_venue(KEYS, VEN, salt="shadow:sent")
        env = dict(os.environ,
                   ARSIC_VENUE_URL=f"http://127.0.0.1:{VEN}",
                   ARSIC_VENUE_KEY="trader-key",
                   ARSIC_VENUE_SECRET="trader-sec")
        cls.proc = subprocess.Popen(
            [sys.executable, "-m", "arsic", "serve", "--root", "run_sent_t",
             "--port", str(API), "--seed", "7"],
            cwd="/home/claude/arsic", env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(40):
            try:
                call("/api/health", timeout=1)
                break
            except Exception:                    # noqa: BLE001
                time.sleep(0.25)

    @classmethod
    def tearDownClass(cls):
        try:
            os.kill(cls.proc.pid, signal.SIGCONT)
        except ProcessLookupError:
            pass
        cls.proc.terminate()
        cls.proc.wait(timeout=5)
        cls.vhttpd.shutdown()
        shutil.rmtree("run_sent_t", ignore_errors=True)

    def test_flatten_while_arsic_is_frozen_then_reconcile_closes_loop(self):
        call("/api/seal", {})
        r = call("/api/l3/request", {
            "mode": "hotl", "route": "external", "ttl_days": 10,
            "heartbeat_every": 6, "max_notional_per_order": 5e5,
            "max_gross_notional": 1.5e6, "max_leverage": 3.0,
            "loss_cap": 3e5, "order_rate_per_day": 40,
            "venues": ["binance", "bybit", "hyperliquid", "xv"],
            "acks": [ACK_1, ACK_2]})
        call("/api/ticket/approve", {"tid": r["tid"]})
        call("/api/l3/activate", {"tid": r["tid"]})
        venue = VenueClient(f"http://127.0.0.1:{VEN}",
                            "sentinel-key", "sentinel-sec")
        for _ in range(4):
            call("/api/day", {})
            if venue.gross() > 0:
                break
        self.assertGreater(venue.gross(), 0, "venue holds live risk")

        os.kill(self.proc.pid, signal.SIGSTOP)   # ARSIC hard-frozen
        st = Sentinel(f"http://127.0.0.1:{API}",
                      f"http://127.0.0.1:{VEN}",
                      "sentinel-key", "sentinel-sec",
                      deadman_s=0.6, poll_s=0.1)
        st.check()                                # marks last progress
        acted = None
        t0 = time.time()
        while time.time() - t0 < 6:
            rec = st.check()
            if str(rec.get("action", "")).startswith("venue_cancel_all"):
                acted = rec
                break
            time.sleep(0.2)
        self.assertIsNotNone(acted, "sentinel flattened venue-side")
        self.assertEqual(venue.positions(), [],
                         "venue flat while ARSIC is still SIGSTOPped")
        self.assertTrue(st.acted and st.acted[-1]["closed"] >= 1)

        os.kill(self.proc.pid, signal.SIGCONT)   # ARSIC resumes
        time.sleep(0.3)
        call("/api/day", {})                     # reconciliation runs
        snap = call("/api/state")["snapshot"]
        self.assertEqual(snap["l3"]["status"], "revoked")
        self.assertEqual(snap["l3"]["revokeReason"], "reconcile_mismatch")
        kinds = {e["kind"] for e in call("/api/state")["events"]}
        self.assertIn("l3.reconcile_mismatch", kinds)
        st.check()                               # ping now lands
        snap = call("/api/state")["snapshot"]
        self.assertIsNotNone(snap.get("sentinel"))
        self.assertTrue(snap["sentinel"]["alive"])
        self.assertGreaterEqual(snap["sentinel"]["acted"], 1)
        self.assertTrue(call("/api/audit/verify")["ok"])


if __name__ == "__main__":
    unittest.main()
