import tempfile
import unittest
from pathlib import Path

from arsic.events import EventLog
from arsic.governance import (
    Governance, GoalContract, KillSwitch, ScopeRouter, Priv,
    ContractError, lint_against_contract,
)


def mk():
    d = tempfile.TemporaryDirectory()
    audit = EventLog(str(Path(d.name) / "audit.jsonl"))
    gov = Governance(secret="test-secret", audit=audit)
    return d, audit, gov


class TestContracts(unittest.TestCase):
    def test_sign_and_verify(self):
        d, _, gov = mk()
        try:
            c = gov.sign_contract(GoalContract(
                principal="agent.x", objective="o", constraints={}, scopes=("a",)))
            self.assertTrue(c.signature)
            self.assertTrue(gov.verify_contract(c))
            c.objective = "tampered"
            self.assertFalse(gov.verify_contract(c))
        finally:
            d.cleanup()


class TestTickets(unittest.TestCase):
    def test_below_policy_auto_approved(self):
        d, _, gov = mk()
        try:
            t = gov.request(Priv.SKILL, "skill change", {}, actor="a")
            self.assertTrue(gov.is_executable(t))
        finally:
            d.cleanup()

    def test_policy_requires_human_role(self):
        d, _, gov = mk()
        try:
            t = gov.request(Priv.POLICY, "policy change", {}, actor="a")
            self.assertFalse(gov.is_executable(t))
            with self.assertRaises(ContractError):
                gov.approve(t.tid, actor_role="agent")
            with self.assertRaises(ContractError):
                gov.mark_applied(t)
            gov.approve(t.tid, actor_role="human")
            self.assertTrue(gov.is_executable(t))
            gov.mark_applied(t)
            self.assertEqual(t.status, "applied")
        finally:
            d.cleanup()

    def test_reject_requires_human_role(self):
        d, _, gov = mk()
        try:
            t = gov.request(Priv.META, "meta", {}, actor="a")
            with self.assertRaises(ContractError):
                gov.reject(t.tid, actor_role="agent")
            gov.reject(t.tid, actor_role="human")
            self.assertEqual(t.status, "rejected")
        finally:
            d.cleanup()

    def test_frozen_blocks_apply(self):
        d, _, gov = mk()
        try:
            t = gov.request(Priv.POLICY, "p", {}, actor="a")
            gov.approve(t.tid, actor_role="human")
            gov.freeze("test", "unit")
            with self.assertRaises(ContractError):
                gov.mark_applied(t)
            gov.unfreeze(actor_role="human", analysis="drill complete")
            gov.mark_applied(t)
        finally:
            d.cleanup()


class TestFreeze(unittest.TestCase):
    def test_unfreeze_requires_human(self):
        d, _, gov = mk()
        try:
            gov.freeze("x", "unit")
            with self.assertRaises(ContractError):
                gov.unfreeze(actor_role="agent", analysis="nope")
            self.assertTrue(gov.frozen)
            gov.unfreeze(actor_role="human", analysis="ok")
            self.assertFalse(gov.frozen)
        finally:
            d.cleanup()

    def test_freeze_hook_fires(self):
        d, _, gov = mk()
        try:
            seen = []
            gov.on_freeze(lambda frozen, reason: seen.append((frozen, reason)))
            gov.freeze("why", "unit")
            gov.unfreeze(actor_role="human", analysis="a")
            self.assertEqual(seen[0], (True, "why"))
            self.assertEqual(seen[1][0], False)
        finally:
            d.cleanup()


class TestHumanToken(unittest.TestCase):
    def test_token_roundtrip_and_forgery(self):
        d, _, gov = mk()
        try:
            tok = gov.human_token("live:BTC")
            self.assertTrue(gov.check_human_token("live:BTC", tok))
            self.assertFalse(gov.check_human_token("live:ETH", tok))
            self.assertFalse(gov.check_human_token("live:BTC", "forged"))
        finally:
            d.cleanup()


class TestKillSwitch(unittest.TestCase):
    def test_funding_extreme_trips_freeze(self):
        d, _, gov = mk()
        try:
            ks = KillSwitch(gov)
            hits = ks.evaluate({"max_abs_funding": 0.02})
            self.assertIn("funding_extreme", hits)
            self.assertTrue(gov.frozen)
        finally:
            d.cleanup()

    def test_oi_spike_needs_divergence(self):
        d, _, gov = mk()
        try:
            ks = KillSwitch(gov)
            self.assertEqual(ks.evaluate({"oi_z": 5.0, "price_divergence": False}), [])
            hits = ks.evaluate({"oi_z": 5.0, "price_divergence": True})
            self.assertIn("oi_spike_price_divergence", hits)
        finally:
            d.cleanup()

    def test_evaluator_drop(self):
        d, _, gov = mk()
        try:
            gov.last_epoch_score = 1.0
            ks = KillSwitch(gov)
            self.assertEqual(ks.evaluate({"evaluator_score": 0.9}), [])
            hits = ks.evaluate({"evaluator_score": 0.5})
            self.assertIn("evaluator_score_drop", hits)
        finally:
            d.cleanup()


class TestScopeRouter(unittest.TestCase):
    def test_route_and_handoff(self):
        d, audit, gov = mk()
        try:
            r = ScopeRouter(audit)
            r.register("a.market", {"market"})
            self.assertTrue(r.check("a.market", {"market"}))
            self.assertFalse(r.check("a.market", {"meta"}))
            self.assertEqual(r.route("T1", {"market"}, {}), "a.market")
            self.assertIsNone(r.route("T2", {"nonexistent"}, {"why": "x"}))
            self.assertEqual(len(r.handoffs), 1)
            self.assertEqual(audit.count("router.handoff"), 1)
        finally:
            d.cleanup()


class TestLint(unittest.TestCase):
    def test_lint_violations(self):
        c = GoalContract(principal="sys", objective="o",
                         constraints={"max_leverage": 3.0, "max_drawdown": 0.10,
                                      "min_liq_score": 0.3, "paper_only": True},
                         scopes=("*",))
        self.assertEqual(lint_against_contract(
            {"max_leverage": 2.0, "dd_budget": 0.08, "min_liq_score": 0.3}, c), [])
        v = lint_against_contract(
            {"max_leverage": 5.0, "dd_budget": 0.2, "min_liq_score": 0.1}, c)
        self.assertEqual(len(v), 3)


if __name__ == "__main__":
    unittest.main()
