"""Backend server integration test (S-wire): boots the HTTP server in-process
and drives the full genesis arc over the JSON API, asserting the same
governance invariants the CLI demo proves."""
import json
import os
import shutil
import unittest
import urllib.request

from arsic.server import serve, TOTAL_DAYS
from arsic.execution_l3 import ACK_1, ACK_2

PORT = 8907
BASE = f"http://127.0.0.1:{PORT}"


def call(path, body=None):
    if body is None:
        with urllib.request.urlopen(BASE + path, timeout=30) as r:
            return json.load(r)
    req = urllib.request.Request(BASE + path,
                                 data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"},
                                 method="POST")
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.load(r)


class TestServerWiredArc(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        shutil.rmtree("run_srv_test", ignore_errors=True)
        cls.srv, cls.httpd = serve("run_srv_test", port=PORT, seed=7,
                                   html=None, block=False)

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        shutil.rmtree("run_srv_test", ignore_errors=True)

    def test_full_wired_arc(self):
        self.assertTrue(call("/api/health")["ok"])
        call("/api/reset", {"seed": 7})

        # -- L0: 30 paper days over the wire
        for _ in range(TOTAL_DAYS):
            call("/api/day", {})
        st = call("/api/state?since=0")
        snap, events = st["snapshot"], st["events"]
        self.assertEqual(snap["day"], TOTAL_DAYS)
        self.assertGreater(len(snap["dailyRows"]), 25)
        self.assertGreater(len(snap["pages"]), 20)
        self.assertGreater(len(snap["graph"]["nodes"]), 20)
        ids = {n["id"] for n in snap["graph"]["nodes"]}
        self.assertTrue(all(l["a"] in ids and l["b"] in ids
                            for l in snap["graph"]["links"]))
        self.assertTrue(any(e["kind"] == "wiki.rebuild" for e in events))
        self.assertEqual(snap["gateway"]["liveTrades"], 0)

        # -- frozen? clear via the human endpoint before governance steps
        if snap["frozen"]:
            call("/api/killswitch/reset",
                 {"analysis": "end-of-phase review over the wire"})

        # -- autonomy L1 via META ticket + human approval
        t = call("/api/autonomy", {"level": 1})["ticket"]
        call("/api/ticket/approve", {"tid": t["tid"]})
        snap = call("/api/state?since=0")["snapshot"]
        self.assertEqual(snap["autonomy"], 1)
        with self.assertRaises(urllib.error.HTTPError):
            call("/api/autonomy", {"level": 3})     # never grantable -> 400

        # -- seal + epoch (small held-out sweep keeps the test quick)
        h = call("/api/seal", {})["hash"]
        self.assertEqual(len(h), 16)
        ep = call("/api/epoch", {"preApprovePolicy": True,
                                 "seeds": [1, 2, 3, 4, 5, 6], "days": 6})
        kinds = {r["title"]: r for r in ep["reports"]}
        self.assertTrue(kinds["tighten extreme filter (+prompt directive)"]["promoted"])
        self.assertLess(kinds["tighten extreme filter (+prompt directive)"]["p"], 0.05)
        self.assertTrue(kinds["raise leverage to 5x"]["lint"])
        self.assertEqual(ep["promotedVersion"], 2)

        # -- L2 + adapter over the wire
        t = call("/api/autonomy", {"level": 2})["ticket"]
        call("/api/ticket/approve", {"tid": t["tid"]})
        fit = call("/api/adapter/fit", {})
        self.assertGreater(fit["nVerified"], 20)
        call("/api/ticket/approve", {"tid": fit["ticket"]["tid"]})
        ap = call("/api/adapter/apply", {"tid": fit["ticket"]["tid"]})
        self.assertEqual(ap["version"], 3)

        # -- evaluator co-evolution
        at = call("/api/evalco/attempt", {})
        self.assertTrue(at["beat"])
        self.assertAlmostEqual(at["taus"][0], 0.857, places=3)
        self.assertAlmostEqual(at["taus"][1], 0.929, places=3)
        call("/api/ticket/approve", {"tid": at["ticket"]["tid"]})
        rp = call("/api/evalco/replace", {"tid": at["ticket"]["tid"]})
        self.assertNotEqual(rp["hash"], h)

        # -- drill, human reset, live probe
        d = call("/api/killswitch/drill", {})
        self.assertIn("funding_extreme", d["hits"])
        self.assertTrue(d["frozen"])
        call("/api/killswitch/reset", {"analysis": "drill analyzed"})
        pr = call("/api/probe", {})
        self.assertTrue(pr["rejected"])
        self.assertEqual(pr["liveTrades"], 0)

        # -- compounding + audit + invariants
        cp = call("/api/compounding", {"seed": 8})
        self.assertGreater(cp["gapClosed"], 0)
        self.assertEqual(cp["version"], 3)
        av = call("/api/audit/verify")
        self.assertTrue(av["ok"])
        self.assertGreater(av["count"], 800)
        snap = call("/api/state?since=0")["snapshot"]
        self.assertTrue(snap["policyPlusAllHuman"])
        self.assertTrue(snap["evaluator"]["frozen"])
        tail = call("/api/audit/tail?n=5")
        self.assertEqual(len(tail), 5)

    def test_reject_and_arbiter_and_errors(self):
        call("/api/reset", {"seed": 11})
        call("/api/day", {})
        t = call("/api/autonomy", {"level": 1})["ticket"]
        r = call("/api/ticket/reject", {"tid": t["tid"]})
        self.assertEqual(r["status"], "rejected")
        with self.assertRaises(urllib.error.HTTPError):
            call("/api/killswitch/reset", {"analysis": ""})  # 400 needs analysis


    def test_z_autonomy_extends_world_over_the_wire(self):
        """After the 30-day arc: /api/auto/tick keeps going — governed
        research fires and the synthetic world extends past the horizon."""
        call("/api/reset", {"seed": 7})
        saw_research, advanced, tries = False, 0, 0
        while advanced < TOTAL_DAYS + 3 and tries < TOTAL_DAYS + 15:
            tries += 1
            r = call("/api/auto/tick",
                     {"research_every": 6, "epoch_every": 100})
            if r.get("halted"):
                call("/api/killswitch/reset",
                     {"analysis": f"autonomy ops review: {r['reason']}"})
                continue
            advanced += 1
            if r.get("research"):
                saw_research = True
        last = call("/api/state")
        snap, events = last["snapshot"], last["events"]
        self.assertEqual(snap["day"], TOTAL_DAYS + 3)
        self.assertGreater(snap["day"], TOTAL_DAYS)
        self.assertTrue(saw_research)
        self.assertTrue(call("/api/audit/verify")["ok"])
        kinds = {e["kind"] for e in events}
        self.assertIn("world.extended", kinds)


    def test_zz_l3_mandate_over_the_wire(self):
        """Wired HOTL ceremony: request → human key → activate → shadow day
        → intervene (flatten) → revoke; audit intact; L3 ladder still sealed."""
        call("/api/reset", {"seed": 7})
        for _ in range(2):
            call("/api/day", {})
        call("/api/seal", {})
        with self.assertRaises(urllib.error.HTTPError):
            call("/api/autonomy", {"level": 3})         # ladder sealed
        acks = call("/api/state")["snapshot"]["l3Acks"]
        r = call("/api/l3/request",
                 {"mode": "hotl", "ttl_days": 5, "heartbeat_every": 3,
                  "max_notional_per_order": 1.5e5,
                  "max_gross_notional": 6e5, "max_leverage": 2.5,
                  "loss_cap": 5e4, "order_rate_per_day": 12, "acks": acks})
        call("/api/ticket/approve", {"tid": r["tid"]})
        act = call("/api/l3/activate", {"tid": r["tid"]})
        self.assertTrue(act["mid"].startswith("M"))
        call("/api/l3/heartbeat", {})
        for _ in range(2):
            try:
                call("/api/day", {})
            except urllib.error.HTTPError:
                call("/api/killswitch/reset", {"analysis": "l3 test review"})
        snap = call("/api/state")["snapshot"]
        self.assertIn("l3", snap)
        self.assertEqual(snap["l3"]["mode"], "hotl")
        self.assertGreaterEqual(snap["l3"]["counters"]["fills"], 0)
        call("/api/l3/flatten", {})
        call("/api/l3/revoke", {})
        snap2 = call("/api/state")["snapshot"]["l3"]
        self.assertFalse(snap2["active"])
        self.assertEqual(snap2["revokeReason"], "human_revoked")
        self.assertTrue(call("/api/audit/verify")["ok"])
        kinds = {e["kind"] for e in call("/api/state")["events"]}
        self.assertTrue({"l3.mandate_activated", "l3.demoted"} <= kinds)


    def test_zz_l3_mandate_over_the_wire(self):
        """S11 over raw HTTP: dual-ack request → operator approve →
        risk-officer activate → shadow-live days → human revoke."""
        call("/api/reset", {"seed": 7})
        call("/api/seal", {})
        r = call("/api/l3/request", {
            "mode": "hotl", "ttl_days": 5, "heartbeat_every": 3,
            "max_notional_per_order": 5e5, "max_gross_notional": 1e6,
            "max_leverage": 3.0, "loss_cap": 1e5, "order_rate_per_day": 30,
            "venues": ["binance", "bybit", "hyperliquid", "xv"],
            "acks": [ACK_1, ACK_2]})
        tid = r["tid"]
        call("/api/ticket/approve", {"tid": tid})
        m = call("/api/l3/activate", {"tid": tid})
        self.assertEqual(m["mode"], "hotl")
        snap = call("/api/state")["snapshot"]
        self.assertTrue(snap["l3"]["active"])
        call("/api/day", {})
        call("/api/day", {})
        self.assertEqual(call("/api/l3/heartbeat", {})["ok"], True)
        snap = call("/api/state")["snapshot"]
        self.assertIn("counters", snap["l3"])
        self.assertGreaterEqual(snap["l3"]["counters"]["fills"], 0)
        call("/api/l3/revoke", {})
        snap = call("/api/state")["snapshot"]
        self.assertEqual(snap["l3"]["status"], "revoked")
        self.assertTrue(call("/api/audit/verify")["ok"])


if __name__ == "__main__":
    unittest.main()
