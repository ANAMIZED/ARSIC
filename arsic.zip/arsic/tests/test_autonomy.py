"""S10 autonomy loop tests: the constellation gathers information and
self-improves inside the governance envelope."""
import shutil
import unittest
from types import SimpleNamespace

from arsic import autonomy
from arsic.bootstrap import build_system
from arsic.cycle import DailyCycle
from arsic.events import EventLog
from arsic.governance import Priv, lint_against_contract
from arsic.perception import SyntheticMarket

SCHED = [("trend", 8), ("range", 7), ("high_vol", 8), ("post_squeeze", 7)]


def _reset_if_frozen(state, note="test ops review"):
    if state.governance.frozen:
        state.audit.append("human.ops_review", {"phase": note}, "human:test")
        state.governance.unfreeze(actor_role="human", analysis=note,
                                  actor="human:test")


class TestAutonomy(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        shutil.rmtree("run_auto_t", ignore_errors=True)
        cls.state = build_system(5, SCHED, "run_auto_t")
        cls.cycle = DailyCycle(cls.state)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree("run_auto_t", ignore_errors=True)

    def test_1_extension_keeps_prefix_and_wraps_regimes(self):
        drv = SyntheticMarket(seed=9, schedule=[("trend", 2), ("range", 2)])
        fake = SimpleNamespace(driver=drv,
                               audit=EventLog("run_auto_t/ext_audit.jsonl"))
        before = repr(drv.ticks_at(1, 0))
        self.assertTrue(autonomy.ensure_days(fake, 9))
        self.assertGreaterEqual(drv.total_days, 10)
        self.assertEqual(repr(drv.ticks_at(1, 0)), before)
        self.assertEqual(drv.regime_of(4), "trend")
        self.assertEqual(drv.regime_of(6), "range")
        self.assertEqual(len(drv.ticks_at(8, 1)), len(drv.ticks_at(1, 1)))

    def test_2_research_pass_targets_gaps_and_audits(self):
        s, c = self.state, self.cycle
        for d in range(6):
            _reset_if_frozen(s)
            c.run_day(d)
        _reset_if_frozen(s)
        # age one market page so the scanner flags it stale
        name = next(n for n in s.pages.pages if n.startswith("market:"))
        s.pages.pages[name]["ts"] -= 86400
        gaps = autonomy.scan_gaps(s, 6)
        self.assertIn(name, gaps["stale"])
        r = autonomy.research_pass(s, c, 6)
        self.assertNotIn("skipped", r)
        self.assertIn(name[7:], r["targets"])
        self.assertGreaterEqual(r["acts"]["reingest"], 1)
        self.assertTrue(any(e.kind == "auto.research"
                            for e in s.audit.tail(30)))
        self.assertIsInstance(r["freshness"], float)

    def test_3_mined_candidates_are_addressable_and_lintable(self):
        s, c = self.state, self.cycle
        for d in range(6, 11):
            _reset_if_frozen(s)
            c.run_day(d)
        _reset_if_frozen(s)
        live = autonomy.mine_candidates(s, 11)      # live path: shape only
        self.assertIn("cands", live)
        self.assertIn("evidence", live)
        crafted = autonomy.mine_rules(
            dict(s.harness.strategy), {}, 
            {"capture_eff": 0.2, "fp_rate": 0.0, "max_dd": 0.06},
            fp_ext=0.4, ext_len=9, hot=["binance:BTC-USDT-PERP"],
            ev=lambda keys: ["cid-demo"])
        titles = [c[0] for c in crafted["cands"]]
        self.assertEqual(len(crafted["cands"]), 4)
        self.assertTrue(any("tighten extreme" in t for t in titles))
        self.assertTrue(any("cross-venue" in t for t in titles))
        for title, _lv, diff in crafted["cands"]:
            s.harness.apply_diff(diff)          # every diff addressable
            self.assertIn(title, crafted["evidence"])
        lev = next(cd for cd in crafted["cands"] if "leverage" in cd[0])
        cand = s.harness.apply_diff(lev[2])
        self.assertTrue(lint_against_contract(cand.strategy,
                                              s.system_contract))

    def test_4_tick_arc_skill_auto_policy_gated_breaker_halts(self):
        s, c = self.state, self.cycle
        cfg = {"research_every": 4, "epoch_every": 6, "seeds": [1, 2, 3],
               "days": 4, "epochs": 0}
        day, epochs, resets = 11, 0, 0
        while day < 18 and resets < 10:
            day, r = autonomy.auto_tick(s, c, day, cfg)
            if r.get("halted"):
                resets += 1
                _reset_if_frozen(s, "autonomy ops review")
                continue
            if r.get("epoch"):
                epochs += 1
                for rep in r["epoch"]["reports"]:
                    if rep["promoted"]:
                        self.assertLess(rep["level"], int(Priv.POLICY))
        self.assertEqual(day, 18)
        self.assertGreaterEqual(epochs, 1)
        pol = [t for t in s.governance.tickets.values()
               if t.status == "pending" and t.level >= int(Priv.POLICY)]
        self.assertTrue(pol)                     # a human key is waiting
        ok, _ = s.audit.verify()
        self.assertTrue(ok)
        s.killswitch.human_trip("test halt")
        d2, r = autonomy.auto_tick(s, c, day, cfg)
        self.assertEqual(r.get("halted"), "frozen")
        self.assertEqual(d2, day)
        _reset_if_frozen(s, "post-halt")

    def test_5_standing_human_approval_transfers(self):
        s = self.state
        gov = s.governance
        prior = gov.request(Priv.POLICY, "promote: transfer-demo", {}, "t")
        gov.approve(prior.tid, actor_role="human", actor="human:test")
        fresh = gov.request(Priv.POLICY, "promote: transfer-demo", {}, "t")
        self.assertTrue(autonomy.transfer_approval(s, gov, fresh))
        self.assertEqual(fresh.status, "approved")
        self.assertTrue(any(e.kind == "auto.approval_transfer"
                            for e in s.audit.tail(5)))
        stranger = gov.request(Priv.POLICY, "promote: other", {}, "t")
        self.assertFalse(autonomy.transfer_approval(s, gov, stranger))


if __name__ == "__main__":
    unittest.main()
