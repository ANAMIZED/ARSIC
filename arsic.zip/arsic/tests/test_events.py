import json
import tempfile
import unittest
from pathlib import Path

from arsic.events import EventLog, ObjectStore, ExperimentTracker, sha, GENESIS


class TestEventLog(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = str(Path(self.dir.name) / "audit.jsonl")
        self.log = EventLog(self.path)

    def tearDown(self):
        self.dir.cleanup()

    def test_chain_links(self):
        self.log.append("a.b", {"x": 1}, actor="t")
        self.log.append("a.c", {"y": 2}, actor="t")
        ok, bad = self.log.verify()
        self.assertTrue(ok)
        self.assertIsNone(bad)
        rows = [json.loads(l) for l in Path(self.path).read_text().splitlines()]
        self.assertEqual(rows[0]["prev"], GENESIS)
        self.assertEqual(rows[1]["prev"], rows[0]["hash"])

    def test_tamper_detection(self):
        for i in range(5):
            self.log.append("k", {"i": i}, actor="t")
        rows = Path(self.path).read_text().splitlines()
        row = json.loads(rows[3])
        row["payload"]["i"] = 999  # tamper without re-hashing
        rows[3] = json.dumps(row)
        Path(self.path).write_text("\n".join(rows) + "\n")
        ok, bad = EventLog(self.path).verify()
        self.assertFalse(ok)
        self.assertEqual(bad, 3)

    def test_reload_continues_chain(self):
        self.log.append("k", {"i": 0}, actor="t")
        log2 = EventLog(self.path)
        log2.append("k", {"i": 1}, actor="t")
        ok, _ = log2.verify()
        self.assertTrue(ok)
        self.assertEqual(log2.count(), 2)


class TestObjectStore(unittest.TestCase):
    def test_content_addressing(self):
        with tempfile.TemporaryDirectory() as d:
            store = ObjectStore(d)
            h1 = store.put({"a": 1})
            h2 = store.put({"a": 1})
            self.assertEqual(h1, h2)
            self.assertEqual(h1, sha({"a": 1}))
            self.assertEqual(store.get(h1), {"a": 1})
            self.assertTrue(store.has(h1))


class TestTracker(unittest.TestCase):
    def test_log_runs(self):
        with tempfile.TemporaryDirectory() as d:
            tr = ExperimentTracker(str(Path(d) / "exp.jsonl"))
            tr.log({"run": "r1", "metric": 1.0})
            tr.log({"run": "r1", "metric": 2.0})
            rows = tr.runs()
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[1]["metric"], 2.0)


if __name__ == "__main__":
    unittest.main()
