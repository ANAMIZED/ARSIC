import tempfile
import unittest
from pathlib import Path

from arsic.events import EventLog, ObjectStore
from arsic.wiki import TemporalKG, WikiPages, Claim, Provenance

T = 1_700_000_000.0


def mk():
    d = tempfile.TemporaryDirectory()
    audit = EventLog(str(Path(d.name) / "a.jsonl"))
    store = ObjectStore(str(Path(d.name) / "obj"))
    kg = TemporalKG(audit, store)
    return d, audit, kg


def claim(subj="market:binance:BTC-USDT-PERP", pred="funding_rate_at", val=0.0004,
          ts=T, conf=0.9, src="binance_api", ttl=None, relation=False):
    return Claim(subject=subj, predicate=pred, value=val, ts=ts, confidence=conf,
                 prov=Provenance(source_id=src, source_hash="h1"), ttl=ttl,
                 relation=relation)


class TestPatchOutcomes(unittest.TestCase):
    def test_insert_then_merge(self):
        d, _, kg = mk()
        try:
            p = kg.new_patch([claim()], "perc.market", "perception.market")
            self.assertEqual(kg.apply(p, now=T)[0][1], "insert")
            p2 = kg.new_patch([claim(val=0.00042, ts=T + 8 * 3600)],
                              "perc.market", "perception.market")
            self.assertEqual(kg.apply(p2, now=T)[0][1], "merge")
            self.assertEqual(len(kg.history("market:binance:BTC-USDT-PERP",
                                            "funding_rate_at")), 2)
        finally:
            d.cleanup()

    def test_relate(self):
        d, _, kg = mk()
        try:
            c = claim(subj="analysis:x", pred="about",
                      val="market:binance:BTC-USDT-PERP", relation=True)
            p = kg.new_patch([c], "res.a", "research.analysis")
            self.assertEqual(kg.apply(p, now=T)[0][1], "relate")
            self.assertIn("market:binance:BTC-USDT-PERP", kg.entities)
        finally:
            d.cleanup()

    def test_conflict_keeps_canonical_and_queues(self):
        d, audit, kg = mk()
        try:
            kg.apply(kg.new_patch([claim(val=0.0010, src="binance_api")],
                                  "perc.market", "perception.market"), now=T)
            # different source, same window, >25% divergence, both conf>=0.6
            r = kg.apply(kg.new_patch([claim(val=0.0020, ts=T + 60, src="other_api")],
                                      "perc.market", "perception.market"), now=T)
            self.assertEqual(r[0][1], "conflict")
            self.assertEqual(len(kg.arbiter_queue), 1)
            # canonical untouched
            self.assertEqual(kg.latest("market:binance:BTC-USDT-PERP",
                                       "funding_rate_at")["value"], 0.0010)
            self.assertEqual(audit.count("wiki.conflict"), 1)
        finally:
            d.cleanup()

    def test_conflict_resolution_requires_role(self):
        d, _, kg = mk()
        try:
            kg.apply(kg.new_patch([claim(val=0.0010)], "p", "perception.market"), now=T)
            kg.apply(kg.new_patch([claim(val=0.0020, ts=T + 60, src="other")],
                                  "p", "perception.market"), now=T)
            with self.assertRaises(PermissionError):
                kg.resolve_conflict(0, pick="challenger", actor_role="agent")
            kg.resolve_conflict(0, pick="challenger", actor_role="human")
            self.assertEqual(len(kg.arbiter_queue), 0)
            self.assertEqual(kg.latest("market:binance:BTC-USDT-PERP",
                                       "funding_rate_at")["value"], 0.0020)
        finally:
            d.cleanup()

    def test_rejects(self):
        d, _, kg = mk()
        try:
            # wrong scope for market: prefix
            r = kg.apply(kg.new_patch([claim()], "x", "research.analysis"), now=T)
            self.assertEqual(r[0][1], "reject")
            # bad confidence
            r = kg.apply(kg.new_patch([claim(conf=1.5)], "x", "perception.market"), now=T)
            self.assertEqual(r[0][1], "reject")
            # unknown prefix
            r = kg.apply(kg.new_patch([claim(subj="mystery:z")], "x",
                                      "perception.market"), now=T)
            self.assertEqual(r[0][1], "reject")
        finally:
            d.cleanup()


class TestInvalidation(unittest.TestCase):
    def test_ttl_sweep_and_latest_validity(self):
        d, _, kg = mk()
        try:
            kg.apply(kg.new_patch([claim(pred="volume_24h", val=5e8, ttl=2 * 86400)],
                                  "p", "perception.market"), now=T)
            self.assertIsNotNone(kg.latest("market:binance:BTC-USDT-PERP",
                                           "volume_24h", at=T + 86400))
            self.assertIsNone(kg.latest("market:binance:BTC-USDT-PERP",
                                        "volume_24h", at=T + 3 * 86400))
            n = kg.sweep_invalidation(now=T + 3 * 86400)
            self.assertGreaterEqual(n, 1)
        finally:
            d.cleanup()


class TestPages(unittest.TestCase):
    def test_compile_surgical_search_trace(self):
        d, _, kg = mk()
        try:
            pages = WikiPages(kg, kg.audit)
            kg.apply(kg.new_patch([claim()], "p", "perception.market"), now=T)
            kg.apply(kg.new_patch([claim(subj="market:bybit:BTC-USDT-PERP",
                                         val=0.0005)], "p", "perception.market"), now=T)
            n = pages.compile_all(now=T)
            self.assertEqual(n, 2)
            h_bybit_before = pages.pages["market:bybit:BTC-USDT-PERP"]["hash"]
            # surgical update touches only target page
            kg.apply(kg.new_patch([claim(val=0.0006, ts=T + 8 * 3600)],
                                  "p", "perception.market"), now=T)
            pages.surgical("market:binance:BTC-USDT-PERP", now=T + 8 * 3600)
            self.assertEqual(pages.pages["market:bybit:BTC-USDT-PERP"]["hash"],
                             h_bybit_before)
            # search finds page
            hits = pages.search("binance funding")
            self.assertTrue(any("binance" in h for h in hits))
            # trace claim -> provenance
            cid = kg.latest("market:binance:BTC-USDT-PERP",
                            "funding_rate_at")["cid"]
            tr = pages.trace(cid)
            self.assertIsNotNone(tr)
            self.assertIn("prov", tr)
            self.assertIn("src_key", tr)
        finally:
            d.cleanup()

    def test_seed_and_freshness(self):
        d, _, kg = mk()
        try:
            pages = WikiPages(kg, kg.audit)
            pages.seed("seed:test", "# Seed page")
            kg.apply(kg.new_patch([claim(ts=T)], "p", "perception.market"), now=T)
            pages.compile_all(now=T)
            self.assertGreater(pages.freshness(now=T + 3600), 0.0)
        finally:
            d.cleanup()


if __name__ == "__main__":
    unittest.main()
