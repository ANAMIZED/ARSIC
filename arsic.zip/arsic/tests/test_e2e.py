import tempfile
import unittest
from pathlib import Path

from arsic.bootstrap import build_system
from arsic.cycle import DailyCycle
from arsic import dashboard
from arsic.trading import LiveTradeRejected


SCHEDULE = [("trend", 3), ("high_vol", 3)]


class TestEndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dir = tempfile.TemporaryDirectory()
        cls.state = build_system(seed=7, schedule=SCHEDULE, root=cls.dir.name)
        cls.summary = DailyCycle(cls.state).run(days=6)

    @classmethod
    def tearDownClass(cls):
        cls.dir.cleanup()

    def test_audit_chain_intact(self):
        ok, bad = self.state.audit.verify()
        self.assertTrue(ok, f"audit chain broken at seq {bad}")
        self.assertGreater(self.state.audit.count(), 100)

    def test_zero_live_trades(self):
        self.assertEqual(self.state.trading.gateway.live_trades, 0)

    def test_live_probe_rejected(self):
        gw = self.state.trading.gateway
        before = gw.live_rejections
        t = next(t for t in self.state.driver.ticks_at(0, 0)
                 if t.venue == "binance" and t.symbol == "BTC-USDT-PERP")
        with self.assertRaises(LiveTradeRejected):
            gw.submit("binance:BTC-USDT-PERP", +1, 1e5, 2.0, t, {}, False,
                      live=True, human_token="forged")
        self.assertEqual(gw.live_trades, 0)
        self.assertEqual(gw.live_rejections, before + 1)

    def test_wiki_populated_and_fresh(self):
        self.assertGreater(len(self.state.pages.pages), 10)
        self.assertGreater(self.state.daily_rows[-1]["freshness"], 0.0)

    def test_trajectories_written(self):
        self.assertGreater(len(self.state.exg.traj), 0)

    def test_daily_rows_complete(self):
        self.assertEqual(len(self.state.daily_rows), 6)
        for r in self.state.daily_rows:
            for k in ("day", "regime", "equity", "score", "fp_rate",
                      "capture_eff", "max_dd", "freshness"):
                self.assertIn(k, r)

    def test_deterministic_repeat(self):
        with tempfile.TemporaryDirectory() as d2:
            s2 = build_system(seed=7, schedule=SCHEDULE, root=d2)
            DailyCycle(s2).run(days=6)
            a = [(r["day"], round(r["equity"], 6), r["closed_total"])
                 for r in self.state.daily_rows]
            b = [(r["day"], round(r["equity"], 6), r["closed_total"])
                 for r in s2.daily_rows]
            self.assertEqual(a, b)

    def test_out_of_scope_task_handoff(self):
        sched = self.state.scheduler
        if self.state.governance.frozen:   # final-day organic trip, if any
            self.state.governance.unfreeze(actor_role="human", analysis="test")
        before = len(self.state.router.handoffs)
        t = sched.new_task("meta-thing", {"scope-that-nobody-has"}, {})
        r = sched.dispatch("perc.market", t)
        self.assertIsNone(r)
        self.assertEqual(len(self.state.router.handoffs), before + 1)

    def test_dashboard_renders(self):
        out = Path(self.dir.name) / "dash.html"
        d = {
            "state": self.state, "daily_rows": self.state.daily_rows,
            "promotions": [], "compounding": {}, "invariants": {},
            "killswitch_events": [], "taus": {},
        }
        dashboard.render(d, str(out))
        html = out.read_text()
        self.assertGreater(len(html), 2000)
        self.assertIn("ARSIC", html)


if __name__ == "__main__":
    unittest.main()
