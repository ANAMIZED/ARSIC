"""S11 L3 execution plane tests: the ladder never grants L3; a human mandate
lends it — scoped, time-boxed, dead-man-guarded, breaker-revoked — with the
risk gate binding below the agents and every decision audited."""
import shutil
import unittest

from arsic.bootstrap import advance_autonomy, build_system
from arsic.cycle import DailyCycle
from arsic.execution_l3 import (ACK_1, ACK_2, L3Session, LiveAdapter,
                                NotArmed, QueuedForApproval)
from arsic.governance import ContractError
from arsic.trading import LiveTradeRejected

SCHED = [("trend", 8), ("range", 7), ("high_vol", 8), ("post_squeeze", 7)]


def _reset_if_frozen(state):
    if state.governance.frozen:
        state.audit.append("human.ops_review", {"phase": "test"}, "human:test")
        state.governance.unfreeze(actor_role="human", analysis="test review",
                                  actor="human:test")


def _mandate(state, ses, day, mode="hotl", **caps):
    params = {"mode": mode, "acks": [ACK_1, ACK_2],
              "ttl_days": 6, "heartbeat_every": 3,
              "max_notional_per_order": 1.5e5, "max_gross_notional": 6e5,
              "max_leverage": 2.5, "loss_cap": 5e4, "order_rate_per_day": 12}
    params.update(caps)
    t, _ = ses.request_mandate(params, actor="human:test")
    state.governance.approve(t.tid, actor_role="human", actor="human:test")
    return ses.activate(t.tid, day, actor="human:test")


class TestL3(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        shutil.rmtree("run_l3_t", ignore_errors=True)
        cls.state = build_system(11, SCHED, "run_l3_t")
        cls.cycle = DailyCycle(cls.state)
        cls.day = 0
        for d in range(3):
            _reset_if_frozen(cls.state)
            cls.cycle.run_day(d)
            cls.day = d + 1
        _reset_if_frozen(cls.state)
        cls.ses = L3Session(cls.state, cls.state.trading.gateway)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree("run_l3_t", ignore_errors=True)

    def _tick(self, day=None):
        d = min(self.__class__.day if day is None else day,
                self.state.driver.total_days - 1)
        return next(t for t in self.state.driver.ticks_at(d, 0))

    def test_1_ladder_never_grants_l3_and_live_adapter_refuses(self):
        with self.assertRaises(ContractError):
            advance_autonomy(self.state, 3)
        self.assertLessEqual(self.state.governance.autonomy_level, 2)
        with self.assertRaises(NotArmed):
            LiveAdapter()

    def test_2_ceremony_requires_acks_seal_and_human_key(self):
        s, ses = self.state, self.ses
        with self.assertRaises(LiveTradeRejected):
            ses.request_mandate({"mode": "hotl", "acks": [ACK_1]})
        t, _ = ses.request_mandate({"mode": "hotl", "acks": [ACK_1, ACK_2]},
                                   actor="human:test")
        with self.assertRaises(LiveTradeRejected):
            ses.activate(t.tid, self.__class__.day)        # not approved
        with self.assertRaises(ContractError):
            s.governance.approve(t.tid, actor_role="auto", actor="auto")
        s.governance.approve(t.tid, actor_role="human", actor="human:test")
        self.assertFalse(s.evaluator.frozen)
        with self.assertRaises(LiveTradeRejected):
            ses.activate(t.tid, self.__class__.day)        # unsealed evaluator
        s.evaluator.freeze()
        m = ses.activate(t.tid, self.__class__.day, actor="human:test")
        self.assertTrue(ses.active(self.__class__.day))
        self.assertEqual(m.mode, "hotl")
        ses.revoke(self.__class__.day, actor="human:test")
        self.assertFalse(ses.active(self.__class__.day))

    def test_3_hotl_shadow_fill_and_gate_caps(self):
        s, ses = self.state, self.ses
        _mandate(s, ses, self.__class__.day)
        tick = self._tick()
        key = tick.key()
        s.trading.broker.positions.pop(key, None)
        p = s.trading.gateway.submit(key, 1, 3e4, 2.0, tick, {}, False)
        self.assertIsNotNone(p)                            # shadow fill landed
        self.assertTrue(any(e.kind == "l3.fill"
                            for e in s.audit.tail(12)))
        fills0, gated0 = ses.fills, ses.gated
        for n, lv, tag in [(9e5, 2.0, "notional_per_order"),
                           (1e4, 3.4, "leverage")]:
            with self.assertRaises(LiveTradeRejected):
                s.trading.gateway.submit(f"bybit:ETH-USDT-PERP", 1, n, lv,
                                         tick, {}, False)
        self.assertEqual(ses.gated, gated0 + 2)
        self.assertEqual(ses.fills, fills0)
        why = [e.payload["why"] for e in s.audit.tail(20)
               if e.kind == "l3.gated"]
        self.assertTrue(any("notional_per_order" in w for w in why))
        self.assertTrue(any("leverage" in w for w in why))

    def test_4_forged_token_rejected_even_under_mandate(self):
        s, ses = self.state, self.ses
        self.assertTrue(ses.active(self.__class__.day))
        tick = self._tick()
        with self.assertRaises(LiveTradeRejected):
            s.trading.gateway.submit("hyperliquid:BTC-USD-PERP", 1, 1e4, 2.0,
                                     tick, {}, False, live=True,
                                     human_token="forged")
        self.assertTrue(any(e.kind == "l3.gated" and
                            "forged_token" in e.payload["why"]
                            for e in s.audit.tail(8)))
        ses.revoke(self.__class__.day, actor="human:test")

    def test_5_hitl_fresh_fill_requote_expiry_and_pump_fallback(self):
        s, ses = self.state, self.ses
        _mandate(s, ses, self.__class__.day, mode="hitl")
        tick = self._tick()
        key = "binance:ETH-USDT-PERP"
        s.trading.broker.positions.pop(key, None)
        with self.assertRaises(QueuedForApproval):
            s.trading.gateway.submit(key, 1, 2e4, 2.0, tick, {}, False)
        with self.assertRaises(QueuedForApproval):
            s.trading.gateway.submit("bybit:BTC-USDT-PERP", -1, 2e4, 2.0,
                                     tick, {}, False)
        pend = [i for i in ses.queue if i.status == "pending"]
        self.assertEqual(len(pend), 2)
        # fresh path: approval executes NOW at the latest quote
        ses.approve_intent(pend[0].oid, actor="human:test")
        self.assertIn(pend[0].status, ("filled", "rejected"))
        self.assertTrue(any(e.kind in ("l3.fresh_fill", "l3.fresh_rejected")
                            for e in s.audit.tail(8)))
        # requote ceremony: drifted quote demands a second human key
        pend[1].quoted_premium += 0.01              # ~100 bps > 25 bps cap
        ses.approve_intent(pend[1].oid, actor="human:test")
        self.assertEqual(pend[1].status, "stale_requote")
        self.assertEqual(pend[1].requotes, 1)
        self.assertTrue(any(e.kind == "l3.requote_required"
                            for e in s.audit.tail(6)))
        ses.approve_intent(pend[1].oid, actor="human:test")
        self.assertIn(pend[1].status, ("filled", "rejected"))
        nd = self.__class__.day + 1
        # pending intents expire at the day boundary; approved-but-unexecuted
        # ones (e.g. across a restart) still pump at today's quotes
        with self.assertRaises(QueuedForApproval):
            s.trading.gateway.submit("hyperliquid:ETH-USD-PERP", 1, 2e4, 2.0,
                                     self._tick(), {}, False)
        late = [i for i in ses.queue if i.status == "pending"][-1]
        from arsic.execution_l3 import OrderIntent
        ghost = OrderIntent(oid="OGHOST", day=self.__class__.day,
                            key="bybit:BTC-USDT-PERP", side=1, notional=1.5e4,
                            leverage=2.0, quoted_premium=tick.premium,
                            extreme=False, status="approved")
        ses.queue.append(ghost)
        ses.on_day_start(nd)
        self.assertEqual(late.status, "expired")
        self.assertIn(ghost.status, ("filled", "rejected"))
        self.assertTrue(any(e.kind in ("l3.stale_fill", "l3.pump_rejected")
                            for e in s.audit.tail(20)))
        ses.revoke(nd, actor="human:test")

    def test_6_deadman_expiry_demotes_and_flattens(self):
        s, ses = self.state, self.ses
        d = self.__class__.day
        _mandate(s, ses, d, heartbeat_every=1)
        tick = self._tick()
        k = "binance:BTC-USDT-PERP"
        s.trading.broker.positions.pop(k, None)
        s.trading.gateway.submit(k, 1, 2e4, 2.0, tick, {}, False)
        self.assertIn(k, s.trading.broker.positions)
        ses.heartbeat(d, actor="human:test")
        ses.on_day_start(d + 1)                            # within window
        self.assertTrue(ses.active(d + 1))
        ses.on_day_start(d + 3)                            # lapsed
        self.assertEqual(ses.mandate.status, "revoked")
        self.assertEqual(ses.mandate.revoke_reason, "deadman_expired")
        self.assertNotIn(k, s.trading.broker.positions)    # flattened
        self.assertTrue(any(e.kind == "l3.demoted" for e in s.audit.tail(8)))

    def test_7_breaker_trip_demotes_immediately(self):
        s, ses = self.state, self.ses
        d = self.__class__.day
        _mandate(s, ses, d)
        s.killswitch.human_trip("l3 breaker test")
        ses.on_freeze(d)
        self.assertEqual(ses.mandate.revoke_reason, "breaker")
        _reset_if_frozen(s)

    def test_8_loss_cap_gates_and_demotes(self):
        s, ses = self.state, self.ses
        d = self.__class__.day
        _mandate(s, ses, d, loss_cap=1e3)
        ses._day_equity_mark = s.trading.broker.equity + 5e3   # simulate loss
        tick = self._tick()
        with self.assertRaises(LiveTradeRejected):
            s.trading.gateway.submit("bybit:SOL-USDT-PERP", 1, 1e4, 2.0,
                                     tick, {}, False)
        self.assertEqual(ses.mandate.status, "revoked")
        self.assertEqual(ses.mandate.revoke_reason, "loss_cap")

    def test_9_audit_chain_and_snapshot_shape(self):
        ok, _ = self.state.audit.verify()
        self.assertTrue(ok)
        snap = self.ses.snapshot(self.__class__.day)
        for k in ("active", "mode", "caps", "used", "counters", "queue"):
            self.assertIn(k, snap)
        kinds = {e.kind for e in self.state.audit.all()}
        for k in ("l3.mandate_activated", "l3.fill", "l3.gated", "l3.queued",
                  "l3.intent_approved", "l3.fresh_fill",
                  "l3.requote_required", "l3.demoted",
                  "l3.heartbeat", "l3.flatten", "l3.token_minted"):
            self.assertIn(k, kinds)


if __name__ == "__main__":
    unittest.main()
