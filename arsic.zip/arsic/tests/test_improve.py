import shutil
import tempfile
import unittest
from pathlib import Path

from arsic.events import EventLog, ExperimentTracker
from arsic.governance import Governance, GoalContract, ContractError, Priv
from arsic.evaluate import Evaluator, Scoreboard
from arsic.improve import (
    Harness, HarnessRepo, HarnessEvolution, signflip_pvalue, MetaQueue,
    DEFAULT_STRATEGY,
)
from arsic.llm import bounded_adapter_update
from arsic.exg import Trajectory

GIT = shutil.which("git") is not None

CONTRACT = GoalContract(principal="sys", objective="o",
                        constraints={"max_leverage": 3.0, "max_drawdown": 0.10,
                                     "min_liq_score": 0.3, "paper_only": True},
                        scopes=("*",))


def mk_evo(d, evaluator=None):
    audit = EventLog(str(Path(d) / "a.jsonl"))
    gov = Governance(secret="s", audit=audit)
    ev = evaluator or Evaluator()
    ev.freeze()
    repo = HarnessRepo(str(Path(d) / "repo"), audit)
    evo = HarnessEvolution(gov, CONTRACT, ev, repo, Scoreboard(),
                           ExperimentTracker(str(Path(d) / "exp.jsonl")),
                           audit, str(Path(d) / "sbx"))
    return evo, gov, audit, repo


class TestSignFlip(unittest.TestCase):
    def test_all_positive_small_p(self):
        p = signflip_pvalue([0.5, 0.4, 0.6, 0.5, 0.7, 0.4, 0.5, 0.6, 0.5, 0.4])
        self.assertAlmostEqual(p, 1 / 1024)

    def test_mixed_large_p(self):
        p = signflip_pvalue([0.5, -0.5, 0.4, -0.4, 0.1, -0.1])
        self.assertGreater(p, 0.05)


class TestHarness(unittest.TestCase):
    def test_apply_diff_semantics(self):
        h = Harness()
        h2 = h.apply_diff({"strategy.z_cap": 2.5,
                           "prompts.market_analysis": "+[[EXTREME_DISCOUNT]]",
                           "topology": "cross_venue_precheck"})
        self.assertEqual(h2.strategy["z_cap"], 2.5)
        self.assertEqual(h.strategy["z_cap"], DEFAULT_STRATEGY["z_cap"])  # copy
        self.assertIn("[[EXTREME_DISCOUNT]]", h2.prompts["market_analysis"])
        self.assertIn("cross_venue_precheck", h2.topology)
        self.assertNotIn("cross_venue_precheck", h.topology)


class TestRepo(unittest.TestCase):
    @unittest.skipUnless(GIT, "git unavailable")
    def test_git_commits(self):
        with tempfile.TemporaryDirectory() as d:
            audit = EventLog(str(Path(d) / "a.jsonl"))
            repo = HarnessRepo(str(Path(d) / "r"), audit)
            h = Harness()
            sha1 = repo.commit(h, "v1: init")
            h2 = h.apply_diff({"strategy.z_cap": 2.5}); h2.version = 2
            sha2 = repo.commit(h2, "v2: tighten")
            self.assertTrue(sha1 and sha2 and sha1 != sha2)
            self.assertEqual(len(repo.log()), 2)
            self.assertEqual(audit.count("harness.commit"), 2)


class TestEpochGates(unittest.TestCase):
    def test_frozen_evaluator_required(self):
        with tempfile.TemporaryDirectory() as d:
            evo, gov, audit, _ = mk_evo(d)
            evo.evaluator = Evaluator()          # unfrozen
            with self.assertRaises(AssertionError):
                evo.epoch(Harness(), seeds=[1], days=2)

    def test_lint_screen(self):
        with tempfile.TemporaryDirectory() as d:
            evo, gov, audit, _ = mk_evo(d)
            _, reports = evo.epoch(Harness(), seeds=[1, 2], days=2,
                                   candidates=[("lev5", Priv.SKILL,
                                                {"strategy.max_leverage": 5.0})])
            self.assertEqual(len(reports), 1)
            self.assertTrue(reports[0].lint_violations)
            self.assertFalse(reports[0].promoted)
            self.assertEqual(audit.count("improve.lint_reject"), 1)

    def test_policy_ticket_blocks_unapproved(self):
        with tempfile.TemporaryDirectory() as d:
            evo, gov, audit, _ = mk_evo(d)
            # a no-op diff at POLICY level: even if p is not significant the
            # reason chain must never be 'applied' without human approval
            _, reports = evo.epoch(Harness(), seeds=[1, 2], days=2,
                                   candidates=[("policy-noop", Priv.POLICY,
                                                {"routing.cross_venue_precheck": True})])
            r = reports[0]
            self.assertFalse(r.promoted)
            t = [t for t in gov.tickets.values() if t.tid == r.ticket_id][0]
            self.assertNotEqual(t.status, "applied")

    def test_skill_promotion_end_to_end(self):
        with tempfile.TemporaryDirectory() as d:
            evo, gov, audit, repo = mk_evo(d)
            promoted, reports = evo.epoch(
                Harness(), seeds=list(range(1, 7)), days=6,
                candidates=[("tighten extreme filter (+prompt directive)",
                             Priv.SKILL,
                             {"strategy.z_cap": 2.5, "strategy.persistence_min": 3,
                              "prompts.market_analysis": "+[[EXTREME_DISCOUNT]]"})])
            r = reports[0]
            self.assertTrue(r.promoted, f"expected promotion, got: {r.reason} "
                                        f"(p={r.p_value:.4f}, d={r.mean_diff:.4f})")
            self.assertLess(r.p_value, 0.05)
            self.assertGreater(r.mean_diff, 0)
            self.assertEqual(promoted.version, 2)
            self.assertGreater(len(evo.sibling_exg.verified_trajectories()), 0)
            self.assertEqual(audit.count("improve.ab_result"), 1)


class TestAdapter(unittest.TestCase):
    def test_bound_clamp(self):
        cur = {"risk_aversion": 1.0, "extreme_discount": 1.0}
        b = bounded_adapter_update(cur, {"risk_aversion": 3.0,
                                         "extreme_discount": 0.1})
        self.assertAlmostEqual(b["risk_aversion"], 1.25)
        self.assertAlmostEqual(b["extreme_discount"], 0.75)

    def test_fit_uses_verified_only_and_apply_gated(self):
        with tempfile.TemporaryDirectory() as d:
            evo, gov, audit, _ = mk_evo(d)
            evo.sibling_exg.add(Trajectory(
                tid="", run_id="s", regime="high_vol",
                features={"z": 3.0}, actions=["enter"],
                outcome={"pnl": -50.0}, verified=True))
            evo.sibling_exg.add(Trajectory(
                tid="", run_id="s", regime="high_vol",
                features={"z": 4.0}, actions=["enter"],
                outcome={"pnl": -80.0}, verified=False))   # must be ignored
            bounded, ticket, paths = evo.fit_adapter(Harness(), str(Path(d) / "td"))
            # only the single verified extreme traj counts: fp_rate_ext = 1.0
            self.assertAlmostEqual(bounded["risk_aversion"], 1.25)   # clamped
            with self.assertRaises(ContractError):
                evo.apply_adapter(Harness(), bounded, ticket)
            gov.approve(ticket.tid, actor_role="human")
            h2 = evo.apply_adapter(Harness(), bounded, ticket)
            self.assertEqual(h2.version, 2)
            self.assertEqual(h2.adapter, bounded)
            for p in paths.values():
                self.assertTrue(Path(p).exists())


class TestMetaQueue(unittest.TestCase):
    def test_meta_ticket(self):
        with tempfile.TemporaryDirectory() as d:
            audit = EventLog(str(Path(d) / "a.jsonl"))
            gov = Governance(secret="s", audit=audit)
            mq = MetaQueue(gov)
            t = mq.propose_meta("change AB acceptance", {"alpha": 0.01}, "meta")
            self.assertEqual(t.level, int(Priv.META))
            self.assertFalse(gov.is_executable(t))


if __name__ == "__main__":
    unittest.main()
