"""External route over the wire: ARSIC server + venue simulator on loopback.
The console's orders land on a venue-side ledger; reconciliation freezes the
system when the venue book diverges out-of-band."""
import json
import os
import shutil
import unittest
import urllib.request

from arsic.execution_l3 import ACK_1, ACK_2
from arsic.server import serve
from arsic.venue_client import VenueClient
from arsic.venue_sim import serve_venue

API = 8913
VEN = 8914
KEYS = {"trader-key": {"secret": "trader-sec", "scope": "trade"},
        "sentinel-key": {"secret": "sentinel-sec", "scope": "cancel"}}


def call(path, body=None):
    req = urllib.request.Request(
        f"http://127.0.0.1:{API}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Content-Type": "application/json"},
        method="POST" if body is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return json.loads(e.read().decode())


def _arm(route_caps=None):
    call("/api/reset", {"seed": 7})
    call("/api/seal", {})
    body = {"mode": "hotl", "route": "external", "ttl_days": 8,
            "heartbeat_every": 4, "max_notional_per_order": 5e5,
            "max_gross_notional": 1.5e6, "max_leverage": 3.0,
            "loss_cap": 2e5, "order_rate_per_day": 40,
            "venues": ["binance", "bybit", "hyperliquid", "xv"],
            "acks": [ACK_1, ACK_2]}
    body.update(route_caps or {})
    r = call("/api/l3/request", body)
    call("/api/ticket/approve", {"tid": r["tid"]})
    return call("/api/l3/activate", {"tid": r["tid"]})


class TestExternalRoute(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        shutil.rmtree("run_ext_t", ignore_errors=True)
        cls.sim, cls.vhttpd = serve_venue(KEYS, VEN, salt="shadow:ext")
        os.environ["ARSIC_VENUE_URL"] = f"http://127.0.0.1:{VEN}"
        os.environ["ARSIC_VENUE_KEY"] = "trader-key"
        os.environ["ARSIC_VENUE_SECRET"] = "trader-sec"
        cls.srv, cls.httpd = serve("run_ext_t", port=API, seed=7,
                                   block=False)
        cls.sentinel = VenueClient(f"http://127.0.0.1:{VEN}",
                                   "sentinel-key", "sentinel-sec")

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.vhttpd.shutdown()
        for k in ("ARSIC_VENUE_URL", "ARSIC_VENUE_KEY",
                  "ARSIC_VENUE_SECRET"):
            os.environ.pop(k, None)
        shutil.rmtree("run_ext_t", ignore_errors=True)

    def test_1_external_arc_orders_land_on_the_venue(self):
        m = _arm()
        self.assertEqual(m["mode"], "hotl")
        snap = call("/api/state")["snapshot"]
        self.assertEqual(snap["l3"]["route"], "external")
        self.assertIn(str(VEN), snap["l3"]["venue"])
        for _ in range(3):
            r = call("/api/day", {})
            if isinstance(r, dict) and r.get("error"):
                self.fail(r["error"])
        snap = call("/api/state")["snapshot"]
        fills = snap["l3"]["counters"]["fills"]
        self.assertGreater(fills, 0)
        vgross = sum(p["notional"] for p in self.sentinel.positions())
        self.assertGreater(vgross, 0)
        self.assertAlmostEqual(vgross, snap["l3"]["used"]["gross"],
                               delta=max(1.0, 0.001 * vgross))
        kinds = {e["kind"] for e in call("/api/state")["events"]}
        self.assertIn("l3.external_armed", kinds)
        self.assertIn("l3.fill", kinds)
        # human revoke flattens venue-side too
        call("/api/l3/revoke", {})
        self.assertEqual(self.sentinel.positions(), [])
        snap = call("/api/state")["snapshot"]
        self.assertEqual(snap["l3"]["status"], "revoked")
        self.assertTrue(call("/api/audit/verify")["ok"])

    def test_2_out_of_band_divergence_trips_the_breaker(self):
        _arm()
        for _ in range(2):
            call("/api/day", {})
        snap = call("/api/state")["snapshot"]
        if snap["l3"]["used"]["gross"] <= 0:
            call("/api/day", {})
            snap = call("/api/state")["snapshot"]
        self.assertGreater(snap["l3"]["used"]["gross"], 0)
        # sentinel-scope credential wipes the venue book out-of-band
        self.sentinel.cancel_all()
        call("/api/day", {})                      # reconciliation runs
        snap = call("/api/state")["snapshot"]
        # durable invariants: mandate revoked with the mismatch reason and
        # the breaker trip is on the chain (the bootstrap cycle's morning
        # human ops-review then clears the freeze, as it does for any trip)
        self.assertEqual(snap["l3"]["status"], "revoked")
        self.assertEqual(snap["l3"]["revokeReason"], "reconcile_mismatch")
        kinds = {e["kind"] for e in call("/api/state")["events"]}
        self.assertIn("l3.reconcile_mismatch", kinds)
        self.assertIn("killswitch.tripped", kinds)
        fl = [e for e in call("/api/state")["events"]
              if e["kind"] == "l3.flatten"
              and e["payload"].get("reason") == "demote:reconcile_mismatch"]
        self.assertTrue(fl and fl[-1]["payload"]["closed"] >= 1)
        self.assertEqual(self.sentinel.positions(), [])   # venue stays flat
        self.assertTrue(call("/api/audit/verify")["ok"])

    def test_3_non_loopback_requires_explicit_risk_ack(self):
        os.environ["ARSIC_VENUE_URL"] = "http://venue.example.com:443"
        try:
            call("/api/reset", {"seed": 7})
            call("/api/seal", {})
            r = call("/api/l3/request", {
                "mode": "hotl", "route": "external",
                "acks": [ACK_1, ACK_2]})
            call("/api/ticket/approve", {"tid": r["tid"]})
            resp = call("/api/l3/activate", {"tid": r["tid"]})
            self.assertIn("ARSIC_LIVE_ACK", resp.get("error", ""))
        finally:
            os.environ["ARSIC_VENUE_URL"] = f"http://127.0.0.1:{VEN}"


if __name__ == "__main__":
    unittest.main()
