import tempfile
import unittest
from pathlib import Path

from arsic.events import EventLog
from arsic.governance import Governance, GoalContract, Frozen
from arsic.perception import Tick
from arsic.trading import (
    PaperBroker, PositionSizer, LiquidationMonitor, ExecutionGateway,
    LiveTradeRejected, RiskVeto,
)
from arsic.strategy_math import COST_ROUNDTRIP


def tick(day=0, period=0, funding=0.0005, premium=0.001, oi=5e8, liq=0.9):
    spot = 50_000.0
    return Tick(day=day, period=period, venue="binance", symbol="BTC-USDT-PERP",
                spot=spot, perp=spot * (1 + premium), funding=funding, oi=oi,
                volume=1e9, liq_score=liq)


def mk():
    d = tempfile.TemporaryDirectory()
    audit = EventLog(str(Path(d.name) / "a.jsonl"))
    gov = Governance(secret="s", audit=audit)
    broker = PaperBroker(audit, equity0=1_000_000.0)
    return d, audit, gov, broker


CONTRACT = GoalContract(principal="sys", objective="o",
                        constraints={"max_leverage": 3.0, "max_drawdown": 0.10,
                                     "min_liq_score": 0.3, "paper_only": True},
                        scopes=("*",))


class TestBroker(unittest.TestCase):
    def test_funding_accrual_sign(self):
        d, _, _, broker = mk()
        try:
            t0 = tick()
            key = "binance:BTC-USDT-PERP"
            p = broker.open_pos(key, side=+1, notional=100_000, leverage=2.0,
                                tick=t0, stats={}, extreme=False)
            self.assertAlmostEqual(p.fees, COST_ROUNDTRIP / 2 * 100_000)
            # +funding, short-perp side => receives funding
            broker.on_period({key: tick(period=1)})
            self.assertAlmostEqual(p.funding_pnl, 0.0005 * 100_000)
            # premium unchanged => zero MTM
            self.assertAlmostEqual(p.mtm, 0.0, places=6)
            # premium decays toward 0 => short-perp gains
            broker.on_period({key: tick(period=2, premium=0.0)})
            self.assertAlmostEqual(p.mtm, 0.001 * 100_000)
            broker.close(key)
            self.assertEqual(len(broker.closed), 1)
            self.assertFalse(p.open)
            expected_net = (0.0005 * 2) * 100_000 + 0.001 * 100_000 - \
                COST_ROUNDTRIP * 100_000
            self.assertAlmostEqual(p.net, expected_net, places=4)
        finally:
            d.cleanup()

    def test_negative_side(self):
        d, _, _, broker = mk()
        try:
            key = "k"
            p = broker.open_pos(key, side=-1, notional=100_000, leverage=2.0,
                                tick=tick(funding=-0.0006, premium=-0.001),
                                stats={}, extreme=False)
            broker.on_period({key: tick(funding=-0.0006, premium=-0.001)})
            self.assertAlmostEqual(p.funding_pnl, 0.0006 * 100_000)
        finally:
            d.cleanup()

    def test_flatten_and_max_dd(self):
        d, _, _, broker = mk()
        try:
            for i in range(3):
                broker.open_pos(f"k{i}", +1, 50_000, 2.0, tick(), {}, False)
            broker.flatten_all()
            self.assertEqual(broker.positions, {})
            self.assertEqual(len(broker.closed), 3)
            self.assertGreater(broker.max_dd(), 0.0)
        finally:
            d.cleanup()


class TestSizer(unittest.TestCase):
    def test_caps_and_veto(self):
        s = PositionSizer(CONTRACT)
        with self.assertRaises(RiskVeto):
            s.size(edge=0.001, liq_score=0.1, oi=5e8, equity=1e6)
        notional, lev = s.size(edge=0.001, liq_score=0.9, oi=5e8, equity=1e6)
        self.assertLessEqual(lev, 3.0)
        self.assertLessEqual(notional, 1e6 * 0.10)
        self.assertLessEqual(notional, 5e8 * 0.001)
        # OI participation cap binds on thin books
        notional2, _ = s.size(edge=0.001, liq_score=0.9, oi=1e7, equity=1e6)
        self.assertAlmostEqual(notional2, 1e7 * 0.001)


class TestLiqMonitor(unittest.TestCase):
    def test_levels(self):
        lm = LiquidationMonitor()
        p_ok = PaperBroker(EventLog(tempfile.mktemp()), 1e6).open_pos(
            "k", +1, 1e5, 2.0, tick(premium=0.001), {}, False)
        self.assertEqual(lm.assess(p_ok, premium_now=0.001), "ok")
        # capacity = 1/2 - 0.05 = 0.45; adverse 0.30 -> warn ; 0.42 -> reduce
        self.assertEqual(lm.assess(p_ok, premium_now=0.301), "warn")
        self.assertEqual(lm.assess(p_ok, premium_now=0.421), "reduce")


class TestGateway(unittest.TestCase):
    def test_paper_ok_live_rejected(self):
        d, audit, gov, broker = mk()
        try:
            gw = ExecutionGateway(broker, gov)
            p = gw.submit("k", +1, 1e5, 2.0, tick(), {}, False)
            self.assertTrue(p.open)
            # live requires autonomy>=3 AND a valid token; neither holds
            with self.assertRaises(LiveTradeRejected):
                gw.submit("k2", +1, 1e5, 2.0, tick(), {}, False,
                          live=True, human_token="forged")
            self.assertEqual(gw.live_trades, 0)
            self.assertEqual(gw.live_rejections, 1)
            self.assertEqual(audit.count("exec.live_rejected"), 1)
            # even a genuine token fails below autonomy L3
            tok = gov.human_token("live:k3")
            with self.assertRaises(LiveTradeRejected):
                gw.submit("k3", +1, 1e5, 2.0, tick(), {}, False,
                          live=True, human_token=tok)
            self.assertEqual(gw.live_trades, 0)
        finally:
            d.cleanup()

    def test_frozen_gateway(self):
        d, audit, gov, broker = mk()
        try:
            gw = ExecutionGateway(broker, gov)
            gov.freeze("drill", "unit")
            with self.assertRaises(Frozen):
                gw.submit("k", +1, 1e5, 2.0, tick(), {}, False)
            self.assertEqual(audit.count("exec.rejected_frozen"), 1)
        finally:
            d.cleanup()


if __name__ == "__main__":
    unittest.main()
