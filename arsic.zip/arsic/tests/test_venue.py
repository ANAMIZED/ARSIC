"""Conformance suite for the venue wire protocol + production client.
Any real venue integration should pass the same shape of suite."""
import unittest
import urllib.request
import urllib.error
import json

from arsic.execution_l3 import ShadowLiveAdapter, OrderIntent
from arsic.venue_client import (VenueClient, VenueAuthError)
from arsic.venue_sim import serve_venue, sign

PORT = 8911
KEYS = {"trader-key": {"secret": "trader-sec", "scope": "trade"},
        "sentinel-key": {"secret": "sentinel-sec", "scope": "cancel"}}


class FakeTick:
    """Minimal tick standing in for perception.Tick (dataclasses.replace
    needs a dataclass, so the adapter parity test builds a real one)."""


class TestVenueConformance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sim, cls.httpd = serve_venue(KEYS, PORT, salt="shadow:parity")
        cls.trader = VenueClient(f"http://127.0.0.1:{PORT}",
                                 "trader-key", "trader-sec",
                                 backoff_s=0.01)
        cls.sentinel = VenueClient(f"http://127.0.0.1:{PORT}",
                                   "sentinel-key", "sentinel-sec",
                                   backoff_s=0.01)

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def _raw(self, api_key, secret, nonce, method="POST",
             path="/v1/cancel_all", body="{}", sig=None):
        req = urllib.request.Request(
            f"http://127.0.0.1:{PORT}{path}", method=method,
            data=body.encode(),
            headers={"X-API-KEY": api_key, "X-NONCE": str(nonce),
                     "X-SIGNATURE": sig if sig is not None
                     else sign(secret, method, path, body, str(nonce))})
        return urllib.request.urlopen(req, timeout=2)

    def test_1_signature_and_nonce_enforced(self):
        with self.assertRaises(urllib.error.HTTPError) as cm:
            self._raw("trader-key", "trader-sec", 10, sig="forged")
        self.assertEqual(cm.exception.code, 401)
        self._raw("trader-key", "trader-sec", 11)          # valid
        with self.assertRaises(urllib.error.HTTPError) as cm:
            self._raw("trader-key", "trader-sec", 11)      # replay
        self.assertEqual(cm.exception.code, 409)
        with self.assertRaises(VenueAuthError):
            VenueClient(f"http://127.0.0.1:{PORT}", "trader-key",
                        "wrong-sec").health if False else \
                VenueClient(f"http://127.0.0.1:{PORT}", "trader-key",
                            "wrong-sec").cancel_all()

    def test_2_scope_least_privilege(self):
        with self.assertRaises(VenueAuthError) as cm:
            self.sentinel.place_order("scope-x", "binance:BTC", 1, 1e4, 2.0)
        self.assertIn("403", str(cm.exception))
        self.assertIn("closed", self.sentinel.cancel_all())
        self.assertIsInstance(self.sentinel.positions(), list)

    def test_3_idempotent_client_oid(self):
        r1 = self.trader.place_order("idem-1", "binance:BTC", 1, 5e4, 2.0)
        g1 = self.trader.gross()
        r2 = self.trader.place_order("idem-1", "binance:BTC", 1, 5e4, 2.0)
        self.assertEqual(r1, r2)                 # exact replayed response
        self.assertEqual(self.trader.gross(), g1)  # no double booking

    def test_4_throttle_retried_transparently(self):
        # find an oid whose first attempt throttles (h % 13 == 0)
        from arsic.venue_sim import _h
        oid = next(f"th-{i}" for i in range(500)
                   if _h("shadow:parity", f"th-{i}") % 13 == 0
                   and _h("shadow:parity", f"th-{i}") % 23 != 0)
        before = self.sim.requests
        r = self.trader.place_order(oid, "bybit:ETH", 1, 1e4, 2.0)
        self.assertIn(r["status"], ("filled", "partial"))
        self.assertGreaterEqual(self.sim.requests - before, 2)  # 429 then ok

    def test_5_fill_math_matches_shadow_adapter(self):
        import dataclasses as dc

        @dc.dataclass
        class T:
            perp: float
            premium: float = 0.0
            day: int = 0
            period: int = 0
        shadow = ShadowLiveAdapter("shadow:parity")
        checked = rejects = partials = 0
        for i in range(120):
            oid = f"par-{i}"
            intent = OrderIntent(oid=oid, day=0, key="binance:BTC",
                                 side=1, notional=1e4, leverage=2.0,
                                 quoted_premium=0.0, extreme=False)
            sh = shadow.fill(intent, T(perp=100.0))
            vr = self.trader.place_order(oid, "hyperliquid:SOL", 1, 1e4, 2.0)
            if sh is None:
                rejects += 1
                self.assertEqual(vr["status"], "rejected")
                continue
            self.assertIn(vr["status"], ("filled", "partial"))
            self.assertEqual(vr["slip_bps"], sh["slip_bps"])
            self.assertAlmostEqual(vr["fill_ratio"], sh["ratio"])
            self.assertAlmostEqual(vr["fee"], sh["extra_fee"], places=9)
            if sh["ratio"] < 1.0:
                partials += 1
            checked += 1
        self.assertGreater(checked, 80)
        self.assertGreater(rejects, 0)
        self.assertGreater(partials, 0)


if __name__ == "__main__":
    unittest.main()
