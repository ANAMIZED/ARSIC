import tempfile
import unittest
from pathlib import Path

from arsic.events import EventLog
from arsic.governance import Governance, ContractError
from arsic.evaluate import (
    Evaluator, FrozenEvaluatorError, kendall_tau, gt_tau,
    Scoreboard, EvaluatorEvolution,
)


def mk():
    d = tempfile.TemporaryDirectory()
    audit = EventLog(str(Path(d.name) / "a.jsonl"))
    gov = Governance(secret="s", audit=audit)
    return d, audit, gov


class TestEvaluator(unittest.TestCase):
    def test_freeze_immutability(self):
        ev = Evaluator()
        ev.set_param("w_fp", 3.5)
        h = ev.freeze()
        self.assertEqual(h, ev.hash)
        with self.assertRaises(FrozenEvaluatorError):
            ev.set_param("w_fp", 9.9)

    def test_score_direction(self):
        ev = Evaluator()
        good = ev.score({"sharpe": 2.0, "capture_eff": 0.4,
                         "fp_rate": 0.02, "max_dd": 0.02})
        bad = ev.score({"sharpe": 2.0, "capture_eff": 0.4,
                        "fp_rate": 0.30, "max_dd": 0.20})
        self.assertGreater(good, bad)

    def test_kendall(self):
        self.assertAlmostEqual(kendall_tau([1, 2, 3], [1, 2, 3]), 1.0)
        self.assertAlmostEqual(kendall_tau([1, 2, 3], [3, 2, 1]), -1.0)

    def test_candidate_beats_incumbent_on_ground_truth(self):
        inc = Evaluator()
        cand = Evaluator({"w_fp": 4.0, "w_dd": 3.0})
        self.assertGreater(gt_tau(cand), gt_tau(inc))


class TestScoreboard(unittest.TestCase):
    def test_selective_erasure(self):
        b = Scoreboard()
        b.record("h1", "harness.v1", 1.0, 0)
        b.record("h1", "harness.v2", 1.2, 0)
        b.record("h2", "harness.v2", 0.9, 1)
        self.assertEqual(len(b.comparable("h1")), 2)
        erased = b.mark_stale("h1")
        self.assertEqual(erased, 2)
        self.assertEqual(b.comparable("h1"), [])      # excluded from comparison
        self.assertEqual(len(b.entries), 3)           # raw kept for audit
        self.assertEqual(len(b.comparable("h2")), 1)  # other hash untouched


class TestEvolution(unittest.TestCase):
    def test_replace_requires_beat_and_human(self):
        d, audit, gov = mk()
        try:
            board = Scoreboard()
            evo = EvaluatorEvolution(gov, board, audit)
            inc = Evaluator(); inc.freeze()
            board.record(inc.hash, "harness.v1", 1.0, 0)

            worse = Evaluator({"w_fp": 0.0, "w_dd": 0.0})
            beat, ticket, _ = evo.attempt(inc, worse)
            self.assertFalse(beat)
            gov.approve(ticket.tid, actor_role="human")
            with self.assertRaises(FrozenEvaluatorError):
                evo.replace(inc, worse, ticket)       # GT gate blocks even if approved

            cand = Evaluator({"w_fp": 4.0, "w_dd": 3.0})
            beat, ticket2, taus = evo.attempt(inc, cand)
            self.assertTrue(beat)
            with self.assertRaises(ContractError):
                evo.replace(inc, cand, ticket2)       # human gate blocks
            gov.approve(ticket2.tid, actor_role="human")
            new = evo.replace(inc, cand, ticket2)
            self.assertTrue(new.frozen)
            self.assertEqual(board.comparable(inc.hash), [])   # erased
            self.assertEqual(audit.count("evaluator.replaced"), 1)
        finally:
            d.cleanup()


if __name__ == "__main__":
    unittest.main()
