import tempfile
import unittest
from pathlib import Path

from arsic.events import EventLog, ObjectStore
from arsic.governance import Governance, GoalContract, ScopeRouter
from arsic.runtime import AgentProcess, Planes, Scheduler, Quotas, Bus, Task
from arsic.tools import ToolRegistry, Tool, ToolError
from arsic.wiki import TemporalKG, WikiPages
from arsic.exg import ExperienceGraph
from arsic.llm import DeterministicCore


def mk_planes(d):
    audit = EventLog(str(Path(d) / "a.jsonl"))
    store = ObjectStore(str(Path(d) / "obj"))
    gov = Governance(secret="s", audit=audit)
    router = ScopeRouter(audit)
    tools = ToolRegistry(audit)
    kg = TemporalKG(audit, store)
    pages = WikiPages(kg, audit)
    exg = ExperienceGraph(audit)
    core = DeterministicCore({}, {"risk_aversion": 1.0, "extreme_discount": 1.0})
    return Planes(gov, router, tools, kg, pages, exg, Bus(), audit, core), gov, audit


class Echo(AgentProcess):
    SCOPES = {"echo"}

    def execute(self, step, task):
        return {"ok": True, "step": step}


class Burner(AgentProcess):
    SCOPES = {"burn"}

    def execute(self, step, task):
        self.quotas.spend("tool_calls", 10)
        return {"ok": True}


class Parent(AgentProcess):
    SCOPES = {"parent"}

    def execute(self, step, task):
        child_task = Task(tid=task.tid + ".c", kind="echo",
                          scopes={"echo"}, payload={})
        r = self.spawn(Echo, self.id + ".child", child_task)
        return {"child_result": r}


def contract_for(gov, cls, aid):
    return gov.sign_contract(GoalContract(
        principal=aid, objective="t", constraints={}, scopes=tuple(cls.SCOPES)))


class TestAgentLoop(unittest.TestCase):
    def test_in_scope_executes(self):
        with tempfile.TemporaryDirectory() as d:
            planes, gov, _ = mk_planes(d)
            sched = Scheduler(planes)
            a = Echo("a.echo", contract_for(gov, Echo, "a.echo"), planes)
            sched.add(a)
            t = sched.new_task("echo", {"echo"}, {"x": 1})
            r = sched.dispatch("a.echo", t)
            self.assertEqual(r["ok"], True)
            self.assertEqual(a.status["state"], "done")

    def test_out_of_scope_refused_with_handoff(self):
        with tempfile.TemporaryDirectory() as d:
            planes, gov, audit = mk_planes(d)
            sched = Scheduler(planes)
            a = Echo("a.echo", contract_for(gov, Echo, "a.echo"), planes)
            sched.add(a)
            t = sched.new_task("other", {"not-mine"}, {})
            r = sched.dispatch("a.echo", t)
            self.assertIsNone(r)
            self.assertEqual(audit.count("agent.refused_out_of_scope"), 1)
            self.assertEqual(len(planes.router.handoffs), 1)

    def test_quota_suspension(self):
        with tempfile.TemporaryDirectory() as d:
            planes, gov, audit = mk_planes(d)
            sched = Scheduler(planes)
            a = Burner("a.burn", contract_for(gov, Burner, "a.burn"), planes,
                       quotas=Quotas(tool_calls=5))
            sched.add(a)
            t = sched.new_task("burn", {"burn"}, {})
            r = sched.dispatch("a.burn", t)
            self.assertIsNone(r)
            self.assertTrue(a.suspended)
            self.assertEqual(audit.count("agent.suspended"), 1)
            # suspended agents are skipped
            self.assertIsNone(sched.dispatch("a.burn",
                                             sched.new_task("burn", {"burn"}, {})))

    def test_spawn_tree_and_report_up(self):
        with tempfile.TemporaryDirectory() as d:
            planes, gov, audit = mk_planes(d)
            sched = Scheduler(planes)
            p = Parent("a.parent", contract_for(gov, Parent, "a.parent"), planes)
            sched.add(p)
            t = sched.new_task("parent", {"parent"}, {})
            r = sched.dispatch("a.parent", t)
            self.assertEqual(r["child_result"]["ok"], True)
            self.assertEqual(len(p.children), 1)
            self.assertEqual(p.memory["child_reports"][0]["child"], "a.parent.child")
            self.assertEqual(audit.count("agent.spawned"), 1)
            tree = sched.tree()
            self.assertEqual(tree["agents"][0]["children"][0]["id"], "a.parent.child")

    def test_tampered_contract_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            planes, gov, _ = mk_planes(d)
            a = Echo("a.echo", contract_for(gov, Echo, "a.echo"), planes)
            a.contract.objective = "evil"
            planes.router.register(a.id, a.scopes)
            with self.assertRaises(PermissionError):
                a.handle(Task(tid="T1", kind="echo", scopes={"echo"}, payload={}))

    def test_frozen_scheduler_skips(self):
        with tempfile.TemporaryDirectory() as d:
            planes, gov, audit = mk_planes(d)
            sched = Scheduler(planes)
            a = Echo("a.echo", contract_for(gov, Echo, "a.echo"), planes)
            sched.add(a)
            gov.freeze("test", "unit")
            r = sched.dispatch("a.echo", sched.new_task("echo", {"echo"}, {}))
            self.assertIsNone(r)
            self.assertEqual(audit.count("scheduler.frozen_skip"), 1)
            gov.unfreeze(actor_role="human", analysis="done")
            r = sched.dispatch("a.echo", sched.new_task("echo", {"echo"}, {}))
            self.assertIsNotNone(r)


class TestTools(unittest.TestCase):
    def test_selftest_gate_and_scope_check(self):
        with tempfile.TemporaryDirectory() as d:
            planes, gov, audit = mk_planes(d)
            reg = planes.tools
            self.assertFalse(reg.register(Tool("bad", lambda: 1, {"x"},
                                               selftests=[lambda: False])))
            self.assertFalse(reg.register(Tool("noscope", lambda: 1, set())))
            self.assertTrue(reg.register(Tool("good", lambda v: v * 2, {"echo"},
                                              selftests=[lambda: True])))
            a = Echo("a.echo", contract_for(gov, Echo, "a.echo"), planes)
            self.assertEqual(reg.call(a, "good", 21), 42)
            with self.assertRaises(ToolError):
                reg.call(a, "bad", 1)          # never registered
            b = Burner("a.burn", contract_for(gov, Burner, "a.burn"), planes)
            with self.assertRaises(ToolError):
                reg.call(b, "good", 1)         # scope mismatch
            self.assertEqual(audit.count("tool.scope_denied"), 1)
            self.assertEqual(audit.count("tool.rejected"), 2)


if __name__ == "__main__":
    unittest.main()
