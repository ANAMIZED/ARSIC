# ARSIC — Autonomous Recursive Self-Improving Knowledge Wiki Constellation OS

Reference implementation of the ARSIC blueprint: a governed multi-agent
runtime whose trading instantiation runs **paper-only** market-neutral
funding / basis / RWA arbitrage research, with a temporal-knowledge-graph
wiki as shared memory, four nested self-improvement loops, and a
governance plane that keeps every privileged change behind a human gate.

**This is research / simulation tooling.** It never touches live venues:
the execution gateway structurally rejects live orders without a
governance-minted human token *and* autonomy level L3 (never granted in
this build). Nothing here is financial advice.

## Quick start

```bash
python3 -m unittest discover -s tests   # 66 tests, stdlib only
python3 -m arsic demo --root run --days 30
python3 -m arsic verify --root run      # re-verify the audit hash chain
```

Python ≥ 3.10, standard library only. `git` is used if available for the
harness repo (falls back to a plain versioned file).

Outputs of a demo run land in `run/`:
`reports/RUN_REPORT.md` (full transcript + daily table),
`reports/dashboard.html` (static offline ops console),
`reports/training_data/` (sft/pref/critic JSONL from verified sibling
trajectories), `harness_repo/` (git-versioned harness), and
`state/audit.jsonl` (hash-chained audit log).

## Architecture ↔ spec map

| Spec plane | Module(s) |
|---|---|
| S3 Knowledge Wiki substrate (temporal KG, gated patches, pages, EXG, audit surface) | `arsic/wiki.py`, `arsic/exg.py`, `arsic/events.py` |
| S2/S4 Constellation runtime (agent processes, contracts, quotas, spawning, scheduler, bus, tools) | `arsic/runtime.py`, `arsic/tools.py`, `arsic/constellation.py` |
| S2 Perception & tool plane (drivers, synthetic regimes, held-out suites) | `arsic/perception.py` |
| S4 Execution & risk (paper broker, sizing, liquidation monitor, gateway) | `arsic/trading.py`, shared math in `arsic/strategy_math.py` |
| S5 Recursive improvement (harness co-evolution, sandbox siblings, sign-flip A/B, adapters, evaluator co-evolution, selective erasure, META queue) | `arsic/improve.py`, `arsic/evaluate.py`, `arsic/llm.py` |
| S6 Governance & safety (goal contracts, privilege ladder, approvals, kill-switch, scope router, lint) | `arsic/governance.py` |
| S7 Stack (git harness repo, experiment tracking, object store) | `arsic/improve.py`, `arsic/events.py` |
| S8 Bootstrap + daily 7-step cycle | `arsic/bootstrap.py`, `arsic/cycle.py`, `arsic/cli.py` |
| S9 Metrics & invariants (oracle gap, fp rate, capture, audit invariants) | `arsic/strategy_math.py`, `arsic/evaluate.py`, `arsic/cli.py` |
| Human interface | `arsic/dashboard.py` (static HTML), `reports/RUN_REPORT.md` |

The sandbox this was built in has **no network egress**, so live
integrations (exchange APIs, Neo4j, K8s, W&B, LLM providers) are
implemented as pluggable driver interfaces with documented substitutions —
every substitution is itemised in `COMPLIANCE_MATRIX.md`. Verification
results and invariants are in `AUDIT_REPORT.md`.


## L3 live execution (S11) — human-lent, never ladder-granted

The autonomy ladder still caps at L2 and `advanceAutonomy(3)` still refuses.
L3 exists only as a **mandate**: a human-issued, dual-acknowledged, time-boxed,
capped loan of execution authority. Ceremony: `POST /api/l3/request` (both risk
acknowledgment strings + envelope: TTL, dead-man interval, per-order/gross
notional, leverage, daily loss cap, order rate, venue scope) files a META
ticket → operator key approves it → risk-officer key activates
(`/api/l3/activate`, requires a sealed evaluator and clean breakers). Modes:
**HOTL** (orders auto-execute inside the envelope while a human supervises via
`/api/l3/heartbeat`; a missed dead-man window demotes) and **HITL** (every
order intent queues for `/api/l3/order/approve|reject` and pumps at the *next*
day's quotes — staleness audited). Every demotion path — TTL expiry, dead-man
lapse, loss-cap breach, any breaker trip, or human `/api/l3/revoke` — flattens
the book instantly and returns to L2 paper. The pre-trade RiskGate binds at
the ExecutionGateway, below the agents, so no strategy or self-modification
can out-trade the mandate; forged per-order tokens are rejected even under an
active mandate. Execution routes through one of two adapters behind the same RiskGate:
the deterministic **shadow-live adapter** (adverse slippage, partial fills,
rejects), or the **external route** — a production HTTP venue connector
(`arsic/venue_client.py`) speaking a real exchange wire protocol:
HMAC-signed requests with strictly-increasing nonces (bounded resync on
409), idempotent client order ids, hard timeouts, retry with exponential
backoff on 429/5xx, and a clean fatal-vs-transient error taxonomy. It is
conformance-tested against `arsic/venue_sim.py`, a loopback venue with the
same wire semantics (scoped API keys, throttling, venue-side position
ledger) whose fill math is bit-identical to the shadow adapter. The
external route arms ONLY from environment credentials
(`ARSIC_VENUE_URL/KEY/SECRET`); a non-loopback URL additionally requires
`ARSIC_LIVE_ACK=I_UNDERSTAND_EXTERNAL_EXECUTION_RISK` — pointing this at a
real venue is a deliberate human act outside this sandbox, custody stays at
the venue, and losses are real. Day-start **reconciliation** compares the
venue book against the broker book; any divergence trips the kill-switch
and revokes the mandate. HITL approvals now execute **immediately at the
freshest quote** behind a drift guard (default 25 bps): larger moves demand
an audited re-approval at the refreshed quote.

### Independent sentinel (out-of-process circuit breaker)

`python -m arsic sentinel --api http://127.0.0.1:8787 --venue-url …
--venue-key … --venue-secret … [--deadman 3 --max-gross N --loss-cap N]`
runs a SEPARATE process holding its own **cancel-scope** venue credentials
(the venue rejects order placement on that key). Escalation ladder: limit
breach → ask ARSIC to trip its own breaker (one grace cycle) → breach
persists, runtime stalls, or goes unreachable past the dead-man window
while the venue holds risk → the sentinel flattens venue-side directly,
with no dependence on the ARSIC runtime. The test suite proves it: ARSIC is
SIGSTOPped mid-mandate, the sentinel flattens the venue while the process
is frozen, and on resume ARSIC's own reconciliation trips the breaker and
revokes the mandate — the loop closes from both sides. The console shows
sentinel liveness when it pings the backend.

## Autonomy loop (S10)

`POST /api/auto/tick` (and the **Autonomy loop** button in the console) closes
the knowledge→improvement loop: scan the wiki for gaps (stale pages, low-confidence
claims, uncovered anomalies, arbiter queue) → gather targeted information through
the same governed agent machinery (scopes, quotas, audit; deep-dive spawns) →
mine improvement candidates *from the gathered knowledge* (each carrying evidence
cids you can trace) → run evolution epochs on a cadence. The envelope holds:
SKILL promotions auto-execute, POLICY/ADAPTER queue for human keys, a standing
human approval transfers to an identical re-proposal (audited
`auto.approval_transfer`), the synthetic world extends past the bootstrap horizon
with an identical prefix, and any breaker trip halts the loop until a human
resets it.

## Wired console (HTML frontend on the Python backend)

```bash
python3 -m arsic serve --root run_srv --port 8787 --html ARSIC.html
# open http://127.0.0.1:8787/
```

The bundled `ARSIC.html` auto-detects `/api/health` and wires itself to this
server: every human key (POLICY+ approvals, kill-switch trips/resets, arbiter
rulings, autonomy tickets, epochs, adapter updates, evaluator replacement)
executes as a governance action on the real `SystemState`, with the sha256
audit chain on disk and the git-backed harness repo. The Verify tab runs the
full Python test suite through `/api/selftest`. Opened as a plain file (or if
no backend responds) the console falls back to its embedded JS engine.
Paper-only invariants are identical in both modes: autonomy L3 is never
grantable and the gateway structurally rejects live orders.
